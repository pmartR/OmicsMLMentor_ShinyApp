## code to prepare `expert_mentor` dataset goes here

## Rules table for each of the machine learning methods

#' check if the data has correlation based on intensity values
#'
#' @param x Raw p x n expression data matrix
#' 
#' @return A numeric value representing the average correlation between all pairs of biomolecules
#' 
#' @keywords internal
average_correlation <- function(x) {
  #calculate correlation matrix of edata with the edata_cname column removed
  c_m <- cor(x, use = "pairwise.complete.obs")
  #take the absolute value of the upper triangular values (without diagonal of 1's) since corr matrix is symmetric
  correlation_values <- abs(c_m[upper.tri(c_m, diag = FALSE)])
  #output a "overall correlation in data" score depending on how many correlations are above a threshold
  #the lower the score, the "more correlated" the data set is
  #e.g. read as: if more than 85% of the data has a (absolute) correlation of 0.95, return 0
  if ( sum(correlation_values > 0.95, na.rm = T)/length(correlation_values) > 0.85 ) return(1)
  else if ( sum(correlation_values > 0.9, na.rm = T)/length(correlation_values) > 0.8 ) return(0.75)
  else if ( sum(correlation_values > 0.85, na.rm = T)/length(correlation_values) > 0.75 ) return(0.5)
  else if ( sum(correlation_values > 0.8, na.rm = T)/length(correlation_values) > 0.7 ) return(0.25)
  else return(0)
}

#' Check for outliers by using the mean pvalue score from the rmd filter function
#'
#' @param x An slData object
#'
#' @return A numeric value representing the average p-value of the rMd test across all samples
#'
#' @keywords internal
outlier_sensitivity_score <- function(x) {
  # use pmart::rmd_filter function to grab an average MAD score
  # data must have 'group_DF' to work, if it's not present, just return 1 and use algorithm scores as is
  if(inherits(x, "seqData")){
    return(1)
  } else if (!is.null(attr(x, "group_DF")) ){
    return( round(mean(pmartR::rmd_filter(x)$pvalue), 2))
  }
  else if (!is.null(attr(x, "response_info")$categorical$fdata_col)){
    group_name <- attr(x, "response_info")$categorical$fdata_col
    return( round(mean(pmartR::rmd_filter(pmartR::group_designation(x, group_name))$pvalue), 2))
  }
  else {
    return(1)
  }
}
