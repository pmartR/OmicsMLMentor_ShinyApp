#' Creates an imputeData object
#'
#' Imputes data according to the specified method.
#'
#' @param slData An object output from the \code{as.slData} function.
#'
#' @param method A character string specifying which method to use for imputing
#'   missing values. Currently supports 'ppca'.
#'   
#' @param ... Extra arguments to be passed to the imputation method.  These include:
#'  - pcaMethods::pca for method = 'ppca'
#'
#' @return An impute data object
#'
#' @author Evan A Martin
#'
#' @export
#'
imputation <- function(slData, method = "ppca", ...) {
  # Make sure the input is the correct class.
  if (!inherits(slData, "slData")) {
    stop("The input must be an slData object.")
  }

  # Ensure the imputation method is an accepted method.
  if (!method %in% c("ppca")) {
    # You shall not pass!!!
    stop("The input to method does not match any of the accepted values.")
  }

  # Impute values according to the input to method.
  if (method == "ppca") {
    imputed <- pcaMethods::pca(
      t(data.matrix(slData$e_data[, -get_edata_idx(slData)])),
      method = 'ppca',
      ...
    )
    
    imputed <- t(pcaMethods::completeObs(imputed))
  }

  # Return an imputation object with the imputed_values and missing_by_sample
  # attributes.
  return(
    structure(
      as.data.frame(imputed, check.names = FALSE),
      # Add in imputeData attributes.
      original_edata = slData$e_data,
      missing_by_sample = slData$e_data[, -get_edata_idx(slData)] %>%
        purrr::map_df(~ sum(is.na(.)) / length(.)) %>%
        `class<-`("data.frame"),
      imputation_method = method,
      class = c("imputeData", "data.frame")
    )
  )
}

#' Imputes missing values in \code{slData$e_data}
#'
#' Combines the imputeData and slData object to create an slData object where
#' all missing values have been imputed.
#'
#' @param imputeData asdf
#'
#' @param slData asdf
#'
#' @return An slData object with all missing values imputed.
#'
#' @author Evan A Martin
#'
#' @export
#'
apply_imputation <- function(imputeData, slData) {
  # Preliminaries --------------------------------------------------------------

  # We have to carry out all these preliminary checks because we were asked:
  # "When using this software, what would an idiot do?"

  if (!inherits(imputeData, "imputeData")) {
    stop("The input to the imputeData argument must be an imputeData object.")
  }

  if (!inherits(slData, "slData")) {
    stop("The input to the slData argument must be an slData object.")
  }

  # Apply imputation -----------------------------------------------------------

  # Replace the original values in e_data with the imputed values.
  slData$e_data[, -get_edata_idx(slData)] <- imputeData

  # Extract the data_info attribute from the slData object. This will be used to
  # update the data_info attribute with the imputed data.
  the_info <- get_data_info(slData)

  # Oh look! Here is the end of the function already.
  #
  # The actual imputation was carried out in the imputation function. All we
  # need to do here is add the slData attributes to the data frame with the
  # imputed values. The data_info attribute will be updated but all other
  # attributes will remain the same.
  return(
    structure(
      slData,
      data_info = pmartR:::set_data_info(
        e_data = slData$e_data,
        edata_cname = get_edata_cname(slData),
        data_scale_orig = the_info$data_scale_orig,
        data_scale = the_info$data_scale,
        data_types = the_info$data_types,
        norm_info = the_info$norm_info,
        is_normalized = the_info$norm_info$is_normalized,
        batch_info = the_info$batch_info,
        is_bc = the_info$batch_info$is_bc
      ),
      original_edata = attr(imputeData, "original_edata"),
      imputation_info = list(
        imputation_method = attr(imputeData, "imputation_method"),
        prop_imputed = the_info$prop_missing
      )
    )
  )
}

#' Create a transData object
#'
#' Calculates the information needed to apply a transformation to the data.
#'
#' @param slData asdf
#'
#' @param rollupMethod A character string specifying which rollup method will be
#'   used. This argument is required if the slData object contains peptide data.
#'   The current options are "rollup", "rrollup", "qrollup", and "zrollup". The
#'   default is NULL.
#'
#' @param threshold_q A scalar between zero and one used for filtering peptides
#'   during qrollup. Peptides whose means fall below this value are not used
#'   when rolling up to the protein level.
#'
#' @return A transData object
#'
#' @author Evan A Martin
#'
#' @export
#'
transformation <- function(slData, rollupMethod = NULL, threshold_q = NULL) {
  accepted_methods <- c("rollup", "rrollup", "qrollup", "zrollup")

  is.peptide <- attr(slData, "omicsData_class") == "pepData"

  # Make sure the input is the correct class.
  if (!inherits(slData, "slData")) {
    stop("The input must be an slData object.")
  }

  # Perform sundry checks when the data are peptides.
  if (is.peptide) {
    if (is.null(rollupMethod)) {
      # You must specify a rollup method for peptide data because the number of
      # missing values at the protein level depends how the data is rolled up.
      stop(
        "A rollup method must be specified for peptide data."
      )
    }

    if (!rollupMethod %in% accepted_methods) {
      # The user is trying to use a method that does not exist! WHY?!?!
      stop(
        paste(
          "The accepted rollup methods are: 'rollup', 'rrollup', 'qrollup',",
          "or 'zrollup'.",
          sep = " "
        )
      )
    }
  } else {
    # Set rollupMethod to NULL because the data are not peptides.
    rollupMethod <- NULL
  }

  # Convert all missing values to zero. This data frame will be saved as an
  # attribute and will be used if the user selects the linear map
  # transformation.
  zeros <- slData$e_data[, -get_edata_idx(slData)] %>%
    purrr::map_df(~ replace(., is.na(.), 0)) %>%
    # Only retain the data.frame class.
    `class<-`("data.frame") %>%
    # Add the biomolecule IDs back
    dplyr::bind_cols(
      dplyr::select(slData$e_data, get_edata_cname(slData))
    )

  # Compute proportion of missing values by biomolecule. This will be visualized
  # with plot methods to help determine the threshold or interval.
  props <- data.frame(
    feature = slData$e_data[[get_edata_cname(slData)]],
    prop_missing = rowSums(is.na(slData$e_data[, -get_edata_idx(slData)])) /
      (ncol(slData$e_data) - 1)
  )

  # If the input is peptide data add proportion of missing values by protein.
  if (is.peptide) {
    # Nab the check names attribute because data.frame conventions are making my
    # life miserable. In fact, if it weren't for check.names and the current
    # housing market my life would be pretty awesome right now.
    check_names <- attr(slData, "check.names")

    # Fish out the e_data, f_data, and e_meta column names corresponding to the
    # peptide, sample, and protein IDs.
    pep_id <- attr(slData, "cnames")$edata_cname
    samp_id <- attr(slData, "cnames")$fdata_cname
    pro_id <- attr(slData, "cnames")$emeta_cname

    # Compute the proportion of missing data by rollup type.
    prot_props <- switch(rollupMethod,
      "rollup" = {
        rollup_prop(
          slData = slData,
          pep_id = pep_id,
          pro_id = pro_id
        )
      },
      "rrollup" = {
        rollup_prop_r(
          slData = slData,
          pep_id = pep_id,
          pro_id = pro_id
        )
      },
      "qrollup" = {
        rollup_prop_q(
          slData = slData,
          pep_id = pep_id,
          pro_id = pro_id,
          threshold = threshold_q
        )
      },
      "zrollup" = {
        rollup_prop_z(
          slData = slData,
          pep_id = pep_id,
          pro_id = pro_id
        )
      }
    )
  } else {
    prot_props <- NULL
  }

  # Change the name of the feature column to the name of the biomolecule ID
  # column.
  names(props)[[1]] <- get_edata_cname(slData)

  return(
    structure(
      props,
      na_to_zero = zeros,
      original_edata = slData$e_data,
      prop_missing_prot = prot_props,
      rollup_method = rollupMethod,
      class = c("transData", "data.frame")
    )
  )
}

#' Transforms the data in \code{slData$e_data}
#'
#' Applies the specified transformation to the values in \code{slData$e_data}.
#'
#' @param transData An object output from the \code{transformation} function.
#'
#' @param slData An slData object created from the \code{as.slData} function.
#'
#' @param threshold A numeric value between 0 and 1. This will be used as a
#'   cutoff to determine which biomolecules will be converted to
#'   presence/absence.
#'
#' @param interval A vector with two elements. The first element is the lower
#'   bound the data will be mapped to. The second element is the upper bound the
#'   data will be mapped to.
#'
#' @return An slData object with the values in \code{slData$edata} transformed
#'   according the the specified method.
#'
#' @author Evan A Martin
#'
#' @export
#'
apply_transformation <- function(
    transData, slData, threshold = NULL, interval = NULL) {
  # Preliminaries --------------------------------------------------------------

  # We have to carry out all these preliminary checks because experience tells
  # us that the users of our software are idiots. If it is possible to mess
  # something up, even in the weirdest most unimaginable way, they will do it.

  if (!inherits(transData, "transData")) {
    stop("The input to transData must be a transData object.")
  }

  if (!inherits(slData, "slData")) {
    stop("The input to slData must be an slData object.")
  }

  # The following checks for the threshold and interval arguments make me feel a
  # little controlling and demanding. ... YOU! Do what I say. Exactly how I say.
  # When I say.
  if (is.null(threshold) && is.null(interval)) {
    stop("Either a threshold or an interval must be specified")
  }
  if (!is.null(threshold) && !is.null(interval)) {
    stop("Only one of threshold or interval can be specified")
  }
  if (!is.null(threshold) && length(threshold) != 1) {
    stop("The input to threshold must have a length of one.")
  }
  if (!is.null(threshold) && !is.numeric(threshold)) {
    stop("The input to threshold must be numeric.")
  }
  if (!is.null(interval) && length(interval) != 2) {
    stop("The input to interval must be a vector with two elements.")
  }
  if (!is.null(interval) && !is.numeric(interval)) {
    stop("The input to interval must be numeric.")
  }
  if (!is.null(interval) && interval[[1]] >= interval[[2]]) {
    stop("The first element of interval must be less than the second element.")
  }

  # Determine if the data are peptides or not. If they are we throw a fit
  # because of all the extra work peptides require.
  is.peptide <- attr(slData, "omicsData_class") == "pepData"

  # Transformation -------------------------------------------------------------

  # In this section of the function we take an ugly caterpillar as input and
  # output a beautiful butterfly.

  # If peptide data is the input just keep track of the proteins that will be
  # converted to p/a. The protein names will be stored as an attribute and
  # the slData$e_data that will be returned will be the same as the input. The
  # slData object will be updated during protein rollup.

  # Steps if a threshold was provided (peptide data) ---------
  if (!is.null(threshold) && is.peptide) {
    # Grab the index of the protein name variable. This is named edata_idx to
    # keep the code that creates the attributes the same whether or not the data
    # are peptides.
    #
    # This will always be the first column (unless some Prince Humperdinck comes
    # along and changes it) because of how we create the proportion missing data
    # frame at the protein level in the transformation function.
    edata_idx <- 1

    # Determine which proteins are above the threshold.
    to_pres_abs <- attr(transData, "prop_missing_prot") %>%
      dplyr::filter(prop_missing > threshold)

    # Keep the original slData$e_data. This will not be modified until the
    # protein rollup step.
    transfigured <- slData$e_data


    # Steps if a threshold was provided (not peptide data) ---------
  } else if (!is.null(threshold)) {
    # Nab the index of the biomolecule ID column in slData$e_data.
    edata_idx <- get_edata_idx(slData)

    # Snag biomolecules with a proportion of missing data above the threshold.
    # We need to use strictly greater than because we want to allow for the case
    # where biomolecules with at least one missing value are converted to p/a
    # and biomolecules with no missing values remain on the abundance scale. If
    # we use greater than or equal to it would convert biomolecules with no
    # missing values to p/a also. What good do multiple features of all 1s do?
    to_pres_abs <- slData$e_data %>%
      dplyr::inner_join(transData) %>%
      dplyr::filter(prop_missing > threshold)

    # Grab biomolecules with a proportion of missing data below the threshold.
    to_impute <- slData$e_data %>%
      dplyr::inner_join(transData) %>%
      dplyr::filter(prop_missing <= threshold)

    # Snag the index containing the prop_missing variable. We will use this to
    # correctly subset the to_impute and to_pres_abs data frames when
    # imputing/converting to p/a.
    prop_idx <- ncol(to_pres_abs)

    # Convert biomolecules with missing values above the given threshold to
    # presence/absence.
    if (nrow(to_pres_abs) > 0) {
      # Replace missing values with 0 and non-missing values with 1.
      to_pres_abs[, -c(edata_idx, prop_idx)] <- to_pres_abs %>%
        dplyr::select(-dplyr::all_of(c(edata_idx, prop_idx))) %>%
        purrr::map_df(~ dplyr::if_else(is.na(.), 0, 1)) %>%
        # Only retain the data.frame class.
        `class<-`("data.frame")
    }

    # The remaining biomolecules will have missing values imputed.
    if (nrow(to_impute) > 0) {
      # Impute missing values if there are any. Otherwise just return the
      # original data frame.
      if (any(is.na(to_impute))) {
        to_impute[, -c(edata_idx, prop_idx)] <- to_impute %>%
          dplyr::select(-dplyr::all_of(c(edata_idx, prop_idx))) %>%
          data.matrix() %>%
          Amelia::amelia(., p2s = 0, m = 1) %>%
          `$`("imputations") %>%
          `$`("imp1") %>%
          data.frame(check.names = FALSE)
      }
    }

    # Combine the p/a and imputed data depending on how the data were split.
    if (nrow(to_pres_abs) > 0 && nrow(to_impute) > 0) {
      # Combine the imputed and p/a data frames row-wise. Also remove the
      # prop_missing variable because we no longer need it.
      transformed <- dplyr::bind_rows(
        to_pres_abs, to_impute
      ) %>%
        dplyr::select(-prop_missing)

      # Reorder the rows of transformed according to the original order.
      transfigured <- transformed[match(
        # The order of the biomolecules from the feature_info attribute are in
        # the order the data were in when the slData object was created.
        attr(slData, "feature_info")$names_orig,
        # The order of the biomolecules in the transformed data set could be
        # different from the original because we split the data based on the
        # proportion of missing data.
        transformed[[get_edata_cname(slData)]]
      ), ]
    } else if (nrow(to_pres_abs) > 0 && nrow(to_impute) == 0) {
      transfigured <- to_pres_abs %>%
        dplyr::select(-prop_missing)
    } else if (nrow(to_pres_abs) == 0 && nrow(to_impute) > 0) {
      transfigured <- to_impute %>%
        dplyr::select(-prop_missing)
    }

    # Steps if an interval was provided ---------
  } else {
    # Map the data frame containing zeros, representing missing values, to the
    # specified interval. This mapping will be done column-wise.
    transfigured <- attr(transData, "na_to_zero") %>%
      dplyr::select(-get_edata_cname(slData)) %>%
      purrr::map_df(
        linear_map,
        lower_bound = interval[[1]],
        upper_bound = interval[[2]]
      ) %>%
      dplyr::bind_cols(
        dplyr::select(attr(transData, "na_to_zero"), get_edata_cname(slData))
      ) %>%
      `class<-`("data.frame")
  }

  # Replace the original values in e_data with the transformed values.
  slData$e_data <- transfigured

  # Extract the data_info attribute from the slData object. This will be used to
  # update the data_info attribute with the transformed data.
  the_info <- get_data_info(slData)

  # Update the slData object with the transformed values and update the
  # attributes to reflect the transformation. The transformation type and
  # effects (e.g., number of biomolecules converted to p/a, ...) can be added to
  # the data_info attribute.
  #
  # The data_info attribute will be updated but all other attributes will remain
  # the same.
  return(
    structure(
      slData,
      data_info = pmartR:::set_data_info(
        e_data = slData$e_data,
        edata_cname = get_edata_cname(slData),
        data_scale_orig = the_info$data_scale_orig,
        data_scale = the_info$data_scale,
        data_types = the_info$data_types,
        norm_info = the_info$norm_info,
        is_normalized = the_info$norm_info$is_normalized,
        batch_info = the_info$batch_info,
        is_bc = the_info$batch_info$is_bc
      ),
      original_edata = attr(transData, "original_edata"),
      transformation_info = list(
        n_pres_abs = if (!is.null(threshold)) nrow(to_pres_abs) else NULL,
        names_pres_abs = if (!is.null(threshold)) {
          dplyr::pull(to_pres_abs, edata_idx)
        } else {
          NULL
        },
        rollup_method = if (is.peptide) {
          attr(transData, "rollup_method")
        } else {
          NULL
        },
        interval = interval
      )
    )
  )
}

# Maps the data from the current range to a user specified range. All missing
# values are converted to 0 prior to mapping the data.
#
# @author I can't remember, but Lisa knows.
linear_map <- function(x, lower_bound, upper_bound) {
  # Find the range of x.
  range_x <- range(x) # Here it is!

  # Compute the difference in the range of x.
  diff_x <- diff(range_x)

  # Compute the difference of the interval that x will be scaled to.
  diff_i <- upper_bound - lower_bound

  # Scale the data to the given interval.
  return(lower_bound + diff_i * (x - range_x[[1]]) / diff_x)
}

# Determines the proportion of missing values at the protein level when using
# vanilla rollup.
#
# @author Evan A Martin
rollup_prop <- function(slData, pep_id, pro_id) {
  # Proportionate the heck out of the peptides!
  prot_props <- merge(
    x = slData$e_meta[, c(pep_id, pro_id)],
    y = slData$e_data,
    by = pep_id,
    all.x = FALSE,
    all.y = TRUE
  ) %>%
    dplyr::select(-rlang::sym(pep_id)) %>%
    dplyr::group_by(!!rlang::sym(pro_id)) %>%
    dplyr::mutate(
      dplyr::across(
        .cols = -dplyr::any_of(pro_id),
        .fns = ~ mean(.x, na.rm = TRUE)
      )
    ) %>%
    dplyr::ungroup() %>%
    dplyr::distinct() %>%
    dplyr::mutate(
      prop_missing = rowSums(is.na(.)) / (ncol(.) - 1)
    ) %>%
    dplyr::select(!!rlang::sym(pro_id), prop_missing)

  return(prot_props)
}

# Determines the proportion of missing values at the protein level when using
# rrollup (chocolate rollup if you are Kelly).
#
# @author Evan A Martin
rollup_prop_r <- function(slData, pep_id, pro_id) {
  prot_props <- merge(
    x = slData$e_meta[, c(pep_id, pro_id)],
    y = slData$e_data,
    by = pep_id,
    all.x = FALSE,
    all.y = TRUE
  ) %>%
    dplyr::select(-rlang::sym(pep_id)) %>%
    dplyr::group_by(!!rlang::sym(pro_id)) %>%
    dplyr::mutate(
      prop_missing = calc_prop_r(x = dplyr::across(), pro_id = pro_id)
    ) %>%
    dplyr::ungroup() %>%
    dplyr::distinct(!!rlang::sym(pro_id), prop_missing)

  return(prot_props)
}

# Calculates the proportion of missing data for a protein given a set of
# peptides mapping to it.
#
# x: a data frame consisting of the peptides mapping to a given protein. The
# peptides are down the rows and the samples are across the columns
#
# pro_id: a character string specifying the name of the protein ID column.
#
# @author Evan A Martin
calc_prop_r <- function(x, pro_id) {
  # Check if only one peptide maps to the protein.
  if (nrow(x) == 1) {
    prop_miss <- rowSums(is.na(x)) / ncol(x)

    # If there are multiple peptides mapping to a protein we will have to do a lot
    # of hand waving with an extremely complex set of instructions to get the
    # information we need. Good thing I am a coding grandmaster :)
  } else {
    # First find a reference peptide. The reference peptide is the peptide with
    # the least missing data. There could be more than one peptide that meets
    # this criteria. In this scenario we will select the peptide with the
    # largest median abundance.
    n_na <- rowSums(is.na(x))

    # If the minimum number of missing values is zero then the protein will not
    # have any missing values.
    if (min(n_na) == 0) {
      prop_miss <- 0
    } else {
      da_pepe <- which(n_na == min(n_na))

      if (length(da_pepe) > 1) {
        medi <- apply(x, 1, median, na.rm = TRUE)[da_pepe]
        da_pepe <- da_pepe[which(medi == max(medi))]
      }

      # Determine which samples will have missing values at the protein level
      # based on the row index of the missing values in the reference and
      # non-reference peptides. A sample with a missing value in the reference
      # peptide will not be missing at the protein level if the row index of a
      # non-missing value in the non-reference peptide matches the row index of
      # a non-missing value from a reference peptide sample.

      # Grab number of non-missing values in reference peptide.
      n_no_miss <- sum(!is.na(x[da_pepe, ]))

      non_miss_pepes <- x[, which(!is.na(x[da_pepe, ]))]

      # We want miss_pepes to be a data frame even if there is only one sample
      # in it. (That is what drop = FALSE does.)
      miss_pepes <- x[, which(is.na(x[da_pepe, ])), drop = FALSE]

      # Determine which peptides (with non-missing values for the reference
      # peptide) have at least one non-missing values across all samples. This
      # vector will be used to determine which samples (belonging to missing
      # values in the reference peptide) will have a non-missing/missing value
      # at the protein level. REMEMBER: a sample with a missing value in the
      # reference peptide will not have a missing value at the protein level if
      # a non-reference peptide has a non-missing value in at least one peptide
      # with a non-missing value in the reference peptide.
      #
      # Do not fear if you didn't understand that paragraph after reading it
      # through only once. You do NOT need to worry about your mental capacity
      # nor your ability to think and reason.
      at_least_one <- data.frame(
        alo = rowSums(!is.na(non_miss_pepes)) > 0
      )

      # Loop through each sample with a missing value in the reference peptide
      # (there may only be one) and determine if it will be missing at the
      # protein level.
      for (e in 1:ncol(miss_pepes)) {
        # See if there is any overlap in non-missing values between the
        # missing/non-missing samples (from the reference peptide) for any
        # peptide. If there is any overlap then the sample in question will not
        # have a missing value at the protein level.
        any_overlap <- any(
          rowSums(data.frame(at_least_one, !is.na(miss_pepes[, e]))) == 2
        )

        if (any_overlap) n_no_miss <- n_no_miss + 1
      }

      # We counted the number of NON-MISSING values but the proportion is
      # computed by the number of missing values. We need to subtract the number
      # of non-missing values from the total number of samples to get the
      # correct proportion.
      prop_miss <- (ncol(x) - n_no_miss) / ncol(x)
    }
  }

  return(prop_miss)
}

# Determines the proportion of missing values at the protein level when using
# qrollup. (Cinnamon rollup perhaps?)
#
# @author Evan A Martin
rollup_prop_q <- function(slData, pep_id, pro_id, threshold) {
  prot_props <- merge(
    x = slData$e_meta[, c(pep_id, pro_id)],
    y = slData$e_data,
    by = pep_id,
    all.x = FALSE,
    all.y = TRUE
  ) %>%
    dplyr::select(-rlang::sym(pep_id)) %>%
    dplyr::group_by(!!rlang::sym(pro_id)) %>%
    dplyr::mutate(
      prop_missing = calc_prop_q(
        x = dplyr::across(),
        pro_id = pro_id,
        threshold_q = threshold_q
      )
    ) %>%
    dplyr::ungroup() %>%
    dplyr::distinct(!!rlang::sym(pro_id), prop_missing)

  return(prot_props)
}

# Calculates the proportion of missing data for a protein given a set of
# peptides mapping to it.
#
# x: a data frame consisting of the peptides mapping to a given protein. The
# peptides are down the rows and the samples are across the columns
#
# pro_id: a character string specifying the name of the protein ID column.
#
# threshold_q: a numeric values between 0 and 1. This is the cutoff used to
# determine which peptides will be used for rolling up to the protein level.
#
# @author Evan A Martin
calc_prop_q <- function(x, pro_id, threshold_q) {
  # Check if only one peptide maps to the protein.
  if (nrow(x) == 1) {
    prop_miss <- rowSums(is.na(x)) / ncol(x)

    # If there are multiple peptides mapping to a protein we will have to take
    # multiple steps (three to be exact) to get the information we need. While
    # qrollup is not as complex as rrollup you are still very lucky that I am a
    # coding grandmaster!
  } else {
    # Step 1: Calculate the mean abundance for each peptide.
    da_means <- rowMeans(x, na.rm = TRUE)
    quant <- quantile(da_means, probs = threshold_q, na.rm = TRUE)

    # Step 2: Subset peptides whose abundance is >= to the qrollup threshold.
    x_new <- x[which(da_means >= quant), , drop = FALSE]

    # Step 3: Determine which samples have missing/non-missing values at the
    # protein level.
    prop_miss <- rowSums(is.na(x_new)) / ncol(x_new)
  }

  return(prop_miss)
}

# Determines the proportion of missing values at the protein level when using
# zrollup.
#
# @author Evan A Martin
rollup_prop_z <- function(slData, pep_id, pro_id) {
  prot_props <- merge(
    x = slData$e_meta[, c(pep_id, pro_id)],
    y = slData$e_data,
    by = pep_id,
    all.x = FALSE,
    all.y = TRUE
  ) %>%
    dplyr::select(-rlang::sym(pep_id)) %>%
    dplyr::mutate(
      n_no_na = rowSums(!is.na(dplyr::across(-dplyr::any_of(pro_id))))
    ) %>%
    dplyr::filter(n_no_na >= 2) %>%
    dplyr::select(-n_no_na) %>%
    dplyr::group_by(!!rlang::sym(pro_id)) %>%
    # Take the column-wise median across samples. Any samples with an NA after
    # this step do not meet the z roll up criteria for having a non-missing
    # value at the protein level.
    dplyr::mutate(
      dplyr::across(
        .cols = -dplyr::any_of(pro_id),
        .fns = ~ median(.x, na.rm = TRUE)
      )
    ) %>%
    dplyr::ungroup() %>%
    dplyr::distinct() %>%
    dplyr::mutate(
      prop_missing = rowSums(is.na(.)) / (ncol(.) - 1)
    ) %>%
    dplyr::ungroup() %>%
    dplyr::distinct(!!rlang::sym(pro_id), prop_missing)

  return(prot_props)
}

#' Makes the dataframe indicating whether we will keep, impute, convert, or remove
#' 
#' @param omicsData An object of one of the main \code{omicsData} classes from pmartR.
#' @param thresholds A named list with names 'keep', 'impute', 'convert', and 'remove' and entries consisting of length 2 numeric vectors specifying the range of missing values percentages for which the action corresponding to the list element name should be taken.
#' 
#' @return a data.frame with the biomolecule IDs, the percentage of missing values, and the action to be taken.
#' 
#' @export
get_transform_df <- function(
    omicsData,
    thresholds
  ) {
  id_col <- colnames(omicsData$e_data) %in% pmartR::get_edata_cname(omicsData)
  df <- omicsData$e_data[!id_col]
  
  apply_dir <- 1
  total <- ncol(df[-1])
  
  # holds the pct missing and the decision to keep, impute, convert, or remove the biomolecule
  transform_df <- data.frame(
    omicsData$e_data[id_col],
    `Percentage missing` = apply(is.na(df[-1]), apply_dir, sum)/total*100, check.names = F)
  
  # By default a molecule is kept
  transform_df$Handling <- "Unassigned"
  
  if("keep" %in% names(thresholds)){
    
    rows <- Reduce("&", list(
      transform_df[["Percentage missing"]] >= thresholds$keep[1],
      transform_df[["Percentage missing"]] <= thresholds$keep[2]
    ))
    
    transform_df$Handling[rows] <- "Keep"
    
  }
  
  if("impute" %in% names(thresholds)){
    
    rows <- Reduce("&", list(
      transform_df[["Percentage missing"]] >= thresholds$impute[1],
      transform_df[["Percentage missing"]] <= thresholds$impute[2]
    ))
    
    transform_df$Handling[rows] <- "Estimate"
    
  }
  
  if("convert" %in% names(thresholds)){
    
    rows <- Reduce("&", list(
      transform_df[["Percentage missing"]] >= thresholds$convert[1],
      transform_df[["Percentage missing"]] <= thresholds$convert[2]
    ))
    
    transform_df$Handling[rows] <- "Convert"
    
  }
  
  if("remove" %in% names(thresholds)){
    
    rows <- Reduce("&", list(
      transform_df[["Percentage missing"]] >= thresholds$remove[1],
      transform_df[["Percentage missing"]] <= thresholds$remove[2]
    ))
    
    transform_df$Handling[rows] <- "Remove"
    
  }
  
  attributes(transform_df)$class <- c("imputeFilt", attributes(transform_df)$class)
  return(transform_df)
  
}

#' Remove NA values by removing, 0-1 converting, or imputing based on specified ranges.
#' 
#' @param slData An slData object that inherits one of the main \code{omicsData} classes from pmartR.
#' @param thresholds Either of 1.  A named list with names 'keep', 'impute', 'convert', and 'remove' and entries consisting of length 2 numeric vectors specifying the range of missing values percentages for which the action corresponding to the list element name should be taken.  2. A data.frame returned by \code{\link{get_transform_df}} or in the same structure which specifies the action to be taken for each biomolecule.
#' @param ... Additional arguments to be passed to \code{\link{slopeR::imputation}}.
#' 
#' @return An slData object with the specified conversions applied.
#' 
#' @examples 
#' # impute anything with 0-60% missing values, convert anything with 60-90% missing values, and remove anything with 90-100% missing values.
#' myslData <- as.slData(pdata_processed)
#' 
#' thresholds = list(
#'   'remove' = c(90,100),
#'   'convert' = c(60, 90),
#'   'impute' = c(0,60)
#' )
#' 
#' myslData_trf <- edata_nathresh_transform(myslData, thresholds)
#' 
#' @export
edata_nathresh_transform <- function(slData, thresholds, ...) {
  all_imp <- slopeR::imputation(slData, ...)
  
  if (inherits(thresholds, 'data.frame')) {
    selections <- thresholds
  } else {
    selections <- get_transform_df(slData, thresholds)
  }

  estimate_peps <- selections[selections$Handling == "Estimate", 1]
  convert_peps <- selections[selections$Handling == "Convert", 1]
  remove_peps <- selections[selections$Handling == "Remove", 1]

  tmp <- slData

  ## Impute
  impute_rows <- tmp$e_data[[pmartR::get_edata_cname(tmp)]] %in% estimate_peps
  tmp$e_data[impute_rows, -1] <- all_imp[impute_rows,]

  ## Convert
  convert_rows <- tmp$e_data[[pmartR::get_edata_cname(tmp)]] %in% convert_peps
  tmp$e_data[convert_rows, -1] <- apply(
    ## Logical T/F for presence/absence
    Reduce("&", list(
      !is.na(tmp$e_data[convert_rows, -1]), ## Normal
      tmp$e_data[convert_rows, -1] != 0 ## RNA, shouldn't mess up other types since we convert 0s
    )),
    ## Convert to numeric
    2, as.numeric)
  
  ## Remove
  tmp <- pmartR::applyFilt(pmartR::custom_filter(tmp, e_data_remove = remove_peps), tmp)

  # Remove the custom filter
  attributes(tmp)$filters[[length(attributes(tmp)$filters)]] <- NULL
  attributes(tmp)$na_transforms <- selections

  return(tmp)
}

#' Return an slData object that has been transformed with \code{\link{edata_nathresh_transform}} with the 0-1 transformed data filtered out.
#' 
#' @param slData An slData object that inherits one of the main \code{omicsData} classes from pmartR and has been transformed with \code{\link{edata_nathresh_transform}}.
#'
#' @return An slData object with the 0-1 converted data removed.
#'
#' @export
subset_noconv <- function(slData) {
  na_trf_df = attributes(slData)$na_transform

  if (!is.null(na_trf_df)) {
    converted_biomols <- na_trf_df %>% 
      dplyr::filter(Handling == "Convert") %>% 
      dplyr::pull(get_edata_cname(slData))
      
    converted_biomols <- intersect(converted_biomols, slData$e_data[[get_edata_cname(slData)]])
    if (length(converted_biomols) > 0) {
      cfilt <- pmartR::custom_filter(slData, e_data_remove = converted_biomols)
      slData <- pmartR::applyFilt(cfilt, slData)
    }
  } else {
    warning("No na_transform attribute found. Returning original slData object.")
  }
  
  return(slData)
}

#' Plot an slData object that has been transformed with \code{\link{edata_nathresh_transform}}, excluding the 0-1 converted data.
#' 
#' @param slData An slData object that inherits one of the main \code{omicsData} classes from pmartR and has been transformed with \code{\link{edata_nathresh_transform}}.
#' @param ... Additional arguments to be passed to \code{plot.<omicsData type>}.
#'
#' @return A plot of the transformed data.
#'
#' @export
plot_noconv <- function(slData, ...) {
  na_trf_df = attributes(slData)$na_transform

  if (!is.null(na_trf_df)) {
    converted_biomols <- na_trf_df %>% 
      dplyr::filter(Handling == "Convert") %>% 
      dplyr::pull(get_edata_cname(slData))
      
    if (length(converted_biomols) > 0) {
      cfilt <- pmartR::custom_filter(slData, e_data_remove = converted_biomols)
      slData <- pmartR::applyFilt(cfilt, slData)
    }
  } 
  
  plot(slData, ...)
}