#' asdf
#'
#' asdf
#'
#' @param object asdf
#'
#' @param ... asdf
#'
#' @rdname summary-imputeData
#'
#' @author Evan A Martin
#'
#' @importFrom stats median
#'
#' @importFrom utils capture.output
#'
#' @export
#'
summary.imputeData <- function(object, ...) {
  # Create output in a list.
  the_list <- list(
    n_miss = sum(is.na(attr(object, "original_values"))),
    prop_miss = round(
      sum(is.na(attr(object, "original_values"))) /
        prod(dim(attr(object, "original_values"))),
      3
    ),
    prop_miss_sample = attr(object, "missing_by_sample"),
    median_prior = attr(object, "original_values") %>%
      purrr::map_df(~ median(., na.rm = TRUE)) %>%
      `class<-`("data.frame"),
    median_post = object %>%
      purrr::map_df(~ median(., na.rm = TRUE)) %>%
      `class<-`("data.frame")
  )

  class(the_list) <- "summary.imputeData"

  return(the_list)
}

#' @importFrom utils capture.output
#'
#' @export
#'
print.summary.imputeData <- function(x, ...) {
  cat("Number of values imputed: ", x$n_miss)

  cat(
    "\nProportion of values imputed: ",
    x$prop_miss,
    "\n"
  )

  cat(
    "\nProportion of values imputed by sample:",
    x$prop_miss_sample %>%
      capture.output(),
    sep = "\n"
  )

  cat(
    "\nSample medians prior to imputation:",
    x$median_prior %>%
      capture.output(),
    sep = "\n"
  )

  cat(
    "\nSample medians after imputation:",
    x$median_post %>%
      capture.output(),
    sep = "\n"
  )

  invisible(x)
}

#' asdf
#'
#' asdf
#'
#' @param object asdf
#'
#' @param ... asdf
#'
#' @rdname summary-transData
#'
#' @author Evan A Martin
#'
#' @export
#'
summary.transData <- function(object, ...) {
  # Create a data frame with the range of proportion of missing values as one
  # variable and the counts of biomolecules that fall within the corresponding
  # range as another variable.
  ranges <- data.frame(
    range = c(
      "[0,0.1)", "[0.1,0.2)", "[0.2,0.3)", "[0.3,0.4)", "[0.4,0.5)",
      "[0.5,0.6)", "[0.6,0.7)", "[0.7,0.8)", "[0.8,0.9)", "[0.9,1]"
    ),
    count = c(
      object %>%
        dplyr::filter(prop_missing < 0.1) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.1,
          prop_missing < 0.2
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.2,
          prop_missing < 0.3
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.3,
          prop_missing < 0.4
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.4,
          prop_missing < 0.5
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.5,
          prop_missing < 0.6
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.6,
          prop_missing < 0.7
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.7,
          prop_missing < 0.8
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.8,
          prop_missing < 0.9
        ) %>%
        nrow(),
      object %>%
        dplyr::filter(
          prop_missing >= 0.9,
          prop_missing <= 1
        ) %>%
        nrow()
    )
  )

  class(ranges) <- c("summary.transData", "data.frame")

  return(ranges)
}

#' @importFrom utils capture.output
#'
#' @export
#'
print.summary.transData <- function(x, ...) {
  cat("Number of biomolecules by proportion of missing data: \n")

  invisible(x)

  # I tried using capture.output to print x. However, I kept getting a "sink
  # stack is full" error. It correctly prints when using the NextMethod function
  # because x is also a data.frame.
  NextMethod("print")
}

#' Get a table of the methods and how they scored on the various criteria
#' 
#' @param slSuggestions an `slSuggestions` object from `expert_mentor`.
#' @param apply_hard_filter whether to filter out algorithms that do not pass hard rules
#' @param filter one of 'hard' or 'soft' to filter down to a summary of the algorithm's scores on hard or soft rules
#' @param algos a character string of algorithms to filter down to
#' @param quietly whether to print out the top returned algorithms
#' 
#' @export
summary.slSuggestions <- function(slSuggestions, apply_hard_filter = FALSE, rule_type = NULL, algos = NULL, quietly = FALSE, ...) {
  decisions_soft <- attributes(slSuggestions)$soft_rules_filter %>%
    dplyr::bind_rows() %>%
    dplyr::mutate(method = names(algo_rules)) %>%
    dplyr::select(method, dplyr::everything())
  
  decisions_hard <- attributes(slSuggestions)$hard_rules_filter %>% 
    dplyr::bind_rows() %>%
    dplyr::mutate(method = names(algo_rules)) %>%
    dplyr::select(method, dplyr::everything())
  
  if (!is.null(rule_type)) {
    decisions = if(rule_type == "soft") {
      decisions_soft
    } else if(rule_type == "hard") {
      decisions_hard
    }
  } else {
    decisions <- decisions_hard %>% 
      dplyr::left_join(decisions_soft, by ="method")
  }
  
  if(!is.null(algos)) {
    decisions <- decisions %>% dplyr::filter(method %in% algos)
  }
  
  if (apply_hard_filter) {
    decisions <- decisions %>% dplyr::filter(method %in% names(slSuggestions))
  }

  if (!quietly) {
    cat("Top methods from expert mentor: \n")
    print(
      decisions %>% 
        dplyr::mutate(score = rowSums(dplyr::across(-one_of(c("method", names(hard_rule_names)))))) %>% 
        dplyr::arrange(dplyr::desc(score)) %>%
        head(),
      max_footer_lines = 0
    ) 
  }
  
  return(invisible(decisions))
}
