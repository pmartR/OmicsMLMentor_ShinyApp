# Functions for extracting attributes ------------------------------------------

#' Fetch the column index of the biomolecule ID variable
#'
#' Retrieves the column index from \code{slData$e_data} for the biomolecule ID
#' variable.
#'
#' @param slData An slData object.
#'
#' @return The column number containing the biomolecule IDs.
#'
#' @author Evan A Martin
#'
#' @export
#'
get_edata_idx <- function(slData) {
  # Grab the column name for the biomolecule ID variable in e_data. This will be
  # used to nab the index for this column as we don't assume the columns to
  # appear in any particular order.
  edata_cname <- attr(slData, "cnames")$edata_cname

  # Snag the column number of the biomolecule ID variable in edata.
  edata_idx <- which(names(slData$e_data) == edata_cname)

  return(edata_idx)
}
