#' Create an slData object
#'
#' Converts a pmartR omicsData object to an slData object.
#'
#' @param omicsData A pmartR data object of any class.
#'
#' @param response_cols A character vector specifying the names of the columns in
#'   f_data that contain the class variables. There can be up to two class
#'   variables.
#'
#' @param response_types Optional, a character vector the same length as
#'   response_cols indicating the type of response "categorical" or 
#'   "continuous".  Defaults to NULL, which indicates that all response
#'   variables are categorical.
#'
#' @return An slData object
#'
#' @author Evan A Martin
#'
#' @importFrom magrittr `%>%`
#'
#' @export
#'
as.slData <- function(omicsData, response_cols = NULL, response_types = NULL) {
  # Check that omicsData is the appropriate class.
  if (!inherits(omicsData, c(
    "pepData", "proData", "metabData",
    "isobaricpepData", "lipidData", "seqData", "nmrData"
  ))) {
    # Throw an error that the input for omicsData is not the appropriate class.
    stop(
      paste("omicsData must be of class 'pepData', 'proData', 'metabData',",
        "'isobaricpepData', 'lipidData', 'seqData', or 'nmrData'.",
        sep = " "
      )
    )
  }

  # Check that response_cols is present in fdata.
  if (!is.null(response_cols)) {
    if (!all(response_cols %in% names(omicsData$f_data))) {
      stop(
        paste("The column(s) containing the class information is/are not",
          "present in f_data.",
          sep = " "
        )
      )
    }
  }

  if (!is.null(response_types)) {
    if (length(response_types) != length(response_cols)) {
      stop(
        paste("The length of response_types must be the same as the length of",
          "response_cols.",
          sep = " "
        )
      )
    }
    if (!all(response_types %in% c("categorical", "continuous"))) {
      stop(
        paste("response_types must be either 'categorical' or 'continuous'.",
          sep = " "
        )
      )
    }
  } 
  
  # Check if the data have been normalized. If the input is an nmrData object it
  # does not have to be normalized.
  #
  # Check isobaricpepData first because it is also a pepData object.
  if (inherits(omicsData, "isobaricpepData")) {
    if (!attr(omicsData, "data_info")$norm_info$is_normalized &&
      !attr(omicsData, "isobaric_info")$norm_info$is_normalized) {
      warning(
        paste(
          "The data was not isobaric normalized and global normalized before",
          "creating the slData object.",
          sep = " "
        )
      )
    }
  }
  if (inherits(omicsData, c("pepData", "proData", "metab", "lipidData"))) {
    if (!attr(omicsData, "data_info")$norm_info$is_normalized) {
      warning("omicsData object was not normalized.")
    }
  }

  # Snag edata_cname from the omicsData object.
  edata_cname <- attr(omicsData, "cnames")$edata_cname

  # Nab the class of the omicsData object. This will be an attribute of the
  # slData object.
  the_omicsdata_class <- class(omicsData)

  # Grab the class levels and number of levels. This info will be added as an
  # attribute when creating the slData object.
  if (!is.null(response_cols)) {
    # We allow up to two class variables. If there is more than one class
    # variable the levels of each class will be combined with an "_".
    response_by_type <- list(
      categorical = NULL,
      continuous = NULL
    )

    if (length(response_cols) == 1) {
      response <- omicsData$f_data %>%
        dplyr::pull(response_cols)

      if (is.null(response_types) || response_types == "categorical") {
        response_by_type$categorical <- list(
          "fdata_col" = response_cols,
          "values" = response, 
          "n_levels" = dplyr::n_distinct(response)
        )
      } else {
        response_by_type$continuous <- list("fdata_col" = response_cols,
                                            "values" = response)
        n_lvls <- NULL
      }

    } else if (length(response_cols) == 2) {
      if (all(response_types == "categorical")) {
        # Combine classes.
        response <- omicsData$f_data %>%
          dplyr::select(dplyr::all_of(response_cols)) %>%
          dplyr::mutate(
            new_class = purrr::pmap_chr(dplyr::across(), paste, sep = "_")
          ) %>%
          dplyr::pull(new_class)

        response_by_type$categorical <- list(
          "fdata_col" = response_cols,
          "values" = response, 
          "n_levels" = dplyr::n_distinct(response)
        )
      } else {
        for (i in 1:length(response_cols)) {
          response <- omicsData$f_data %>%
            dplyr::pull(response_cols[i])

          if (response_types[i] == "categorical") {
            response_by_type$categorical <- list(
              "fdata_col" = response_cols[i],
              "values" = response,
              "n_levels" = dplyr::n_distinct(response)
            )
          } else {
            response_by_type$continuous <- list("fdata_col" = response_cols[i],
                                                "values" = response)
            n_lvls <- NULL
          }
        }
      }
    } else {
      # Throw an error because there are 3 or more class variables.
      stop(
        paste("There can only be one or two class variables. You have",
          "specified three or more",
          sep = " "
        )
      )
    }
  }

  # Create an slData object from the omicsData object. The slData object will
  # have the same base structure and attributes as the omicsData object. The
  # slData object will have additional elements in the data_info attribute
  # (added with later functions) as well as two new attributes: response_info 
  # and feature_info.
  return(
    structure(
      omicsData,
      response_info = if (is.null(response_cols)) {
        NULL
      } else {
        list(
          "categorical" = if (is.null(response_by_type$categorical)) {
            NULL
          } else {
            list(
              raw_values = data.frame(
                sample_id = omicsData$f_data %>%
                  dplyr::pull(attr(omicsData, "cnames")$fdata_cname),
                response = response_by_type$categorical$values
              ),
              n_lvls = response_by_type$categorical$n_levels,
              fdata_col = response_by_type$categorical$fdata_col
            )
          },
          "continuous" = if(is.null(response_by_type$continuous)) {
            NULL
          } else {
            list(
              raw_values = data.frame(
                sample_id = omicsData$f_data %>%
                  dplyr::pull(attr(omicsData, "cnames")$fdata_cname),
                response = response_by_type$continuous$values
              ),
              fdata_col = response_by_type$continuous$fdata_col
            )
          }
        )
      },
      feature_info = data.frame(
        names_orig = omicsData$e_data %>%
          dplyr::pull(edata_cname),
        names_compact = paste("feature", 1:nrow(omicsData$e_data), sep = "_")
      ),
      omicsData_class = the_omicsdata_class,
      class = c("slData", class(omicsData))
    )
  )
}
