#' Check the input to the unsupervised learning functions.
unsup_preflight <- function(slData, slMethod, axis="samples", ...) {
  # Check if slData is the appropriate class.
  if (!inherits(slData, "slData")) {
    stop("The input to slData must be an slData object.")
  }

  # Check if slMethod is one of the acceptable methods. The acceptable_sl_sup vector
  # is stored internally. The file (acceptable_methods.R) that created the data
  # can be found in the data-raw directory.
  if (!slMethod %in% acceptable_sl_unsup) {
    stop(
      paste("The input to slMethod is not an acceptable method. See the",
        "documentation for a list of accepted methods.",
        sep = " "
      )
    )
  }
}

#' Prepare the data for unsupervised learning, we do not need to append
#' targets to the data as in supervised learning.  We can also specify whether
#' we are going to perform the analysis in the biomolecules (p x n) or samples
#' view (n x p)
#' 
#' @param slData An slData object.
#' @param axis A character string specifying whether we are going to perform
#' the analysis in the biomolecules (p x n) or samples view (n x p).
unsup_data <- function(slData, axis="samples") {
    # n x p
    if(axis == "samples") {
        the_df <- slData$e_data %>%
            dplyr::select(-dplyr::one_of(get_edata_cname(slData)))

        the_df <- the_df %>%
            t() %>%
            data.frame() %>%
            `rownames<-`(NULL)

        # We need to check the order of the feature names before renaming the columns.
        order_biomole <- match(
            slData$e_data %>%
            dplyr::pull(get_edata_idx(slData)),
            attr(slData, "feature_info")$names_orig
        )

        # Rename the columns with the friendly names (feature_1, feature_2, ...).
        names(the_df) <- attr(slData, "feature_info")$names_compact[order_biomole]
    } else if (axis == "biomolecules"){
        the_df <- slData$e_data |> 
            `rownames<-`(NULL) |> 
            tibble::column_to_rownames(get_edata_cname(slData)) %>%
            data.frame()
    } else {
        stop("The input to axis is not an acceptable method. See the documentation for a list of accepted methods.")
    }

    return(the_df)
}

#' Take in extra parameters for an unsupervised tidyverse model
digest_misc_unsup_args <- function(slMethod, model, ...){
  ## Get appropriate parameters for each model
  
  list_args <- list(...)
  
  if(length(list_args) == 0) return(model)
  
  
  ## For new models, investigate with inital model %>% translate to see what engine (package) functions are involved
  # Q: Why these strings? A: Because warning land -- less obnoxious that they are strings now then pulling them later
  funs <- switch(slMethod,
                 "kmeans" = list("tidyclust::k_means",
                                 "stats::kmeans"),
                 "hclust" = list("tidyclust::hier_clust",
                                 "stats::hclust"),
                 "pca" = list("stats::prcomp"),
                 "umap" = list("uwot::umap")
  )
  
  
  ## Capture viable arguments
  valid_args <- lapply(funs, function(x) names(formals(eval(parse(text = x)))))
  keep_args <- list_args[names(list_args) %in% unique(unlist(valid_args))]
  
  if(length(keep_args) == 0){
    
    warn_text <- c(
      "No valid model arguments were passed. Try one of the following:",
      paste(funs, sapply(valid_args, toString), sep = " -- "))
    
    warning(
      paste(
        warn_text,
        collapse = "\n"
      )
    )
  } else {
    ## update model
    model <- do.call(parsnip:::set_args, c(list(object = model), keep_args))
  }
  
  model
  
}

#' Create a model for unsupervised learning.
#'
#' @param slMethod character, one of the acceptable methods for unsupervised 
#' learning found in `acceptable_sl_unsup`.
#'
unsup_model <- function(slMethod, ...) {
  model <- switch(slMethod,
                  "kmeans" = {
                    tidyclust::k_means(num_clusters=2) |>
                    parsnip::set_engine('stats')
                  },
                  "hclust" = {
                    tidyclust::hier_clust(num_clusters=2) |>
                    parsnip::set_engine('stats')
                  }
  )
  
  model <- digest_misc_unsup_args(slMethod, model, ...)
  return(model)
}

#' return a given set of recipe pipe steps for a particular transformation
#'
#' @param recipe a recipe object with the data and roles added
#' @param slMethod character, one of the acceptable methods for unsupervised
#'  learning found in `acceptable_sl_unsup`.
#'
#' @export
#' 
unsup_transform <- function(recipe, slMethod, ...) {
  if (slMethod %in% c("pca")) {
    recipe <- recipe |> 
      recipes::step_pca(recipes::all_numeric(), ...) 
  } else if (slMethod %in% "umap") {
    recipe <- recipe |> 
      embed::step_umap(recipes::all_numeric(), ...)
  } else if (slMethod %in% "ppca") {
    recipe <- recipe |> 
      step_ppca(recipes::all_numeric(), ...)
  }

  return(recipe)
}

#' Apply unsupervised clustering method on slData.
#' @param slData An slData object.
#' @param ... Additional arguments to be passed to the unsupervised learning
#' @param slMethod A character string specifying the unsupervised machine
#' learning algorithm to use.  The current options are: 'kmeans','hclust'. Default is "kmeans".
#' @param axis A character string where to perform unsupervised analysis. Value must be one of c("samples","biomolecules"). 
#' Default is "samples".
#' @param dataRecipe Recipe object. Option to use a pre-created recipe. Default is NULL (creates recipe internally).
#' 
#' @return slRes.cluster object.  Also inherits 'workflow'.
#' 
#' @export
#' 
cluster_unsup <- function(
    slData, ..., slMethod = "kmeans", axis="samples", 
    dataRecipe = NULL) {
    
    unsup_preflight(
      slData = slData,
      slMethod = slMethod,
      axis = axis
    )

    the_df <- unsup_data(slData, axis=axis)

    the_model <- unsup_model(slMethod, ...)

    rec <- if(is.null(dataRecipe)) {
        recipes::recipe(the_df) |> 
            recipes::update_role(tidyselect::everything())
    } else dataRecipe

    wflow <- workflows::workflow() |> 
        workflows::add_model(the_model) |> 
        workflows::add_recipe(rec)

    the_fit <- wflow |> parsnip::fit(data = the_df)

    
    class(the_fit) <- c("slRes.cluster", class(the_fit))
    attributes(the_fit)$feature_info <- attr(slData, "feature_info")
    attributes(the_fit)$sample_names <- colnames(slData$e_data[-which(colnames(slData$e_data) == pmartR::get_edata_cname(slData))])
    attributes(the_fit)$axis <- axis
    attributes(the_fit)$method <- slMethod
    
    return(the_fit)
}

#' Apply dimension reduction method on slData.
#' @param slData An slData object.
#' @param slMethod A character string specifying the unsupervised machine
#' learning algorithm to use.  The current options are: 'pca','umap'. Default is "pca".
#' @param axis A character string where to perform unsupervised analysis. Value must be one of c("samples","biomolecules"). 
#' Default is "samples".
#' @param dataRecipe Recipe object. Option to use a pre-created recipe. Default is NULL (creates recipe internally).
#' @param bake Boolean. Whether to bake the recipe or not. Default is TRUE. 
#' 
#' @return If bake is FALSE, return the recipe. If TRUE, returns the transformed data.  Object also gains the class "slRes.embed".
#' 
#' @export
#' 
embed_unsup <- function(
  slData, slMethod = "pca", axis="samples", 
  dataRecipe = NULL, bake=TRUE, ...) {
  
  unsup_preflight(
    slData = slData,
    slMethod = slMethod,
    axis = axis
  )

  the_df <- unsup_data(slData, axis=axis)

  rec <- if(is.null(dataRecipe)) {
      recipes::recipe(the_df) |> 
          recipes::update_role(tidyselect::everything())
  } else dataRecipe

  rec <- rec |> 
    unsup_transform(slMethod, ...)

  if (bake) {
    rec <- rec |> 
      recipes::prep(training = the_df)
    
    # some methods, you wanna bake the complete (e.g. imputed) data, not the raw data.
    if (slMethod %in% c("ppca")) {
      x = rec$steps[[1]]$res@completeObs
      rec <- recipes::bake(rec, new_data = x)
    } else {
      rec <- recipes::bake(rec, new_data = the_df)
    }
  }
  
  class(rec) <- c("slRes.embed", class(rec))
  attributes(rec)$feature_info <- attr(slData, "feature_info")
  attributes(rec)$axis <- axis
  attributes(rec)$method <- slMethod
  attributes(rec)$sample_names <- colnames(slData$e_data[-which(colnames(slData$e_data) == pmartR::get_edata_cname(slData))])
  
  
  return(rec)
}

#' Creates a recipe step that will convert your numeric variables into PCA scores.
#' 
#' @param recipe A recipe object.  The step will be added to the
#'  sequence of operations for this recipe.
#' @param ... A selection of columns. This should be a selection of columns that are numeric.  See [?recipes::selections] for more details.
#' @param role For model terms created by this step, what analysis role should
#'  they be assigned? By default, the new columns created by this step from
#'  the original variables will be used as _predictors_ in a model.
#' @param trained A logical to indicate if the step is trained or not, usually by calling [prep()].
#' @param num_comp The number of principal components to retain. Default is 2.
#' @param options A list of additional parameters to be passed to the pca function.
#' @param res The result of the [pcaMethods::pca] function.
#' @param columns Character vector of the columns that will be transformed.
#' @param skip A logical. Should the step be skipped when the
#'  recipe is baked by [bake()]? While all operations are baked
#'  when [prep()] is run, some operations may not be able to be
#'  conducted on new data (e.g. processing the outcome variable(s)).
#'  Care should be taken when using `skip = TRUE` as it may affect
#'  the computations for subsequent operations.
#' @param id A character string that is unique to this step to identify it.
#'
#' @export
step_ppca <- function(
  recipe,
  ...,
  role = NA,
  trained = FALSE,
  num_comp = 2,
  options = list(method = "ppca"),
  res = NULL,
  columns = NULL,
  keep_original_cols = FALSE,
  skip = FALSE,
  id = recipes::rand_id("ppca")
  ) {
  
  recipes::recipes_pkg_check(required_pkgs.step_ppca())

  recipes::add_step(
    recipe, 
    step_ppca_new(
      terms = rlang::enquos(...),
      role = role,
      trained = trained,
      num_comp = num_comp,
      options = options,
      res = res,
      columns = columns,
      keep_original_cols = keep_original_cols,
      skip = skip,
      id = id
    )
  )
}

step_ppca_new <-
  function(terms, role, trained, num_comp, options, res, columns, keep_original_cols, skip, id) {
    recipes::step(
      subclass = "ppca",
      terms = terms,
      role = role,
      trained = trained,
      num_comp = num_comp,
      options = options,
      res = res,
      columns = columns,
      keep_original_cols = keep_original_cols,
      skip = skip,
      id = id
    )
  }

#' @export
prep.step_ppca <- function(x, training, info = NULL, ...) {
  col_names <- recipes::recipes_eval_select(x$terms, training, info)
  recipes::check_type(training[, col_names], types = c("double", "integer"))

  if (is.null(x$num_comp)) {
    num_comp <- 2
  } else if (x$num_comp > length(col_names)) {
    rlang::warn("num_comp is greater than the number of columns in the data. Setting num_comp to the number of columns in the data.")
    num_comp <- length(col_names)
  } else {
    num_comp <- x$num_comp
  }

  if (x$num_comp > 0 && length(col_names) > 0) {
    prc_call <- rlang::expr(pcaMethods::pca(
      as.matrix(training[, col_names]), nPcs = num_comp
      ))

    prc_call <- rlang::call_modify(prc_call, !!!x$options)

    res <- eval(prc_call)
  } else {
    res <- NULL
  }

  step_ppca_new(
    terms = x$terms,
    trained = TRUE,
    role = x$role,
    options = x$options,
    res = res,
    skip = x$skip,
    columns = col_names,
    keep_original_cols = recipes::get_keep_original_cols(x),
    num_comp = num_comp,
    id = x$id
  )
}

#' @export
bake.step_ppca <- function(object, new_data, ...) {
  recipes::check_new_data(object$columns, object, new_data)

  x_scaled <- pcaMethods::prep(
    as.matrix(new_data),
    scale = object$res@scale,
    center = object$res@center
  )

  pca_vars <- rownames(object$res@loadings)

  # num_comps should always be the same as the column dimension of loadings,
  # since pcaMethods::pca only returns the first num_comp components
  pcomps <- x_scaled[, pca_vars] %*% object$res@loadings[, 1:object$num_comp]
  new_data <- cbind.data.frame(new_data, tibble::as_tibble(pcomps))
  new_data <- recipes::remove_original_cols(new_data, object, pca_vars)

  new_data <- tibble::as_tibble(new_data)
  return(new_data)
}

#' @export
print.step_ppca <- function(x, width = max(20, options()$width - 35), ...) {
  title <- "Probabilistic Principal Component Analysis"
  recipes::print_step(x$columns, x$terms, x$trained, title, width)
  invisible(x)
}

#' @export
tidy.step_ppca <- function(x, ...) {
  if (recipes::is_trained(x)) {
    tibble::tibble(
      term = x$columns,
      value = x$res@loadings[, 1:x$num_comp]
    )
  } else {
    tibble::tibble(
      term = x$columns,
      value = NA_real_
    )
  }
}

#' @export
required_pkgs.step_ppca <- function(x, ...) {
  c("pcaMethods")
}