#' Calculate variable importance
#'
#' Calculates the variable importance for all features for a given machine
#' learing algorithm.
#'
#' @param slData An slData object.
#'
#' @param slMethod A character string specifying the machine learning algorithm
#'   that will be used for classification. The current options are: "rf" -
#'   random forest, "lsvm" - linear support vector machine, "psvm" - polynomial
#'   support vector machine, "rsvm" - radial basis support vector machine,
#'   "logistic" - logistic regression, "loglasso" - logistic regression with
#'   LASSO, "multi" - multinomial regression, and "multilasso" - multinomial
#'   regression with LASSO, "gbtree" - gradient boosting trees, "knn" - k nearest neighbors.
#'
#' @param task A string specifying the type of task, either "classification" or "regression".
#'   If NULL, will be inferred from the response type of the slData object.
#'
#' @param cvMethod A character string specifying the type of cross validation
#'   that will be used. There are only two options "kfcv" for K-fold cross
#'   validation and "loocv" for leave-one-out cross validation.
#' 
#' @param return_cv A logical value specifying whether to return the cross
#'  validation results.
#'
#' @param fdata_use A character string or vector of character strings specifying any
#'  columns in f_data to use as extra features.  Defaults to NULL.
#'  
#' @param nFolds An integer specifying the number of cross validation folds.
#'
#' @param pTest A numeric value specifying the proportion of samples to us
#'  when creating the test set.
#'  
#' @param seed Value for random seed usage
#' 
#' @param grid Integer of levels to test per tuning parameter or vector of 
#' values to test per tuning parameter
#' 
#' @param ... Additional arguments to pass to the model, e.g. you can pass
#' \code{penalty = tune::tune()} alongside \code{slMethod = loglasso} to tune
#' the penalty parameter.
#' 
#' @return An slRes object with a var_import attribute that contains the
#'   variable importance for each feature.
#'
#' @author Evan A Martin
#'
#' @export
#'
variable_importance <- function(slData, slMethod = "rf", task = NULL, cvMethod = "kfcv", return_cv = TRUE,
                              fdata_use = NULL, nFolds = 10, pTest = 0.2, model=NULL, dataRecipe=NULL, 
                              seed = 1024, grid = 5, ...) {
  # 0. Preliminaries -----------------------------------------------------------

  # Check all the things.
  sup_preflight(
    slData = slData,
    slMethod = slMethod,
    cvMethod = cvMethod,
    nFolds = nFolds,
    pTest = pTest,
    task = task
  )

  # 1. Create the model -------------------------------------------------------
  
  # Specify the model, engine, and ML type (e.g., classification or
  # regression). The model will be applied later to the training data.
  task = sup_check_task(slData, task)
  the_model <- if (is.null(model)) sup_model(slMethod, task = task, ...) else model
  the_model <- sup_check_model(the_model, slData)

  if (the_model$mode == "regression") {
    response_type = "continuous" 
  } else {
    response_type = "categorical"
  }
  
  # 2. Data transform ----------------------------------------------------------

  # Transpose the data so the biomolecules appear across the columns. This is
  # necessary because tidymodels expects the features (e.i., the biomolecules)
  # to appear in the columns of the data matrix.
  the_df <- sup_data(slData, response_type = response_type, fdata_use = fdata_use)

  # 3. Split the data --------------------------------------------------------

  # NOTE: The data may not actually be split depending on the user's input. If
  # a test set is not created the entire data matrix is used as the training
  # data.
  
  splits <- data_splitter(the_df, nFolds, pTest, seed)
  the_train <- splits$the_train
  the_test <- splits$the_test
  nFolds <- splits$nFolds
  the_split <- splits$the_split

  # We use a recipe -> workflow -> cvfit method. Using a recipe is needed to
  # prevent errors arising from using formulae with large numbers of predictors.
  rec <- if(is.null(dataRecipe)) {
    recipes::recipe(the_train) |> 
      recipes::update_role(everything()) |> 
      recipes::update_role(response, new_role='outcome')
  } else dataRecipe
  
  wflow <- workflows::workflow() |> 
    workflows::add_model(the_model) |> 
    workflows::add_recipe(rec)
  
  # 4. Cross validation --------------------------------------------------------

  if(isTRUE(nFolds > 0)) {
    if (nFolds > dim(the_train)[1]) {
      warning("The number of cross validation folds is greater than the number of samples.  Setting nFolds to the number of samples.")
      nFolds <- dim(the_train)[1]
    }
    
    the_fold <- sup_cv_folds(
      trainData = the_train,
      slMethod = slMethod,
      cvMethod = cvMethod,
      nFolds = nFolds
    )
  } else {
    the_fold <- NULL
  }

  # 5. Fit the model -----------------------------------------------------------

  fit_res <- sup_fit(
    trainData = the_train,
    workflow = wflow,
    folds = the_fold,
    grid = grid
  )

  the_fit <- fit_res$fit
  the_cv_hp <- fit_res$tune
  the_cv <- the_cv_hp
  
  if (!is.null(the_fold)) {
    if (is.null(the_cv_hp)) {
      the_cv <- the_fit |> tune::fit_resamples(the_fold)
    }
  } else {
    the_cv <- NULL
  }

  # 6. Model prediction --------------------------------------------------------

  the_pred_train <- train_pred(
    fit = the_fit,
    trainData = the_train
  )

  if (pTest != 0) {
    the_pred_test <- test_pred(
      the_fit,
      the_test
    )
  } else {
    the_pred_test <- NULL
  }

  cv_info = list(
    cv_res = the_cv,
    cv = cvMethod,
    n_folds = nFolds
  )

  # 7. Variable importance -----------------------------------------------------

  # Calculate the variable importance for each feature. The variable importance
  # will be used later to select a subset of all features. The selected features
  # will be used to create an "average" model. This model will be used on the
  # test data (if it exists) and on the training data to compute the performance
  # metrics.
  the_vi <- calc_var_import(
    fit = the_fit,
    slMethod = slMethod
  )

  return(
    structure(
      the_fit,
      cv_info = cv_info,
      hp_info = the_cv_hp,
      fit_info = list(
        method = slMethod,
        prop_test = pTest,
        data_split = if (pTest != 0) the_split else NULL,
        task = task
      ),
      feature_info = attr(slData, "feature_info"),
      vi_info = the_vi,
      prediction_test = the_pred_test,
      prediction_train = the_pred_train,
      class = c("slRes", "slRes.vi", "workflow")
    )
  )
}

#' Perform cross-validation on 

#' Classify data with a given machine learning algorithm
#'
#' Trains and tests a model with the option to also perform feature selection
#' (when an slRes object is also provided).
#'
#' @param slData An slData object.
#'
#' @param slRes An slRes object created by the \code{variable_importance}
#'   function. This argument is optional. If NULL (the default) no feature
#'   selection is performed.
#'
#' @param slMethod A character string specifying the machine learning algorithm
#'   that will be used for classification. The current options are: "rf" -
#'   random forest, "lsvm" - linear support vector machine, "psvm" - polynomial
#'   support vector machine, "rsvm" - radial basis support vector machine,
#'   "logistic" - logistic regression, "loglasso" - logistic regression with
#'   LASSO, "multi" - multinomial regression, "multilasso" - multinomial
#'   regression with LASSO, "gbtree" - gradient boosting trees, "pls" - partial
#'   least-squares.
#'
#' @param task A string specifying the type of task, either "classification" or "regression".
#'   If NULL, will be inferred from the response type of the slData object.
#' 
#' @param cvMethod A character string specifying the type of cross validation
#'   that will be used. There are only two options "kfcv" for K-fold cross
#'   validation and "loocv" for leave-one-out cross validation.
#'
#' @param fdata_use A character string or vector of character strings specifying any
#'  columns in f_data to use as extra features.  Defaults to NULL.
#'
#' @param nFolds An integer specifying the number of cross validation folds.
#'
#' @param pTest A numeric value specifying the proportion of samples to use
#' when creating the test set.
#'
#' @param viThreshold A numeric value specifying the cutoff for the variable
#'   importance. Only the features with a variable importance value above the
#'   threshold will be kept.
#'   
#' @param seed Value for random seed usage
#' 
#' @param grid Integer of levels to test per tuning parameter or vector of 
#' values to test per tuning parameter
#' 
#' @param ... Additional arguments to pass to the model, e.g. you can pass 
#' \code{penalty = tune::tune()} alongside \code{slMethod = loglasso} 
#' to tune the penalty parameter.
#'
#' @return An slRes object.
#'
#' @author Evan A Martin
#'
#' @export
#'
fit <-
  function(slData,
           slRes = NULL,
           slMethod = "rf",
           task = NULL,
           cvMethod = "kfcv",
           fdata_use = NULL,
           dataRecipe = NULL,
           model = NULL,
           nFolds = 10,
           pTest = 0.2,
           return_cv = FALSE,
           viThreshold = NULL,
           seed = 1024,
           grid = 5,
           ...) {
    
  # 0. Preliminaries -----------------------------------------------------------

  # Check the slRes object. If it is present the remaining arguments will be
  # ignored (slMethod, cvMethod, nFolds, and pTest) because they are stored in
  # the slRes object and will be used instead of the actual inputs. We do this
  # because we want to use all the same settings for the final fit/prediction as
  # with the feature selection step.
  if (!is.null(slRes)) {
    # Check if slRes is the appropriate class.
    if (!inherits(slRes, "slRes")) {
      stop("The input to slRes must be an slRes object.")
    }

    # Make sure the vi_info attribute is present.
    if (is.null(attr(slRes, "vi_info"))) {
      stop(
        paste("The vi_info attribute must not be null. Run the",
          "variable_importance function to populate this attribute.",
          sep = " "
        )
      )
    }

    message("Feature selection will be performed.  Provided slMEthod, cvMethod, nFolds, and pTest arguments will be overwritten by attributes in the slRes object.")

    slMethod <- slRes %>%
      attr("fit_info") %>%
      `$`("method")
    cvMethod <- slRes %>%
      attr("cv_info") %>%
      `$`("cv")
    nFolds <- slRes %>%
      attr("cv_info") %>%
      `$`("n_folds")
    pTest <- slRes %>%
      attr("fit_info") %>%
      `$`("prop_test")
  } else {
    # Check all the things.
    sup_preflight(
      slData = slData,
      slMethod = slMethod,
      cvMethod = cvMethod,
      nFolds = nFolds,
      pTest = pTest,
      task = task
    )
  }

  # Idiot proof the viThreshold argument. (Hopefully!)
  if (is.null(slRes) && !is.null(viThreshold)) {
    stop(
      "viThreshold cannot be specified if slRes is NULL."
    )
  }

  if (!is.null(viThreshold)) {
    if (length(viThreshold) != 1) {
      stop("viThreshold must have length one.")
    }

    if (!is.numeric(viThreshold)) {
      stop("viThreshold must be numeric.")
    }

    if (viThreshold < 0) {
      stop("viThreshold cannot be less than 0")
    }

    if (viThreshold > max(attr(slRes, "vi_info")$var_import)) {
      stop(
        paste("viThreshold cannot be greater than the largest variable",
          "importance value.",
          sep = " "
        )
      )
    }
  }

  # 1. Create the model --------------------------------------------------------
  
  # Specify the model, engine, and ML type (e.g., classification or
  # regression). The model will be applied later to the training data.
  task = sup_check_task(slData, task)
  the_model <- if (is.null(model)) sup_model(slMethod, task = task, ...) else model
  the_model <- sup_check_model(the_model, slData)
  
  if (the_model$mode == "regression") {
    response_type = "continuous" 
  } else {
    response_type = "categorical"
  }
  
  if (is.null(attributes(slData)$response_info[[response_type]])) {
    stop(sprintf("Your model was specified to perform %s but did not find the appropriate type of response (%s)", the_model$mode, response_type))
  }
  
  # 2. Data transform ----------------------------------------------------------

  # Transpose the data so the biomolecules appear across the columns. This is
  # necessary because tidymodels expects the features (e.i., the biomolecules)
  # to appear in the columns of the data matrix.
  the_df <- sup_data(slData, response_type = response_type, fdata_use = fdata_use)

  # 3. Split the data --------------------------------------------------------

  splits <- data_splitter(the_df, nFolds, pTest, seed)
  the_train <- splits$the_train
  the_test <- splits$the_test
  nFolds <- splits$nFolds
  the_split <- splits$the_split
  
  # If the slRes attribute is not NULL select features based on the variable
  # importance.
  if (!is.null(slRes)) {
    # 3.1. Select features ---------------
    
    set.seed(seed)

    the_besties <- select_ftrs(
      vi_scores = attr(slRes, "vi_info"),
      threshold = viThreshold
    )

    # warn about low feature count
    if (length(the_besties) < 2) {
      warning("Fewer than two features returned by feature selection.  Some engines like 'glmnet' require at least two features.  Consider lowering viThreshold or training with all features.")
    }

    # 3.2. Subset train/test data ---------------

    if (pTest != 0) {
      the_test <- the_test %>%
        dplyr::select(
          dplyr::all_of(c(the_besties, "response"))
        )
    }

    the_train <- the_train %>%
      dplyr::select(
        dplyr::all_of(c(the_besties, "response"))
      )
  } else {
    
    
    splits <- data_splitter(the_df, nFolds, pTest, seed)
    
    the_train <- splits$the_train
    the_test <- splits$the_test
    nFolds <- splits$nFolds
    the_split <- splits$the_split
    
  }

  # Fit the model -------------------------------------------------------------

  # We use a recipe -> workflow -> cvfit method. Using a recipe is needed to
  # prevent errors arising from using formulae with large numbers of predictors.
  rec <- if(is.null(dataRecipe)) {
    recipes::recipe(the_train) |>
      recipes::update_role(dplyr::everything()) |>
      recipes::update_role(response, new_role='outcome')
  } else dataRecipe
  
  wflow <- workflows::workflow() |>
    workflows::add_model(the_model) |>
    workflows::add_recipe(rec)

  # Cross validation 
  if(isTRUE(nFolds > 0)) {
    if (nFolds > dim(the_train)[1]) {
      warning("The number of cross validation folds is greater than the number of samples.  Setting nFolds to the number of samples.")
      nFolds <- dim(the_train)[1]
    }
    
    the_fold <- sup_cv_folds(
      trainData = the_train,
      slMethod = slMethod,
      cvMethod = cvMethod,
      nFolds = nFolds
    )
  } else {
    the_fold <- NULL
  }
  
  # Fit the model
  fit_res <- sup_fit(
    trainData = the_train,
    workflow = wflow,
    folds = the_fold,
    grid = grid
  )

  the_fit <- fit_res$fit
  the_cv_hp <- fit_res$tune
  the_cv <- the_cv_hp
  
  # get cv results
  if (!is.null(the_fold)) {
    # if we tuned, we should already have a cv result, otherwise compute one
    if (is.null(the_cv)) {
      the_cv <- the_fit |> tune::fit_resamples(the_fold)
    }
  } else {
    the_cv <- NULL
  }

  # Model prediction: train ---------------------------------------------------

  the_pred_train <- train_pred(
    fit = the_fit,
    trainData = the_train,
    slMethod = slMethod
  )

  # Model prediction: test ----------------------------------------------------

  if (pTest != 0) {
    the_pred_test <- test_pred(
      the_fit,
      the_test
    )
  }

  cv_info = if(return_cv) list(
    cv_res = the_cv,
    cv = cvMethod,
    n_folds = nFolds
  ) else NULL

  return(
    structure(
      the_fit,
      cv_info = cv_info,
      hp_info = the_cv_hp,
      fit_info = list(
        method = slMethod,
        selected_features = if (!is.null(slRes)) the_besties else NULL,
        prop_test = pTest,
        data_split = if (pTest != 0) the_split else NULL,
        task = task
      ),
      feature_info = attr(slData, "feature_info"),
      prediction_test = if (pTest != 0) the_pred_test else NULL,
      prediction_train = the_pred_train,
      class = c("slRes", "workflow")
    )
  )
}

# Helper functions -------------------------------------------------------------

# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
# Some of the following functions start with sup_ for supervised. All of the
# following functions are wrapper functions for the different parts of the
# tidymodels workflow. These wrapper functions exist because two functions
# (variable_importance and run_model) follow the same workflow and return the same
# object (slRes). However, in the variable_importance function there is an
# additional step to calculate the variable importance. The variable importance
# will be used to select a subset of features before running the final model.
# Having wrapper functions makes it so we only have to change code in one place
# when we make updates.
# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!
# #!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!

sup_check_model <- function(model, slData) {
  if (!inherits(model, "model_spec")) {
    stop("Model must be a 'model_spec' object.")
  }

  if (is.null(model$mode) || !(model$mode %in% c("classification", "regression"))) {
    stop("Model must have either classification of regression mode set")
  } else {
    if (model$mode == "classification") {
      if (is.null(attributes(slData)$response_info$categorical)) {
        stop("Your model was specified to perform classification but no categorical response variable was found in slData")
      }
    } else if (model$mode == "regression") {
      if (is.null(attributes(slData)$response_info$continuous)) {
        stop("Your model was specified to perform regression but no continuous response variable was found in slData")
      }
    }
  }

  return(model)
}

sup_check_task <- function(slData, task) {
  if (!is.null(task)) {
    if (!(task %in% c("classification", "regression"))) {
      stop("task must be either 'classification' or 'regression'")
    } else if (task == "classification") {
      if (is.null(attributes(slData)$response_info$categorical)) {
        stop("You specified to perform classification but no categorical response variable was found in slData")
      }
    } else if (task == "regression") {
      if (is.null(attributes(slData)$response_info$continuous)) {
        stop("You specified to perform regression but no continuous response variable was found in slData")
      }
    }
  } else {
    if (!is.null(attributes(slData)$response_info$categorical)) {
      message("No task specified.  Setting to 'classification'")
      task = "classification"
    } else if (!is.null(attributes(slData)$response_info$continuous)){
      message("No task specified.  Setting to 'regression'")
      task = "regression"
    } else {
      stop("No response variable found in slData")
    }
  }

  return(task)
}

sup_preflight <- function(slData, slMethod, cvMethod, nFolds, pTest, task) {
  # Check if slData is the appropriate class.
  if (!inherits(slData, "slData")) {
    stop("The input to slData must be an slData object.")
  }

  # Check if slMethod is one of the acceptable methods. The acceptable_sl_sup vector
  # is stored internally. The file (acceptable_methods.R) that created the data
  # can be found in the data-raw directory.
  if (!slMethod %in% acceptable_sl_sup) {
    stop(
      paste("The input to slMethod is not an acceptable method. See the",
        "documentation for a list of accepted methods.",
        sep = " "
      )
    )
  }

  checked_task <- suppressMessages(sup_check_task(slData, task))

  # Check if cvMethod is one of the acceptable methods. The acceptable_cv vector
  # is stored internally. The file (acceptable_methods.R) that created the data
  # can be found in the data-raw directory.
  if (!cvMethod %in% acceptable_cv) {
    stop(
      paste("The input to cvMethod is not an acceptable method. See the",
        "documentation for a list of accepted methods.",
        sep = " "
      )
    )
  }

  # Check if nFolds is greater than one and less than the number of samples.
  if (nFolds <= 1 || nFolds >= nrow(slData$f_data)) {
    stop(
      paste("The number of cross validation folds must be greater than 1",
        "and less than the number of samples.",
        sep = " "
      )
    )
  }

  if (!is.numeric(pTest) || length(pTest) != 1) {
    stop(
      paste("The proportion of samples to use when creating the test set",
        "must be a numeric value.",
        sep = " "
      )
    )
  }

  # Check if pTest is less than half of the total number of samples.
  if (pTest < 0 || pTest >= 1) {
    stop(
      paste("The proportion of samples to use when creating the test set",
        "must be greater than or equal to zero and less than 1.",
        sep = " "
      )
    )
  }
}

sup_data <- function(slData, response_type = "categorical", fdata_use = NULL) {
  # Transpose the data so the biomolecules appear across the columns. This is
  # necessary because the biomolecules will be the predictor variables when
  # running the selected machine learning method.
  the_df <- slData$e_data %>%
    dplyr::select(-get_edata_idx(slData)) %>%
    t() %>%
    data.frame()
  
  # We need to check the order of the feature names before renaming the columns.
  order_biomole <- match(
    slData$e_data %>%
      dplyr::pull(get_edata_idx(slData)),
    attr(slData, "feature_info")$names_orig
  )

  # Rename the columns with the friendly names (feature_1, feature_2, ...).
  names(the_df) <- attr(slData, "feature_info")$names_compact[order_biomole]

  # Here we need to check the order of the samples from e_data before adding the
  # class variable to the transposed data frame.
  order_samples <- match(
    slData$e_data %>%
      dplyr::select(-get_edata_idx(slData)) %>%
      names(),
    attr(slData, "response_info")[[response_type]]$raw_values$sample_id
  )

  # Add the class variable to the transposed data.
  the_df$response <- attr(slData, "response_info") %>%
    `[[`(eval(response_type)) %>%
    `$`("raw_values") %>%
    `$`("response") %>%
    `[`(order_samples)
  
  # add predictors from f_data if specified
  if (!is.null(fdata_use)) {
    order_samples <- match(
      slData$f_data[[get_fdata_cname(slData)]],
      attr(slData, "response_info")[[response_type]]$raw_values$sample_id
    )
    
    ordered_f = slData$f_data[order_samples,]
    
    for (fdata_col in fdata_use) {
      if (is.numeric(ordered_f[,fdata_col])) {
        unique_name = make.unique(c(colnames(the_df), fdata_col)) %>% tail(1)
        the_df[unique_name] <- ordered_f[,fdata_col]
      } else {
        # one-hot encode the categorical variable
        # first check it has at least 2 samples in each group
        one_hot_list = list()
        cur_levels = unique(ordered_f[,fdata_col])
        
        for (lvl in cur_levels) {
          one_hot = as.numeric(ordered_f[,fdata_col] == lvl)
          one_hot_list = append(one_hot_list, list(one_hot))
        } 
        
        # for barbarians who somehow created colname collisions
        new_pred_colnames <- paste(fdata_col, cur_levels, sep = "_")
        new_pred_colnames <- make.unique(c(colnames(the_df), new_pred_colnames)) %>%
          tail(length(new_pred_colnames))
        
        onehot_df = do.call(cbind.data.frame, one_hot_list) %>%
          `colnames<-`(new_pred_colnames)
        
        the_df <- cbind.data.frame(the_df, onehot_df)
      }
    }
  }
    
  if (response_type == "categorical") {
    # Convert the class variable to a factor.
    the_df$response <- as.factor(the_df$response)
  } else {
    # Convert the class variable to numeric.
    the_df$response <- as.numeric(the_df$response)
  }

  return(the_df)
}

digest_misc_args <- function(slMethod, model, ...){
  ## Get appropriate parameters for each model
  
  list_args <- list(...)
  
  if(length(list_args) == 0) return(model)
  
  ## getMethod(kernlab:::ksvm, signature = "formula")
  ksvm_fun <- function(subset, na.action = na.omit, scaled = TRUE){
    NULL
  }
  
  ## For new models, investigate with inital model %>% translate to see what engine (package) functions are involved
  # Q: Why these strings? A: Because warning land -- less obnoxious that they are strings now then pulling them later
   funs <- switch(slMethod,
                "rf" = list("parsnip::rand_forest", 
                            "randomForest:::randomForest.default"),
                
                ## getMethod(kernlab:::ksvm, signature = "formula")
                "lsvm" = list("parsnip::svm_linear",
                              "ksvm_fun"),
                "psvm" = list("parsnip::svm_poly",
                              "ksvm_fun"),
                "rsvm" = list("parsnip::svm_rbf",
                              "ksvm_fun"),
                "logistic" = list("parsnip::logistic_reg",
                                  "glmnet::glmnet"),
                "loglasso" = list("parsnip::logistic_reg",
                                  "glmnet::glmnet"),
                "multi" = list("parsnip::multinom_reg",
                               "glmnet::glmnet"),
                "multilasso" = list("parsnip::multinom_reg",
                                    "glmnet::glmnet"),
                "pls" = list("parsnip::pls",
                             "mixOmics::pls"),
                "gbtree" = list("parsnip::boost_tree",
                                "parsnip::xgb_train",
                                "xgboost::xgb.train"),
                "knn" = list("parsnip::nearest_neighbor",
                             "kknn::train.kknn"),
                "lr" = list("parsnip::linear_reg",
                            "stats::lm"),
                "nb" = list("parsnip::naive_Bayes",
                            "klaR::NaiveBayes"),
                "lda" = list("parsnip::discrim_linear",
                             "MASS::lda")
  )

  ## Capture viable arguments
  valid_args <- lapply(funs, function(x) names(formals(eval(parse(text = x)))))
  keep_args <- list_args[names(list_args) %in% unique(unlist(valid_args))]
  
  if(length(keep_args) == 0){
    
    warn_text <- c(
      "No valid model arguments were passed. Try one of the following:",
      paste(funs, sapply(valid_args, toString), sep = " -- "))
    
    warning(
      paste(
        warn_text,
        collapse = "\n"
      )
    )
  } else {
    ## update model
    model <- do.call(parsnip:::set_args, c(list(object = model), keep_args))
  }
  
  model

}

sup_model <- function(slMethod, task = NULL, ...) {
  if (slMethod == "pls") {
    if (!requireNamespace("plsmod", quietly = TRUE)) {
      stop(
        "The plsmod package is required to use the partial least-squares",
        " method. Please install the package and try again."
      )
    }
  } else if (slMethod %in% c("lda")) {
    if (!requireNamespace("discrim", quietly = TRUE)) {
      stop(
        "The 'discrim' package is required to use the linear discriminant",
        " analysis method. Please install the package and try again."
      )
    } else {
      # for some ungodly reason you have to load this...
      library(discrim)
    }
  }
  
  model <- switch(slMethod,
           "rf" = {
              parsnip::rand_forest() %>%
                parsnip::set_engine("randomForest", importance = TRUE)
           },
           "lsvm" = {
             parsnip::svm_linear() %>%
               parsnip::set_engine("kernlab", scaled = TRUE)
           },
           "psvm" = {
              parsnip::svm_poly() %>%
                parsnip::set_engine("kernlab", scaled = TRUE)
           },
           "rsvm" = {
              parsnip::svm_rbf() %>%
                parsnip::set_engine("kernlab", scaled = TRUE)
           },
           "logistic" = {
              parsnip::logistic_reg(penalty = 0, mixture = 0) %>%
                parsnip::set_engine("glmnet")
           },
           "loglasso" = {
              parsnip::logistic_reg(penalty = tune::tune(), mixture = 1) %>%
                parsnip::set_engine("glmnet")
           },
           "multi" = {
              parsnip::multinom_reg(penalty = 0, mixture = 0) %>%
                parsnip::set_engine("glmnet")
           },
           "multilasso" = {
              parsnip::multinom_reg(penalty = tune::tune(), mixture = 1) %>%
                parsnip::set_engine("glmnet")
           },
           "pls" = {
              parsnip::pls() %>%
                parsnip::set_engine("mixOmics")
           },
           "gbtree" = {
              parsnip::boost_tree() %>%
                parsnip::set_engine("xgboost")
           },
           "knn" = {
              parsnip::nearest_neighbor() %>%
                parsnip::set_engine("kknn")
           },
           "lr" = {
             parsnip::linear_reg() %>%
               parsnip::set_engine("lm")
           },
           "nb" = {
             parsnip::naive_Bayes() %>%
               parsnip::set_engine("klaR")
           },
           "lda" = {
             parsnip::discrim_linear() %>%
               parsnip::set_engine("MASS")
           }
    )

  # leaning on tidymodels error handling for incorrect model specifications
  model <- parsnip::set_mode(model, task)

  model <- digest_misc_args(slMethod, model, ...)
  
  return(model)
}

sup_cv_folds <- function(trainData, slMethod, cvMethod, nFolds) {
  response_type <- class(trainData$response)
  
  the_fold <- if (cvMethod == "kfcv") {
    cv_call = rlang::expr(
      rsample::vfold_cv(
        trainData,
        v = nFolds,
        repeats = 1
      )
    )
    
    if (response_type != "numeric") {
      cv_call <- rlang::call_modify(
        cv_call,
        strata = quote(response)
      )
    }
    
    rlang::eval_tidy(cv_call)
  } else {
    rsample::loo_cv(trainData)
  }

  return(the_fold)
}

sup_fit <- function(trainData, workflow, folds, grid = 5, ...) {
  tune_params <- tune::tune_args(workflow)
  
  if (nrow(tune_params) > 0) {
    tune_params <- dplyr::mutate(tune_params, display = sprintf("<%s> from component: %s", name, component))
    if (is.null(folds)) stop(sprintf("folds cannot be NULL if certain parameters are being tuned.  Current tuned parameters:  %s", paste(tune_params$display, collapse = "\n ")))
    
    if(!is.data.frame(grid) && all(is.numeric(grid))){
      
      index <- which.min(purrr::map_int(folds$splits, nrow))
      smallest_fold <- as.data.frame(folds$splits[[index]])
      
      ## Pick params based on the smallest fold for consistency
      params <- tune::extract_parameter_set_dials(workflow)
      
      ## Some params don't autoset range 
      
      if("min_n" %in% params$name){
        if(params$object[[which(params$name == "min_n")]]$range$upper > nrow(smallest_fold)){
          params$object[[which(params$name == "min_n")]]$range$upper <- nrow(smallest_fold)
        }
      }
      
      params <- dials::finalize(
        params, 
        smallest_fold[-ncol(smallest_fold)] ## Remove response col
        )
      
      grid <- dials::grid_regular(
        params,
        levels = grid
      )
    }
    
    the_tune <- workflow |> 
      tune::tune_grid(
        resamples = folds,
        grid = grid
      )

    best_params <- the_tune %>% 
      tune::select_best(metric = "accuracy")
      
    the_fit <- workflow %>% 
      tune::finalize_workflow(best_params) %>%
      parsnip::fit(data = trainData)
  } else {
    the_fit <- workflow |> 
      parsnip::fit(data = trainData)

    # we'll do our own cross-validation on this object if we're not tuning.
    the_tune <- NULL
  }
  
  return(list(fit = the_fit, tune = the_tune))
}

train_pred <- function(fit, trainData, slMethod = NULL) {
  the_prediction = predict_sloper(fit, trainData)
  return(the_prediction)
}

test_pred <- function(fit, test_data) {
  # Run the model on the samples held out for testing.
  the_prediction <- predict_sloper(
    fit = fit,
    data = test_data
  )

  return(the_prediction)
}

predict_sloper <- function(fit, data) {
  mode = parsnip::extract_spec_parsnip(fit)$mode

  if (mode == "regression") {
    type = "numeric"
  } else if (mode == "classification") {
    type = "prob"
  } else {
    warning(sprintf("No prediction method implemented for mode %s", mode))
    return(NULL)
  }

  the_prediction <- fit %>%
    predict(
      data,
      type = type
    )

  if (type == "prob") {
    the_prediction <- the_prediction %>% dplyr::mutate(
      # The following code grabs the name of the variable (the name of the
      # class) that has the largest probability across all the columns (or
      # classes). This code exists because the tidymodels function to determine
      # the predicted class does not always choose the class with the highest
      # probability.
      .pred_class = purrr::pmap(
        dplyr::across(dplyr::starts_with(".pred_")), ~ names(c(...)[which.max(c(...))])
      ),
      .pred_class = stringr::str_remove(.pred_class, ".pred_"),
      response = data$response,
    ) %>%
    dplyr::relocate(.pred_class, .before = dplyr::everything()) %>%
    dplyr::relocate(response, .before = dplyr::everything()) %>% 
    dplyr::mutate(`__SAMPNAMES__` = rownames(data))
  } else if (type == "numeric") {
    the_prediction <- the_prediction %>%
      dplyr::mutate(response = data$response) %>%
      dplyr::relocate(response, .before = dplyr::everything()) %>% 
      dplyr::mutate(`__SAMPNAMES__` = rownames(data))
  }

  return(the_prediction)
}

# Calculate the variable importance depending on the ML method selected.
calc_var_import <- function(fit, slMethod) {
  # get the parsnip fit to avoid accessing fit$fit$fit$fit.....
  parsnip_fit <- tune::extract_fit_parsnip(fit)
  mode = parsnip_fit$spec$mode
  
  if (slMethod == "rf") {
    # Create the variable importance data frame. This will be used to plot the
    # variable importance and set a variable importance threshold.
    if (mode == "regression") {
      metric = "IncNodePurity"
    } else if (mode == "classification") {
      metric = "MeanDecreaseGini"
    } else {
      stop(sprintf("No variable importance method implemented for mode %s with randomForest", mode))
    }
    
    the_vi_df <- data.frame(
      var_name = rownames(parsnip_fit$fit$importance),
      var_import = unname(
        abs(parsnip_fit$fit$importance[, metric])
      )
    )
  } else {
    # Create character vectors that group methods with similar outputs. These
    # vectors will be used to determine which steps to follow when
    # calculating/extracting the variable importance.
    svm_methods <- c("lsvm", "psvm", "rsvm")
    logistic_methods <- c("logistic", "loglasso")
    multinomial_methods <- c("multi", "multilasso")
    pca_methods <- c("pls")

    if (slMethod %in% svm_methods) {
      # Grab the fit object. Elements of this object will be used to calculate
      # variable importance.
      the_fit <- fit$fit$fit$fit # $fit$fit$fit.....$fit$fit....\infty

      # Nab the coefficients and the x matrix to compute variable importance.
      if (inherits(the_fit@coef, 'list')) {
        the_coef <- the_fit@coef[[1]]
      } else {
        the_coef <- the_fit@coef
      }
      
      if (inherits(the_fit@xmatrix, 'list')) {
        the_xmat <- the_fit@xmatrix[[1]]
      } else {
        the_xmat <- the_fit@xmatrix
      }

      # Calculate the variable importance.
      the_vi <- the_coef %*% the_xmat

      # Nab the feature names.
      the_names <- colnames(the_vi)
    } else if (slMethod %in% logistic_methods) {
      tidy_fit <- parsnip::tidy(fit$fit$fit) %>%
        dplyr::filter(term != "(Intercept)")

      # Nab the estimates for each variable.
      the_vi <- tidy_fit %>%
        dplyr::pull(estimate)

      # Snag the feature names.
      the_names <- tidy_fit %>%
        dplyr::pull(term)
    } else if (slMethod %in% multinomial_methods) {
      # Create a tidy fit data frame.
      tidy_fit <- parsnip::tidy(fit$fit$fit) %>%
        # Create one column for each class level. After this step there will
        # be a variable importance value for each class level. For example, if
        # there are three classes each feature will have three variable
        # importance values. We will take the max variable importance value
        # for each feature so there is only as many variable importance values
        # as there are features.
        tidyr::pivot_wider(names_from = class, values_from = estimate) %>%
        dplyr::filter(term != "(Intercept)")

      # Nab the maximum estimate for each variable.
      the_vi <- tidy_fit %>%
        dplyr::select(-term, -penalty) %>%
        # Only keep the max variable importance value for each feature.
        dplyr::mutate(estimate = purrr::pmap_dbl(dplyr::across(.cols = dplyr::everything()), pmax)) %>%
        dplyr::pull(estimate)

      the_names <- tidy_fit %>%
        dplyr::pull(term)
    } else if (slMethod %in% pca_methods) {
      tidy_fit <- parsnip::tidy(fit$fit$fit$fit) %>% filter(.data$type == "predictors")
      tidy_fit <- tidy_fit %>%
        dplyr::group_by(.data$component, .data$term) %>%
        dplyr::summarize(var_import = sum(.data$value^2)) 
        
      the_names <- tidy_fit %>%
        dplyr::pull(.data$term)

      the_vi <- tidy_fit %>%
        dplyr::pull(var_import)
    } else {
      stop(sprintf("No variable importance method implemented for method %s", slMethod))
    }

    the_vi_df <- data.frame(
      var_name = the_names,
      var_import = abs(as.vector(the_vi))
    )
  }

  return(the_vi_df)
}

# The following function applies a threshold selected by the user to the
# variable importance scores. It returns a character vector with the features
# above the threshold.
select_ftrs <- function(vi_scores, threshold) {
  # If the threshold is NULL use the 90th percentile as the threshold.
  if (is.null(threshold)) {
    threshold <- unname(quantile(vi_scores$var_import, probs = 0.9))
  }

  # If the threshold is zero (e.g., when using LASSO), we only want to include
  # the vi scores greater than zero. If the threshold is not zero, we want to
  # keep vi scores greater than or equal to the threshold.
  if (threshold == 0) {
    keepers <- vi_scores %>%
      dplyr::filter(var_import > threshold) %>%
      dplyr::pull(var_name) %>%
      unique()
  } else {
    keepers <- vi_scores %>%
      dplyr::filter(var_import >= threshold) %>%
      dplyr::pull(var_name) %>%
      unique()
  }

  # The order of the features could be changed when creating the keepers object.
  # Change them back to the original order.
  keepers <- vi_scores %>%
    dplyr::pull(var_name) %>%
    intersect(keepers)

  return(keepers)
}
