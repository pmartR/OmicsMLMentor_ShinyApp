#' asdf
#'
#' asdf
#'
#' @param x An imputeData object.
#'
#' @param ... asdf
#'
#' @rdname plot-imputeData
#'
#' @author Evan A Martin
#'
#' @export
#'
plot.imputeData <- function(x, ...) {
  # Preliminaries --------------------------------------------------------------

  # Reformat the imputed data to work with ggplot2.
  tall <- tidyr::pivot_longer(
    data = x,
    cols = dplyr::everything(),
    names_to = "sample"
  )

  # Create a data frame with pre-imputation sample medians. The sample names
  # need to be in their own column for this data to play nicely with ggplot2.
  the_medians <- data.frame(
    sample = names(x),
    medi = attr(x, "original_values") %>%
      purrr::map_dbl(median, na.rm = TRUE) %>%
      unname()
  )

  # Form awe-inspiring plots ---------------------------------------------------

  # Farm boy, make the graph skeleton. As you wish.
  p <- ggplot2::ggplot(tall)

  # Farm boy, make a beautiful box plot. As you wish.
  p <- p +
    ggplot2::geom_boxplot(
      aes(
        x = sample,
        y = value
      )
    )

  # Farm boy, add the pre-imputation medians to the plot. As you wish.
  p <- p +
    ggplot2::geom_point(
      data = the_medians,
      aes(
        x = sample,
        y = medi
      ),
      shape = 17,
      color = "red",
      size = 3
    )

  # Farm boy, color the plots based on the input. As you wish.
  # if (is.null(color_by)) {
  #
  #   p <- p +
  #     ggplot2::geom_boxplot(aes(x = variable,
  #                                        y = value))
  #
  # } else {
  #
  #   p <- p +
  #     ggplot2::geom_boxplot(aes(x = variable,
  #                                        y = value,
  #                                        fill = !!rlang::sym(color_by)))
  #
  # }

  # Farm boy, use my custom sample names in the plot. As you wish.
  # if (use_VizSampNames) p <- p + ggplot2::scale_x_discrete(
  #   labels = omicsData$f_data$VizSampNames,
  #   breaks = unique(omicsData$f_data[, get_fdata_cname(omicsData)])
  # )

  # Farm boy, add the black and white theme to my plot. As you wish.
  # if (bw_theme) {
  #
  #   p <- p + ggplot2::theme_bw() +
  #     ggplot2::theme(strip.background = ggplot2::element_rect(fill = "white"))
  #
  # }

  # Farm boy, group my plots for me. As you wish.
  # if(!is.null(facet_by)) {
  #   if(is.null(facet_cols)) {
  #     p <- p + ggplot2::facet_wrap(formula(paste("~", facet_by)),
  #                                  scales = "free_x")
  #   } else {
  #     p <- p + ggplot2::facet_wrap(formula(paste("~", facet_by)),
  #                                  scales = "free_x",
  #                                  ncol = facet_cols)
  #   }
  # }

  # Farm boy, add thematic elements to my plot. As you wish.
  # p <- p +
  #   ggplot2::theme(
  #     plot.title = ggplot2::element_text(size = title_lab_size),
  #     axis.title.x = ggplot2::element_text(size = x_lab_size),
  #     axis.title.y = ggplot2::element_text(size = y_lab_size),
  #     axis.text.x = ggplot2::element_text(angle = x_lab_angle, hjust = 1),
  #     plot.subtitle = ggplot2::element_text(face = 'italic')
  #   )

  # Farm boy, add labels to my plot. As you wish.
  # p <- p +
  #   ggplot2::ggtitle(title, subtitle) +
  #   ggplot2::xlab(xlabel) +
  #   ggplot2::ylab(ylabel) +
  #   ggplot2::scale_color_discrete(legend_title)


  # Farm boy, add limits to my plot. As you wish.
  # if (!is.null(ylimit)) {
  #   p <- p + ggplot2::scale_y_continuous(limits = ylimit)
  # }

  # Farm boy, make me a plot with beautiful colors. As you wish.
  # if (!is.null(palette)) p <- p +
  #   ggplot2::scale_fill_brewer(name = legend_title,
  #                              palette = palette)

  # Farm boy, make me an interactive plot. As you wish.
  # if (interactive) p <- plotly::ggplotly(p)

  # Farm boy, send my plot into the world to be adored by all. As you wish.
  return(p)
}

#' asdf
#'
#' asdf
#'
#' @param x An object of class transData.
#'
#' @param slData asdf
#'
#' @param threshold asdf
#'
#' @param interval asdf
#'
#' @param ... asdf
#'
#' @rdname plot-transData
#'
#' @author Evan A Martin
#'
#' @export
#'
plot.transData <- function(x, slData, threshold = NULL,
                           interval = NULL, ...) {
  # Preliminaries --------------------------------------------------------------

  # All important and necessary checks are performed in the apply_transformation
  # function. No sense in writing redundant code.
  tempData <- apply_transformation(
    transData = x,
    slData = slData,
    threshold = threshold,
    interval = interval
  )

  # Reformat the transfigured data to work with ggplot2.
  tall <- tidyr::pivot_longer(
    data = tempData,
    cols = dplyr::everything(),
    names_to = "sample"
  )

  # Build beautiful plots ------------------------------------------------------

  # Farm boy, make the graph skeleton. As you wish.
  p <- ggplot2::ggplot(tall)

  # Farm boy, make a beautiful box plot. As you wish.
  p <- p +
    ggplot2::geom_boxplot(
      aes(
        x = sample,
        y = value
      )
    )
}

#' Plots of various performance metrics and variable importance for slRes objects.
#'
#' @param x An object of class slRes.
#'
#' @param plotType For supervised results, one of the following: "variable_importance", "roc_curve",
#'  "confidence_bar", "prediction_bar", "confusion_heatmap", "confidence_scatter".
#'  "predicted_v_actual", the type of plot to create.  For more information about each plot function,
#'  See e.g. `?confusion_heatmap_plot` for the confusion_heatmap option.
#' 
#' @param viThreshold For plotType = "variable_importance".  A threshold for 
#' variable importance.  Plot will have a line drawn at this threshold to help
#' visualize which variables are are deemed 'important'
#'
#' @param pos_class String indicating the positive class.  Must be one of the 
#' classes in the response column of the slRes object.
#'
#' @param interactive Boolean, whether to convert static ggplot to interactive
#' plotly plot.
#'
#' @param ... Extra arguments passed to unsupervised plots.
#'
#' @return A ggplot object.
#'
#' @rdname plot-slRes
#'
#' @author Evan A Martin, Daniel Claborne
#'
#' @importFrom ggplot2 aes
#' 
#' @export
#' 
plot.slRes <- function(x, plotType = "roc_curve", viThreshold = NULL, split = "test",
                       pos_class = NULL, interactive = FALSE, ...) {
  
  # check that the plot is valid for the performed task
  if (!isTRUE(attr(x, "fit_info")$task %in% PLOTS_TO_TASKS[[plotType]])) {
    stop(
      sprintf(
        "The selected plot type is not valid for the performed task (%s).  Valid tasks for %s are [%s]", 
         attr(x, "fit_info")$task, attr(x, "fit_info")$task, 
        TASKS_TO_PLOTS[[attr(x, "fit_info")$task]] |> paste(collapse = ", ")
        )
    )
  }
  
  # Make sure if plotType is "variable_importance" the vi_info attribute exists.
  if (plotType == "variable_importance" && is.null(attr(x, "vi_info"))) {
    stop(
      paste("If plotType is 'variable_importance' the vi_info attribute must",
        "not be NULL. Run the variable_importance function to create an",
        "slRes object with the vi_info attribute.",
        sep = " "
      )
    )
  }

  # If plotType is "roc_curve" and we are using the test split
  if (plotType == "roc_curve" && split == "test" && is.null(attr(x, "prediction_test"))) {
    stop(
      paste("If plotType is 'roc_curve' the prediction_test attribute must",
        "not be NULL. Run the classify function with pTest equal to up to",
        "half of the total number of samples.",
        sep = " "
      )
    )
  }

  # Check if there is a variable importance threshold.
  if (!is.null(attr(x, "vi_info"))) {
    # Set the variable importance threshold to top 10% if the user did not
    # provide their own threshold.
    if (is.null(viThreshold)) {
      # Remove the name from the output of quantile.
      viThreshold <- unname(quantile(attr(x, "vi_info")$var_import, probs = 0.9))
    }
  }

  plot_theme = NULL
  
  pred_df = if(split == "test") {
    attr(x, "prediction_test")
  } else {
    attr(x, "prediction_train")
  }

  if (plotType == "variable_importance") {
    p <- variable_importance_plot(x, viThreshold)
    
    plot_theme = ggplot2::theme(
      axis.line = ggplot2::element_line(color = "black"),
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.border = ggplot2::element_blank(),
      panel.background = ggplot2::element_blank()
    )
    # straight line from x-axis to confidence level to reduce clutter
    # other option to do scatter of binary classification (see chat)
  } else if (plotType == "confidence_bar") {
    p <- confidence_bar_plot(x, pred_df)
    # make this just a geom tile 'confusion matrix'
  } else if (plotType == "prediction_bar") {
    p <- prediction_bar_plot(x, pred_df)
  } else if (plotType == "confusion_heatmap") {
    p <- confusion_heatmap_plot(x, pred_df)
    
    plot_theme <- ggplot2::theme(
      panel.border = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      axis.line = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank()
    )
  } else if (plotType == "confidence_scatter") {
    p <- confidence_scatter_plot(x, pred_df=pred_df, pos_class=pos_class)
    
    plot_theme <- ggplot2::theme(
      axis.title.y = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_blank(),
      axis.ticks.y = ggplot2::element_blank()
    )
  } else if (plotType == "roc_curve") {
    p <- roc_curve_plot(x, pred_df)
    
    plot_theme = ggplot2::theme(
      axis.line = ggplot2::element_line(color = "black"),
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      panel.background = ggplot2::element_blank()
    )
  } else if (plotType == "predicted_v_actual") {
    p <- predicted_v_actual_plot(x, pred_df=pred_df)
  } else {
    stop(
      paste("The plotType argument must be one of the following:",
        paste(names(PLOTS_TO_TASKS), collapse = ", ")
      )
    )
  }
  
  # variable_importance, confidence_bar, prediction_bar, confusion_heatmap, roc_curve, confidence_scatter

  p <- p +
    ggplot2::theme_bw() + 
    plot_theme
  
  if (interactive) {
    if (requireNamespace("plotly", quietly = TRUE)) {
      p <- plotly::ggplotly(p, tooltip = "text")
    } else {
      warning("The plotly package is not installed. The plot will not be interactive.")
    }
  }
  
  return(p)

  # The following is a scatter plot with a variable importance point for each
  # feature and fold. This plot takes forever to render when there are a large
  # number of features and becomes unreadable (just a blob of color).
  # p <- ggplot(data = objects$vi_score,
  #             aes(x = var_name,
  #                 y = var_import,
  #                 color = fold_num)) +
  #   geom_point() +
  #   geom_hline(yintercept = input$vi_threshold) +
  #   theme_bw() +
  #   theme(
  #     axis.text.x = element_text(angle = 90, size = 7),
  #     panel.border = element_blank(),
  #     panel.grid.minor = element_blank(),
  #     panel.background = element_blank(),
  #     axis.line = element_line(colour = "black")
  #   ) +
  #   xlab("") +
  #   ylab("Variable importance") +
  #   scale_color_discrete(
  #     name = "Fold"
  #   )
  # If random forest was used there are no cross validation folds. Remove the
  # legend which displays the point color by fold.
  # if (input$select_sl == "rf") {
  #   p <- p +
  #     theme(legend.position = "none")
  # }
}

#' Plot the variable importance for a given model fit
#' 
#' @param x An object of class slRes
#' 
#' @return A ggplot object, plot of variable importance.
#' 
variable_importance_plot <- function(x, viThreshold = NULL) {
  vi_info = attr(x, "vi_info")
  # Order the features in the order in which they appear in the vi_score data
  # frame. Without this step ggplot reorders the features when plotting.
  vi_info$var_name <- vi_info$var_name %>%
    forcats::fct_inorder()
  
  p <- ggplot2::ggplot(data = vi_info, aes(x = var_import)) +
    ggplot2::geom_histogram(aes(y = ggplot2::after_stat(count) / sum(ggplot2::after_stat(count))),
                            bins = 20
    ) +
    ggplot2::geom_vline(xintercept = viThreshold) +
    ggplot2::coord_flip() +
    ggplot2::xlab("Variable importance") +
    ggplot2::ylab("Proportion") +
    ggplot2::scale_x_continuous(expand = c(0, 0)) +
    ggplot2::scale_y_continuous(expand = c(0, 0))
  
  return(p)
}

#' A function to plot predicted vs actual values from the results of a regression task
#' 
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#' 
#' @return A ggplot object, plot of predicted vs actual values.
#' 
predicted_v_actual_plot <- function(x, pred_df) {
  # compute the rsquared value
  sstot = sum((pred_df$response - mean(pred_df$response))^2)
  ssres = sum((pred_df$response - pred_df$.pred)^2)
  rsquared = 1 - ssres / sstot
  
  p <- ggplot2::ggplot(data = pred_df, aes(x = response, y = .pred)) +
    ggplot2::geom_point() +
    ggplot2::geom_abline(intercept = 0, slope = 1, linetype = "dashed") +
    ggplot2::xlab("Actual") +
    ggplot2::ylab("Predicted") +
    ggplot2::ggtitle(sprintf("Predicted vs Actual. R^2 = %s", prettyNum(rsquared, digits=4))) +
    ggplot2::theme_bw() 
  
  min_val = min(c(min(na.omit(pred_df$response)), min(na.omit(pred_df$.pred))))
  max_val = max(c(max(na.omit(pred_df$response)), max(na.omit(pred_df$.pred))))
  
  # add anchors to the plot to show the diagonal line
  p <- p + 
    ggplot2::geom_point(aes(x = min_val, y = min_val), size = 0) +
    ggplot2::geom_point(aes(x = max_val, y = max_val), size = 0)

  return(p)
}

#' Plot a scatter plot of confidence scores for a classification task
#'
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#'
#' @return A ggplot object, scatter plot of the confidence scores.
#'
confidence_scatter_plot <- function(x, pred_df, pos_class = NULL) {
  pred_df$`__IDX__` <- 1:nrow(pred_df)
  
  if (is.null(pos_class)) {
    pos_class = unique(pred_df$response[!is.na(pred_df$response)])[1]
  } else {
    if (!(pos_class %in% pred_df$response)) {
      stop(
        paste("The positive class must be one of the following:",
              paste(unique(pred_df$response[!is.na(pred_df$response)]), collapse = ", "),
              sep = " "
        )
      )
    }
  }
  
  xvar = paste0(".pred_", pos_class)
  
  n_classes = length(unique(pred_df$response))
  # make the vline move for different numbers of classes
  gt_chance_prob <- 1 / n_classes
  added_vline = ggplot2::geom_vline(xintercept = gt_chance_prob, linetype = "dashed")

  breaks = round(union(pretty(range(c(0,1))), gt_chance_prob), 2)

  # do one-vs-all for > 2 classes
  if (n_classes > 2) {
    new_response <- as.character(pred_df$response)
    other_level = sprintf("Other (%s classes)", n_classes - 1)
    new_response[new_response != pos_class] <- other_level
    pred_df$response <- factor(new_response, levels = c(other_level, as.character(pos_class)))
  }
  
  p <- ggplot2::ggplot(aes(y = `__IDX__`, x = !!rlang::sym(xvar)), data = pred_df) 
  
  p <- p + suppressWarnings(ggplot2::geom_point(aes(color = response, text = `__SAMPNAMES__`))) +
    added_vline +
    ggplot2::scale_x_continuous(limits = c(0, 1), breaks = breaks) +
    ggplot2::scale_color_discrete(name = "Class") +
    ggplot2::xlab(sprintf("Model confidence that sample is of class %s", pos_class)) +
    ggplot2::ggtitle("Model confidence of positive class for all samples")
  
  return(p)
}

#' Plot the ROC curve for a classification task
#' 
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#' 
#' @return A ggplot object, plot of the ROC curve.
#' 
roc_curve_plot <- function(x, pred_df) {
  if (length(unique(pred_df$response)) == 2) {
    # For now grab the first column of predicted probabilities.
    pos_class <- names(pred_df)[3]
    # ROC plot for training set.
    p <- yardstick::roc_curve(pred_df, response, dplyr::all_of(pos_class))
    
    auc_by_level = p %>% 
      dplyr:: mutate(spc_diff = specificity - dplyr::lag(specificity), sens_avg = (sensitivity + dplyr::lag(sensitivity))/2) %>%
      dplyr::summarise(sum(spc_diff*sens_avg, na.rm=T))
  } else {
    # > 2 classes expects all predicted probability names
    pos_class <- names(pred_df)[3:(2+length(unique(pred_df$response)))]
    # ROC plot for training set.
    p <- yardstick::roc_curve(pred_df, response, dplyr::all_of(pos_class))
    
    auc_by_level = p %>% 
      dplyr::group_by(.level) %>% 
      dplyr:: mutate(spc_diff = specificity - dplyr::lag(specificity), sens_avg = (sensitivity + dplyr::lag(sensitivity))/2) %>%
      dplyr::summarise(sum(spc_diff*sens_avg, na.rm=T))
  }
  
  # Farm boy, make the ROC plot beautiful. As you wish.
  p <- p %>%
    ggplot2::ggplot(aes(x = 1 - specificity, y = sensitivity)) +
    ggplot2::geom_path(aes(linetype = "ROC Curve", color = "ROC Curve")) +
    ggplot2::geom_segment(aes(x = 0, y = 0, xend = 1, yend = 1, linetype = "Baseline", color="Baseline")) +
    ggplot2::xlab("False Positive Rate") +
    ggplot2::ylab("True Positive Rate") +
    ggplot2::scale_x_continuous(
      limits = c(-0.01, 1.01),
      expand = ggplot2::expansion(c(0.0025, 0.0025)),
      breaks = c(0, 0.25, 0.50, 0.75, 1),
      labels = c(0, 0.25, 0.50, 0.75, 1)
    ) +
    ggplot2::scale_y_continuous(
      limits = c(-0.01, 1.01),
      expand = ggplot2::expansion(c(0.0025, 0.0025)),
      breaks = c(0, 0.25, 0.50, 0.75, 1),
      labels = c(0, 0.25, 0.50, 0.75, 1)
    ) +
    ggplot2::scale_linetype_manual(name = "", values = c("ROC Curve" = "solid", "Baseline" = "dashed")) +
    ggplot2::scale_color_manual(name = "", values = c("ROC Curve" = "red", "Baseline" = "black"))
  
  # multiclass does one-vs-all
  if (length(unique(pred_df$response)) > 2) {
    p <- p + ggplot2::facet_wrap(~ .level)
  }
  
  return (p)
}

#' Plot barplots of model confidence in a classification task
#' 
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#' 
#' @return A ggplot object, barplot of the confidence scores.
#' 
confidence_bar_plot <- function(x, pred_df) {
  p <- pred_df %>%
    dplyr::mutate(pred_tgt = purrr::map2_dbl(dplyr::row_number(),.pred_class,~pred_df[[.x,sprintf(".pred_%s",.y)]])) %>%
    ggplot2::ggplot(aes(x = reorder(`__SAMPNAMES__`, pred_tgt, decreasing=TRUE), y = pred_tgt, fill=.pred_class)) +
    ggplot2::geom_bar(stat="identity") +
    ggplot2::xlab("Sample (abbreviated)") + ggplot2::ylab("Confidence") +
    ggplot2::scale_x_discrete(label=abbreviate) +
    ggplot2::scale_fill_discrete(name = "Predicted class")
  
  return(p)
}

#' Plot barplots of model predictions in a classification task
#' 
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#' 
#' @return A ggplot object, barplot of the predictions.
#' 
prediction_bar_plot <- function(x, pred_df) {
  p <- pred_df %>% 
    dplyr::mutate(iscorrect = response == .pred_class) %>% 
    ggplot2::ggplot(aes(fill = .pred_class, x = response)) + 
    ggplot2::geom_bar(position='dodge') +
    ggplot2::scale_fill_discrete(name = "Predicted class") +
    ggplot2::xlab("Truth class")

  return(p)
}

#' Plot a confusion heatmap for a classification task
#' 
#' @param x An object of class slRes
#' @param pred_df A data frame with the prediction results
#' 
#' @return A ggplot object, confusion matrix in heatmap form.
#' 
confusion_heatmap_plot <- function(x, pred_df) {
  counts_df <- expand.grid(levels(pred_df$response), levels(pred_df$response))
  
  counts_df <- counts_df %>% dplyr::mutate(
    cell_count = purrr::map2_dbl(Var1, Var2, ~sum(pred_df$response == .x & pred_df$.pred_class == .y))
  )
  
  counts_df$cell_count[counts_df$cell_count == 0] <- NA
  
  # Make this the row proportions
  prop_df <- counts_df %>% dplyr::group_by(Var1) %>% 
    dplyr::mutate(cell_prop = cell_count / sum(cell_count, na.rm=T))
  
  p <- prop_df %>%
    ggplot2::ggplot(aes(x = Var1, y = Var2)) +
    ggplot2::geom_tile(aes(fill = cell_prop)) +
    ggplot2::geom_text(aes(label = ifelse(!is.na(cell_count), sprintf("%s (%s)", cell_count, prettyNum(cell_prop, digits = 2)), ""))) +
    ggplot2::scale_fill_gradient(low = "#c8dde3", high = "steelblue", na.value = "#59131355", 
                                 limits = c(0, 1), name = "Proportion of \n predictions for this class.") +
    ggplot2::xlab("Truth class") +
    ggplot2::ylab("Predicted class") +
    ggplot2::scale_y_discrete(limits = rev(levels(prop_df$Var2))) +
    ggplot2::scale_x_discrete(position='top')
  
  return(p)
}

### Unsupervised Plots

#' Plot results of cluster_unsup on an slData object
#' 
#' @param x An object of class slRes.cluster
#' @param plotType String of the plot to create, options are currently:  "pca", and "dendro".
#' @param ... Additional arguments to pass to the plot function.
#' 
#' @return A ggplot object.
#' 
#' @export
plot.slRes.cluster <- function(x, plotType = "pca", ...) {
  if (plotType == "pca") {
    p <- cluster_pca_plot(x, ...)
  } else if (plotType == "dendro") {
    fit_obj <- workflows::extract_fit_engine(x)
    if (!inherits(fit_obj, "hclust")) stop("For dendrogram plots, you must have used the 'hclust' slMethod.")
    p <- dendrogram_plot(x, ...)
  } else {
    stop("For slRes.cluster objects, the plotType argument must be one of the following: ('pca', 'dendro')")
  }
  
  return(p)
}

#' Plot a dendrogram of a slRes.cluster object fit with slMethod = 'hclust'.
#' 
#' @param x An slRes/workflows object fit with slMethod = 'hclust'.
#' @param slData The slData object used to create the clustering result.  Used when label_obs is TRUE to pull names of samples and biomolecules.
#' @param k Number of clusters to cut the tree at.  Supercedes 'h' if specified.
#' @param h Height to cut the tree at.  Ignored if 'k' is specified.
#' @param color_by Name of a column in slData$f_data to color by.  Requires passing an slData argument.  Defaults to NULL in which case the dendrogram is colored by cluster.
#' @param label_obs A boolean indicating whether to label the observations with their original names.  Must supply slData if TRUE.
#' @param branch.size The size of the branches in the dendrogram.
#' @param label.size The size of the labels in the dendrogram.
#' @param nudge.label The amount to nudge the labels in the y direction.
#' @param expand.y The amount to expand the y axis.
#' @param label.angle The angle of the labels.
#' @param label.hjust The horizontal justification of the labels.
#' @param label.vjust The vertical justification of the labels.
#' @param show.legend A boolean indicating whether to show the legend.
#' @param ... Placeholder for additional arguments.
#' 
#' @return A ggplot object of a dendrogram.
#' 
#' @export
dendrogram_plot <- function(
    x,
    slData = NULL,
    k = NULL, 
    h = NULL, 
    color_by = NULL,
    label_obs = FALSE,
    branch.size = 1,
    label.size  = 3,
    nudge.label = 0.01,
    expand.y = 0.1,
    label.angle = 90,
    label.hjust = 1,
    label.vjust = 0.01,
    show.legend = FALSE,
    ...) {

  fit_obj <- workflows::extract_fit_engine(x)
  
  custom_color <- NULL
  
  if (!is.null(color_by)) {
    if (!inherits(slData, "slData")) {
      stop("If color_by is not NULL, you must supply the slData that was used to create the clustering result")
    }
    
    if (attr(x, "axis") == "samples") {
      #check color_by exists in f_data
      if (!color_by %in% colnames(slData$f_data[,-which(colnames(slData$f_data) == pmartR::get_fdata_cname(slData))])) {
        stop("color_by must be a non-id column in slData$f_data")
      }  
      
      fit_obj$labels = colnames(slData$e_data)[-which(colnames(slData$e_data) == pmartR::get_edata_cname(slData))]
      custom_color <- as.numeric(as.factor(slData$f_data[[color_by]]))
      color_levels <- levels(as.factor(slData$f_data[[color_by]]))
      names(custom_color) <- slData$f_data[[pmartR::get_fdata_cname(slData)]]
    } else if (attr(x, "axis") == "biomolecules") {
      #check color_by exists in e_meta
      if (!color_by %in% colnames(slData$e_meta[,-which(colnames(slData$e_meta) == pmartR::get_edata_cname(slData))])) {
        stop("color_by must be a non-id column in slData$e_meta")
      }
      
      fit_obj$labels = slData$e_data[[get_edata_cname(slData)]]
      custom_color <- as.numeric(as.factor(slData$e_meta[[color_by]]))
      color_levels <- levels(as.factor(slData$e_meta[[color_by]]))
      names(custom_color) <- slData$e_meta[[pmartR::get_edata_cname(slData)]]
    }
  }
  
  hcdata <- dendro_data_k(fit_obj, h = h, k = k, custom_color = custom_color)
  
  ybreaks <- pretty(ggdendro::segment(hcdata)$y, n = 5)
  ymax <- max(ggdendro::segment(hcdata)$y)
  
  if (isTRUE(label_obs)) {
    if (is.null(slData)) stop("if label_obs is TRUE, you must supply the slData that was used to create the clustering result")
    inds = as.numeric(as.factor(hcdata$labels$label))
    aligned_sample_names = slData$f_data[[pmartR::get_fdata_cname(slData)]][inds]
    hcdata$labels$label = aligned_sample_names
  }
  
  plot_data = ggdendro::segment(hcdata)
  
  if (!is.null(custom_color)) {
    plot_data$clust = sapply(plot_data$clust, function(x) if (x > 0) color_levels[x] else NA)
  }
  
  ## branches
  p <- ggplot2::ggplot() +
    ggplot2::geom_segment(
      data = plot_data,
      aes(
        x = x,
        y = y,
        xend = xend,
        yend = yend,
        colour = factor(clust)
      ),
      linetype ="solid",
      lineend = "round",
      show.legend = show.legend,
      size = branch.size
    )
  
  if (!is.null(color_by)) {
    # change the legend title to color_by
    p <- p + ggplot2::labs(color = color_by)
  } else {
    p <- p + ggplot2::labs(color = "Cluster")
  }
  
  ## orientation
  p <- p + ggplot2::scale_x_continuous(breaks = NULL)
  p <- p + ggplot2::scale_y_continuous(breaks = ybreaks)
  nudge.label <- -(nudge.label)

  label_data <- ggdendro::label(hcdata)
  
  if (!is.null(custom_color)) {
    label_data$clust = sapply(label_data$clust, function(x) if (x > 0) color_levels[x] else NA)
  }
  
  p <- p +
    ggplot2::geom_text(
      data = label_data,
      ggplot2::aes(
        x = x,
        y = y,
        label = label,
        colour = factor(clust)
      ),
      angle = label.angle,
      vjust = label.hjust,
      hjust = label.vjust,
      nudge_y = ymax * nudge.label,
      size = label.size,
      show.legend = FALSE
    )
  
  p <- p + scale_color_discrete(breaks = ~ .x[!is.na(.x)])
  
  # colors and limits
  
  ylim <- -round(ymax * expand.y, 1)
  p <- p + ggplot2::expand_limits(y = ylim)
  
  p + ggplot2::labs(x = "Samples", y = "Height")
}

#' Extract plotting dataframe from an 'hclust' fit object.
#' 
#' @param hc An object of class 'hclust' from the 'stats' package.
#' @param k Number of clusters to cut the tree at.  Supercedes 'h' if specified.
#' @param h Height to cut the tree at.  Ignored if 'k' is specified.
#' @param custom_color A named vector mapping cluster names to colors.
#' 
#' @return A list with the following elements:
#' \itemize{
#' \item{segments}{A data frame with the x and y coordinates of the segments of the dendrogram.}
#' \item{labels}{A data frame with information about the leaf node labels}
#' }
#' 
dendro_data_k <- function(hc, k = NULL, h = NULL, custom_color = NULL) {
  
  hcdata    <-  ggdendro::dendro_data(hc, type = "rectangle")
  seg       <-  hcdata$segments
  
  if(!is.null(k)){
    labclust  <-  cutree(hc, k = k)[hc$order]
  } else if(!is.null(h)){
    labclust  <-  cutree(hc, h = h)[hc$order]
  } else {
    message("No k or h specified, using k = 2")
    labclust <- cutree(hc, k = 2)[hc$order]
  }
  
  if(!is.null(custom_color)){
    labclust <- custom_color[names(labclust)]
  }
  
  k <- max(as.numeric(labclust))
  
  segclust  <-  rep(0L, nrow(seg))
  heights   <-  sort(hc$height, decreasing = TRUE)
  height    <-  mean(c(heights[k], heights[k - 1L]), na.rm = TRUE)
  
  for (i in 1:k) {
    xi      <-  hcdata$labels$x[labclust == i]
    consecutive <- split(xi, cumsum(c(1, diff(xi) != 1)))
    for(cons in consecutive){
      idx1    <-  seg$x    >= min(cons) & seg$x    <= max(cons)
      idx2    <-  seg$xend >= min(cons) & seg$xend <= max(cons)
      idx3    <-  seg$yend < height
      idx     <-  idx1 & idx3
      segclust[idx] <- i
    }
  }
  
  idx                    <-  which(segclust == 0L)
  segclust[idx]          <-  segclust[idx + 1L]
  hcdata$segments$clust  <-  segclust
  hcdata$segments$line   <-  as.integer(segclust < 1L)
  hcdata$labels$clust    <-  labclust
  
  hcdata
}



#' Plot the clustering assignments of a model in principal component space
#' 
#' @param x An object of class slRes.cluster
#' 
#' @return A ggplot object, plot of the cluster assignments in principal component space.
#' 
cluster_pca_plot <- function(x, slData = NULL, color_by = NULL, ellipse=FALSE, ...) {
  data_df = workflows::extract_mold(x)$predictors
  
  rec <- recipes::recipe(workflows::extract_mold(x)$predictors) %>% 
    recipes::update_role(tidyselect::everything()) %>%
    unsup_transform('ppca', num_comp = 2) %>% 
    recipes::prep(training = data_df)
  
  data_pcs = recipes::bake(rec, new_data = data_df)
  
  cluster_assn = tidyclust::extract_cluster_assignment(x)
  centroids = tidyclust::extract_centroids(x)
  
  pc_centroids = recipes::bake(rec, new_data = dplyr::select(centroids, -dplyr::one_of('.cluster'))) |>
    dplyr::mutate(cluster = centroids$.cluster) |> 
    dplyr::mutate(type = "centroid")
  
  plot_df = data_pcs |>
    dplyr::mutate(cluster = cluster_assn$.cluster) |> 
    dplyr::mutate(type = "data") |> 
    dplyr::bind_rows(pc_centroids)
  
  
  if (!is.null(color_by)) {
    if (is.null(slData)) {
      warning("The color_by argument was ignored:  If color_by is specified, you must provide the slData object that was used to create the clustering result.")
      .color = NULL
    } else {
      if (isTRUE(attr(x, "axis") == "samples")) {
        f_data <- slData$f_data
        
        if (!(color_by %in% names(f_data))) {
          stop(sprintf("The color_by variable %s is not in the f_data of the slData object", color_by))
        }
        
        reindex <- match(attr(x, "sample_names"), slData$f_data[[pmartR::get_fdata_cname(slData)]])
        f_data <- f_data[reindex,]
        
        plot_df[["__COLORBY__"]] <- c(factor(f_data[[color_by]]), factor(rep("cluster centroid", nrow(pc_centroids))))
      } else if (isTRUE(attr(x, "axis") == 'biomolecules') && !is.null(slData$e_meta)) {
        if (!(color_by %in% names(slData$e_meta))) {
          stop(sprintf("The color_by variable %s is not in the e_meta of the slData object", color_by))
        }
        e_meta <- slData$e_meta
        
        aligned_names = attr(x, "feature_info") %>%
          dplyr::left_join(e_meta, by = c("names_orig" = get_edata_cname(slData)), keep=TRUE)
        
        plot_df['__COLORBY__'] <- c(factor(aligned_names[[color_by]]), factor(rep("cluster centroid", nrow(pc_centroids))))
      }
      
      # weird naming to prevent rare case where they have a color_by column that would overwrite one of the data columns in plot_df
      .color = "__COLORBY__" 
    }
  } else {
    .color = NULL
  }
  
  if (!is.null(.color)) {
    expr = quote(.data[[.color]]) 
  } else {
    expr = quote(factor(cluster))
  }
  
  color_lab = ifelse(is.null(color_by), "Cluster", color_by)
  
  p <- plot_df |> 
    ggplot2::ggplot(ggplot2::aes(x = PC1, y = PC2, color = !!expr, shape = type)) +
    ggplot2::geom_point(size = 3) +
    ggplot2::scale_shape_manual(values = c(3,16)) +
    ggplot2::labs(color = color_lab, shape = "", title = "Cluster Assignments in Principal Component Space")
  
  if (ellipse) {
    p <- p + ggplot2::stat_ellipse(aes(color = factor(cluster))) 
  }
  
  return(p)
}

#' Plot the results of a transformation on an slData object
#' 
#' @param x An object of class slRes.embed.
#' @param plotType String of the plot to create, options are currently:  "scatter".  See details for information on documentation of each plot type.
#' @param ... Additional arguments to pass to the plot function.
#' 
#' @return A ggplot object.
#' 
#' @details This plot function is set up to call a separate function for each plot type.  Documentation for the arguments for these sub-functions (passed by ...) can be found in:
#' \itemize{
#'  \item{plotType = "scatter":  \code{?embed_scatter_plot}}
#' }
#' 
#' 
#' @export
plot.slRes.embed <- function(x, plotType = "scatter", ...) {
  if (plotType == "scatter") {
    p <- embed_scatter_plot(x, ...)
  } else {
    stop("For slRes.embed objects, the plotType argument must be one of the following: ('scatter')")
  }
  
  return(p)
}

#' A scatterplot of the embeddings from embed_unsup
#' 
#' @param x An object of class slRes.embed
#' @param slData The slData object that was passed to the embed_unsup function.
#' @param color_by The variable to color the points by.  If slData is provided, this can be a variable in the f_data or e_meta.  Specify a column in f_data if axis = 'samples' was specified in embed_unsup, and specify a column in e_meta if axis = 'biomolecules' was specified.
#' @param components The principal components to plot, default is c(1,2).
#' @param size The size of the points in the scatter plot.
#' @param alpha The alpha (opacity) value of the points in the scatter plot.  Defaults to 0.5.
#' @param pch The point shape to use in the scatter plot.  Defaults to 21, a filled circle.
#' @param add_stroke A boolean indicating whether to add an opaque stroke to the points, useful when opacity < 1.  Defaults to TRUE.
#' 
#' @return A ggplot object, scatter plot of the embeddings.
#' 
#' @export
embed_scatter_plot <- function(x, slData = NULL, color_by = NULL, components = c(1,2), size = 3, alpha = 0.5, pch = 21, add_stroke = TRUE, ...) {
  if (!inherits(x, "slRes.embed")) {
    stop("x must be an object of class slRes.embed resulting from slopeR::embed_unsup")
  }
  
  if (inherits(x, c("recipe"))) {
    rec = x %>% 
      prep(new_data = x$template)
      
    # some methods, you wanna bake the complete (e.g. imputed) data, not the raw data.
    if (attr(x, "method") %in% c("ppca")) {
      new_data = rec$steps[[length(rec$steps)]]$res@completeObs
    } else {
      new_data = x$template
    }
    embed_df = bake(rec, new_data = new_data)
  } else if (inherits(x, c("tibble", "data.frame"))) {
    embed_df = x
  } else {
    stop("x must be an object of class slRes.embed")
  } 
  
  if (attr(x, "method") == "umap") {
    components = paste0("UMAP", components)
  } else if (attr(x, "method") %in% c("pca", "ppca")) {
    components = paste0("PC", components)
  } else {
    components = colnames(embed_df)[components]
  }
  
  if (!is.null(color_by)) {
    if (is.null(slData)) {
      warning("The color_by argument was ignored:  If color_by is specified, you must provide the slData object that was used to create the embedding result.")
      .color = NULL
    } else {
      if (isTRUE(attr(x, "axis") == "samples")) {
        f_data <- slData$f_data
        
        if (!(color_by %in% names(f_data))) {
          stop(sprintf("The color_by variable %s is not in the f_data of the slData object", color_by))
        }
        
        reindex <- match(attr(x, "sample_names"), slData$f_data[[pmartR::get_fdata_cname(slData)]])
        f_data <- f_data[reindex,]
        
        embed_df[["__COLORBY__"]] <- f_data[[color_by]] 
      } else if (isTRUE(attr(x, "axis") == 'biomolecules') && !is.null(slData$e_meta)) {
        if (!(color_by %in% names(slData$e_meta))) {
          stop(sprintf("The color_by variable %s is not in the e_meta of the slData object", color_by))
        }
        e_meta <- slData$e_meta
        
        aligned_names = attr(x, "feature_info") %>%
          dplyr::left_join(e_meta, by = c("names_orig" = get_edata_cname(slData)), keep=TRUE)
        
        embed_df['__COLORBY__'] <- aligned_names[[color_by]]
      }
      
      # weird naming to prevent rare case where they have a color_by column that would overwrite one of the data columns in embed_df
      .color = "__COLORBY__"
    }
  } else {
    .color = NULL
  }
  
  # check for too many levels
  if (!is.null(.color) && length(unique(embed_df[[.color]])) > 10 && !is.numeric(embed_df[[.color]])) {
    warning("The color_by variable has more than 10 levels, ignoring the color_by option.  Consider using a different variable or reducing the number of levels.")
    .color = NULL
  }
  
  if (!is.null(.color)) {
    expr = quote(.data[[.color]]) 
  } else {
    expr = NULL
  }
  
  # fill or color depending on pch
  if (pch %in% c(21,22,23,24,25)) {
    p <- embed_df |> ggplot2::ggplot(ggplot2::aes(x = .data[[components[1]]], y = .data[[components[2]]], fill = !!expr)) + 
      ggplot2::guides(fill = ggplot2::guide_legend(title = color_by))
  } else {
    p <- embed_df |> ggplot2::ggplot(ggplot2::aes(x = .data[[components[1]]], y = .data[[components[2]]], color = !!expr)) + 
      ggplot2::guides(color = ggplot2::guide_legend(title = color_by))
  }
  
  p <- p +
    ggplot2::geom_point(size = size, alpha = alpha, pch=pch) +
    ggplot2::labs(title = "Embedding Scatter Plot")

  if (add_stroke) {
    p <- p + ggplot2::geom_point(size = size, pch=1)
  }
  
  return(p)
}


#' Remove duplicate lead characters from a vector of strings
#' 
#' @param sample_names A vector of strings
#' @param return_trimmed If TRUE, return the strings with trimmed lead characters, otherwise return the index of the first character that is not the same across all strings.
#' 
#' @return A vector of strings with trimmed lead characters or an integer indicating the index of the first character that is not the same across all strings.
#' 
#' @noRd 
trim_strings <- function(sample_names, return_trimmed=TRUE) {
  min_nchar <- purrr::map_int(sample_names, nchar) |> min()

  trim_lead = 0

  for (i in 1:min_nchar) {
    lead_strings <- purrr::map_chr(sample_names, substring, 1, i) |> unique()
    if (length(lead_strings) > 1) {
      trim_lead = i
      break
    }
  }

  if (return_trimmed) {
    return(purrr::map_chr(sample_names, substring, trim_lead))
  } else {
    return(i)
  }
}
