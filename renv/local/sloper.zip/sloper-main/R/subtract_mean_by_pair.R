#' Subtract a pair's mean from each sample
#' 
#' Performs recipe to subtract paired samples' mean from each sample
#'
#' @param dataset The dataset of class `data.frame` on which to perform the 
#' transformation. 
#' 
#' @param group_col_name the name of the column containing the grouping variable
#' 
#' @param pair_col_name the name of the column containing pair assignments. 
#' This function expects that each pair has a unique identifier.
#' 
#' @return the modified dataset
#' 
#' 
#' #Should I continue to use group_col_name or drop it entirely?





subtract_mean_by_pair <- function(slData, group_col_name, pair_col_name){
  
  featureNameCol <- pmartR::get_edata_cname(slData)
  dataFrame <- t(slData$e_data[,-1])
  dataset <- cbind(slData$f_data[,c(group_col_name, pair_col_name)], dataFrame)
  # names <- sl
  newDataset <- dataset %>%
    # bring grouping column to first column
    dplyr::relocate(!! rlang::sym(group_col_name)) %>%
    # place column with pairing information after grouping column
    dplyr::relocate(!! rlang::sym(pair_col_name), .after = (!! rlang::sym(group_col_name))) %>%
    dplyr::group_by(!! rlang::sym(pair_col_name)) %>%
    dplyr::mutate_at(tidyr::all_of(names(.)[3:(ncol(.))]), function(x){
      pair_mean <- mean(x)
      return(x - pair_mean)
    }) %>%
    dplyr::ungroup() %>%
     dplyr::select(-(!! rlang::sym(pair_col_name))) %>%
    dplyr::select(-(!! rlang::sym(group_col_name)))
    
  
     dataframe <- data.frame(newDataset)
    tDataframe <- data.frame(names(dataframe), t(dataframe))
    colnames(tDataframe) <- c(featureNameCol, slData$f_data$sampleName)
    slData$e_data <- tDataframe
   
    return(slData)
   
} 
  
