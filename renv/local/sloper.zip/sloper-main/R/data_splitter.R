#' Split sup_data result into training and testing data
#'
#' Split sup_data result into training and testing data
#'
#' @param the_df A result of sup_data()
#'
#' @param nFolds An integer specifying the number of cross validation folds.
#'
#' @param pTest A numeric value specifying the proportion of samples to use
#'  when creating the test set.
#'
#' @return A list of resulting training and testing data, as well as a number of folds
#' 
#'
#' @author Evan A Martin and Rachel Richardson
#' 
#' @examples
#' myslData <- as.slData(slopeR::mdata, response_cols = "Condition")
#' the_df <- slopeR:::sup_data(myslData, response_type = "categorical")
#' the_split <- slopeR:::data_splitter(the_df = the_df, nFolds = 5, pTest = 0.2, seed = 1024)
#'
#'
data_splitter <- function(the_df, nFolds, pTest, seed){
  
  
  set.seed(seed)
  
  # NOTE: The data may not actually be split depending on the user's input. If
  # a test set is not created the entire data matrix is used as the training
  # data.
  if (pTest != 0) {
    the_split <- rsample::initial_split(
      the_df,
      prop = 1 - pTest,
      strata = .data$response
    )
    
    the_train <- rsample::training(the_split)
    
    the_test <- rsample::testing(the_split)
  } else {
    the_split <- NULL
    the_train <- the_df
    the_test <- NULL
  }
  
  nTrain = nrow(the_train)
  
  if (is.null(nFolds)) {
    # validation will be approximately 10% of the total data, with a minimum of 2, which we need to do for stability checks:
    valid_floor = floor(nrow(the_train) / 10)
    nValid = max(valid_floor, 2)
    nFolds = ceiling(nTrain / nValid)
    message(sprintf("No nFolds provided, using %d folds for cross validation.", nFolds))
  }
  
  return(
    list(
      the_train = the_train,
      the_test = the_test,
      nFolds = nFolds,
      the_split = the_split
    )
  )
  
}
