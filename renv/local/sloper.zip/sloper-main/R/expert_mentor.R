#' Get list of suggestions for ML algorithms
#' 
#' Returns a ranked list of algorithms based on various scored criteria.  Rules
#' are divided into 'hard rules', which are required for an algorithm to be
#' considered, and 'soft rules', which score/rank the algorithms not filtered
#' out by the hard rules.
#'
#' @param slData An object of class \code{slData}
#' @param supervised Boolean, whether to filter down to supervised or 
#' unsupervised algorithms. (controls hard rule)
#' @param handles_regression Boolean, whether you desire an algorithm that
#' handles regression tasks. (controls hard rule)
#' @param feature_selection Boolean, whether you desire an algorithm that
#' that supports feature selection. (controls soft rule)
#' @param explainability Boolean, whether you desire an algorithm that
#' that supports explainability. (controls soft rule)
#' @param equation Boolean, whether whether you desire an algorithm that
#' that produces a useful, closed-form equation. (controls soft rule)
#' @param correlation Boolean, whether you desire an algorithm that handles
#' correlated predictors well. (controls soft rule)
#' @param prone_to_overfit Boolean, whether you desire an algorithm that is
#' effective in avoiding overfitting. (controls soft rule)
#' @param handles_missingness Boolean, whether you desire an algorithm that
#' handles missing data well. (controls soft rule)
#' @param high_dimensional_data Boolean, whether you desire an algorithm that
#' is effective in high-dimensional data. (controls soft rule)
#' @param handles_outliers Boolean, whether you desire an algorithm that
#' handles outliers well. (controls soft rule)
#' @param handles_small_n Boolean, whether you desire an algorithm that
#' handles smaller sample sizes well. (controls soft rule)
#'
#' @return slSuggestions object containing ranked ML algorithms
#' 
#' @details
#' 
#' Some rules are controled by the values of parameters, such as `handles_regression`.
#' Others are automatically computed from the data and applied, such as the minimum
#' number of levels in the response for a classification algorithm, e.g. logistic
#' regression will not be returned if you provide data with 3 or more levels.
#' 
#' For details on the scoring, see the expert mentor vignette.
#' 
#' @examples 
#' 
#' myslData <- as.slData(slopeR::mdata, response_cols = "Condition")
#' suggestions <- expert_mentor(myslData, explainability = TRUE)
#' summary(suggestions)
#'
#' @export
#' 
expert_mentor <- function(slData, 
    supervised = TRUE, feature_selection = TRUE, samples_per_feature = TRUE, 
    explainability = TRUE, equation = TRUE, correlation = TRUE,
    prone_to_overfit = TRUE, handles_missingness = TRUE, high_dimensional_data = TRUE,
    handles_outliers = TRUE, handles_regression = FALSE, handles_small_n = TRUE) {

  if (!inherits(slData, "slData")) {
    stop("slData must be an object of class slData")
  }

  # Calculate attributes based on the slData object
  n_samps <- attr(slData, "data_info")$num_samps
  class_info <- attr(slData, "response_info")$categorical
  n_levels <- class_info$n_lvls
  n_predictors <- dim(attr(slData, "feature_info"))[1]
  any_is_na <- any(is.na(slData$e_data[, get_edata_cname(slData)]))
  correlation_data_score <- average_correlation(dplyr::select(slData$e_data, - attr(slData, "cnames")$edata_cname ))
  prop_missing <- ifelse(
    inherits(slData, "seqData"), 0, attributes(slData)$data_info$prop_missing)
  mean_outlier_score <- outlier_sensitivity_score(slData)
  

  # set the hard rules (of life)
  hard_rules <- list()
  
  hard_rules[["n_levels"]] <- if (handles_regression) Inf else n_levels
  hard_rules[["n_predictors"]] <- n_predictors
  hard_rules[["any_is_na"]] <- any_is_na
  hard_rules[["supervised"]] <- supervised
  hard_rules[["regression"]] <- handles_regression
  hard_rules[["naive_bayes_cutoff"]] <- n_predictors
  
  # some checks for bad input
  if (hard_rules[['supervised']] == TRUE && is.null(attr(slData, 'response_info'))) {
    warning("You have set supervised to TRUE, but the slData object does not have info on a response/target variable, no algorithms will be suggested.  Specify 'reponse_cols' when creating your slData object to have expert mentor pass this check.")
  }

  # compute soft rules (of life?)
  # value set to zero if the attribute is undesired. If desired, value set at 1 or computed value if req. data.
  soft_rules <- list()
  # Do not require data for input --> value is 1
  soft_rules[["equation"]] <- ifelse(equation, 1, 0)
  soft_rules[["explainability"]] <- ifelse(explainability, 1, 0)
  soft_rules[["feature_selection"]] <- ifelse(feature_selection, 1, 0)
  soft_rules[["prone_to_overfit"]] <- ifelse(prone_to_overfit, 1, 0)
  soft_rules[["high_dimensional"]] <- ifelse(high_dimensional_data, 1, 0)
  soft_rules[["handles_small_n"]] <- ifelse(handles_small_n, 1, 0) # 1 means we actually score based on this, 0 means we dont.
  soft_rules[["n_predictors_per_sample"]] <- ifelse(samples_per_feature, n_samps/ n_predictors, 0)
  soft_rules[["prop_missing"]] <- ifelse(handles_missingness, prop_missing, 0)
  soft_rules[["correlation"]] <- ifelse(correlation, correlation_data_score, 0)
  soft_rules[["outlier_sensitivity"]] <- ifelse(handles_outliers, mean_outlier_score, 0)

  # filter hard rules
  # compare to table of 'hard rules'
  hard_rules_filter <- purrr::map2(algo_rules, names(algo_rules), function(algr, name) {
    algo_filter <- purrr::map(names(slopeR::hard_rule_names), function(rname) {
      rule = algr[['hard']][[rname]]
      
      # Either NULL or PASS_ANY_RULE is an auto pass.  Use PASS_ANY_RULE if possible
      # for filtering purposes on the table.
      
      if (is.null(rule) || identical(rule, slopeR::PASS_ANY_RULE)) {
        return(TRUE)
      }
      
      # situation where the data does not have a certain property
      # in this case we want to say the algorithm cannot be used.
      # e.g. we did not provide a column to determine the number of
      # levels, so any algorithm that requires this cannot be used.
      if (length(hard_rules[[rname]]) == 0) {
        return(FALSE)
      }
      
      compare_func <- ifelse(length(rule) > 1, rule[[2]], `==`)
      
      result <- compare_func(hard_rules[[rname]], rule[[1]])
      
      if (length(result) == 0) {
       return(FALSE)
      } else {
       return(result)
      }
     
    }) %>% setNames(names(slopeR::hard_rule_names))
  })

  # rank soft rules
  soft_rules_filter <- purrr::map2(algo_rules, names(algo_rules), function(algr, name) {
    algo_filter <- purrr::map(names(slopeR::soft_rule_names), function(rname) {
      rule = algr[['soft']][[rname]]
      
      if (is.null(rule)) {
        return(FALSE)
      }

      compare_func <- ifelse(length(rule) > 1, rule[[2]], `&`)

      return(compare_func(soft_rules[[rname]], rule[[1]]))
    }) %>% setNames(names(slopeR::soft_rule_names))
  })

  hard_rules_pass <- purrr::map(hard_rules_filter, function(x) {
    all(unlist(x))
  })

  soft_rules_scores <- purrr::map(soft_rules_filter, function(x) {
    round(sum(unlist(x)), 2)
  })

  out_rules <- soft_rules_scores[which(unlist(hard_rules_pass))]
  class(out_rules) <- c("slSuggestions", "list")
  attr(out_rules, "hard_rules_filter") <- hard_rules_filter
  attr(out_rules, "soft_rules_filter") <- soft_rules_filter
  return(out_rules)
}

#' @export
print.slSuggestions <- function(x, ...) {
  attr_names = names(attributes(x))
  attributes(x)$hard_rules_filter <- NULL
  attributes(x)$soft_rules_filter <- NULL
  print.default(
    x,
    ...
  )
}
