#' Evaluate the stability of cross validation on dataset and model class.
#'
#' Given an slData and slMethod, warns if you have insufficient samples for cross validation and returns two dataframes containing information about the stability of cross-validation.
#' 
#' @param slData An slData object.
#' @param nFolds An integer specifying the number of cross validation folds.  Defaults to NULL, which will use the minimum number of folds required for 2 samples per validation set.
#' @param slMethod A string specifying the supervised learning method.
#' @param task A string specifying the type of task, either "classification" or "regression".  If NULL, will be inferred from the response type of the slData object.
#' @param pTest A number greater than or equal to 0 and less than 1 specifying the proportion of samples to hold out for testing.
#' @param repeats An integer specifying the number of times to repeat the cross validation (using different splits).
#' @param model A model object, if NULL will be created from slMethod and additional arguments.
#' @param seed Value for random seed usage
#' @param ... Additional arguments to pass to the model, e.g. you can pass \code{penalty = tune::tune()} alongside \code{slMethod = loglasso} to tune the penalty parameter.
#' 
#' @return An slCvEval object containing data frames with information about the stability of accuracy and predictions.
#' 
#' @export
evaluate_cv <- function(slData, nFolds = NULL, slMethod = "rf", task = NULL, pTest = 0.2, repeats=5, 
                        model=NULL, seed = 1024, ...) {
  # Specify the model, engine, and ML type (e.g., classification or
  # regression). The model will be applied later to the training data.
  task = sup_check_task(slData, task)
  the_model <- if(is.null(model)) sup_model(slMethod, task = task, ...) else model
  the_model <- sup_check_model(the_model, slData)

  if (the_model$mode == "regression") {
    response_type = "continuous"
  } else {
    response_type = "categorical"
  }

  the_df <- sup_data(slData, response_type = response_type)

  splits <- data_splitter(the_df, nFolds, pTest, seed)
  the_train <- splits$the_train
  the_test <- splits$the_test
  nFolds <- splits$nFolds
  the_split <- splits$the_split

  # This example would use the minimum of user provided and the folds required for 2 samples per validation set
  # nFolds = min(nFolds, nrow(the_df)%/%2)

  # use repeated k-fold cross validation to evaluate stability
  the_fold_init <- rsample::vfold_cv(
        the_train,
        v = nFolds,
        strata = .data$response
      )

  smallest_fold <- the_fold_init$splits %>% 
    purrr::map_int(.f = function(x) length(x$in_id)) %>% 
    min()

  min_ntrain <- slopeR:::method_min_ntrain(slMethod)
  if (smallest_fold < min_ntrain) {
    warning(sprintf("The number of folds (%d) resulted in a split with number of training samples less than the minimum suggested for method %s (minimum suggested: %d, smallest fold: %d).  Consider decreasing the number of test samples or increasing the number of folds.", nFolds, slMethod, min_ntrain, smallest_fold))
  }

  rec <- recipes::recipe(the_train) |> 
      recipes::update_role(dplyr::everything()) |> 
      recipes::update_role(.data$response, new_role='outcome')
  
  wflow <- workflows::workflow() |> 
    workflows::add_model(the_model) |> 
    workflows::add_recipe(rec)

  fit_res <- sup_fit(
    trainData = the_train,
    workflow = wflow,
    folds = the_fold_init
  )

  the_fit <- fit_res$fit

  the_fold_eval <- rsample::vfold_cv(
        the_train,
        v = nFolds,
        repeats = repeats,
        strata = .data$response
      )

  the_cv <- the_fit |> tune::fit_resamples(the_fold_eval, control=tune::control_resamples(save_pred = TRUE))

  # find models with unique test sets, some will have overlapping predictions
  # group by THE PREDICTION, and see what the stability is, will probably have to unnest the predictions

  # 1. mutate a new column with test indices
  # 2. de-dupe rows with identical test indices (if any)
  # 3. unnest test indices dataset
  # 4. group by test indices, and calculate the mean and sd of the prediction

  # do 1
  eval_cv <- the_cv %>% 
    dplyr::mutate(
      test_idx = purrr::map(
        .f = function(x) setdiff(1:nrow(the_train), x$in_id), .x = .$splits
      )
    )

  # filter distinct rows of eval_cv by the column test_idx
  eval_cv <- eval_cv %>% 
    dplyr::distinct(test_idx, .keep_all = TRUE)

  pred_cols <- the_train$response %>% unique() %>% 
    {paste0(".pred_", .)}

  # add an accuracy column
  eval_cv <- eval_cv |> dplyr::mutate(
    accuracy = purrr::map_dbl(
      .f = function(x) x %>% dplyr::filter(.metric == "accuracy") %>% dplyr::pull(.estimate),
      .x = .metrics
    )
  )

  # unnest by test_idx and .predictions
  consistency_df <- eval_cv %>% 
    tidyr::unnest(c(test_idx, .predictions)) %>%
    dplyr::group_by(test_idx)

  # helper to calculate cross enropy
  .tmp_fun <- (function(p) ifelse(p == 0, 0, -log(p, base = 2)))

  # summarize pred_cols by mean
  consistency_df <- consistency_df %>% 
    dplyr::summarize(
      dplyr::across(
        .cols = c(dplyr::one_of(pred_cols)),
        .fns = list(mean = mean, sd = sd)
      ),
      dplyr::across(
        .cols = dplyr::one_of(".pred_class"),
        .fn = list
      ),
      dplyr::across(
        .cols = dplyr::one_of(".pred_class"),
        .fn = list(
          entropy = function(x) {
            t <- table(x)
            p <- t / sum(t)
            -sum(ifelse(p == 0, 0, p * log(p, base=2)))
          }
        )
      ),
      response = dplyr::first(.data$response)
    ) |>
    dplyr::rowwise() |>
    dplyr::mutate(
      pred_entropy = -sum(.tmp_fun(
        dplyr::c_across(dplyr::one_of(paste0(pred_cols, "_mean")))
      ) * (gsub(".pred_", "", pred_cols) == .data$response))
    )

  result <- list(
    "fit" = the_fit,
    "accuracy_df" = eval_cv,
    "consistency_df" = consistency_df
  )

  attr(result, 'pTest') <- pTest
  attr(result, 'nTrain') <- nrow(the_train)
  attr(result, 'nFolds') <- nFolds
  attr(result, 'splits_init') <- the_fold_init
  attr(result, 'splits_eval') <- the_fold_eval
  attr(result, 'sample_names') <- rownames(the_train)
  attr(result, "class") <- "slCvEval"

  return(result)
}

#' Evaluate the stability of cross validation on dataset and model class over a range of the number of folds.
#' 
#' Given an slData, slMethod and a range of values for the number of folds, compute a 'score' for each cross-validation.  This is computed as the average accuracy minus the standard deviation of the accuracy across the folds.  This is repeated for each value of the number of folds, and the results are returned in a list.
#' 
#' @param slData An slData object.
#' 
#' @param nFolds A vector of integers specifying the number of cross validation 
#' folds.
#' 
#' @param slMethod A string specifying the supervised learning method.
#' 
#' @param task A string specifying the type of task, either "classification" or "regression".
#'   If NULL, will be inferred from the response type of the slData object.
#' 
#' @param pTest A number greater than or equal to 0 and less than 1 specifying 
#' the proportion of samples to hold out for testing.
#' 
#' @param repeats An integer specifying the number of times to repeat the cross 
#' validation (using different splits).
#' 
#' @param model A model object, if NULL will be created from slMethod and 
#' additional arguments.
#' 
#' @param parallel T/F for running in parallel
#' 
#' @param seed Value for random seed usage
#' 
#' @param ... Additional arguments to pass to the model, e.g. you can pass 
#' \code{penalty = tune::tune()} alongside \code{slMethod = loglasso} to tune 
#' the penalty parameter.
#' 
#' @return A list containing the scores, means, standard deviations, number of 
#' folds, and cross validation results for each value of the number of folds.
#' 
#' @export
eval_cv_grid <- function(slData, nFolds = NULL,
                         slMethod = "rf", task = NULL,
                         pTest = 0.2, repeats=5,
                         model=NULL, parallel = T,
                         seed = 1024, 
                         ...) {
  
  task = sup_check_task(slData, task)  
  the_model <- if(is.null(model)) sup_model(slMethod, task = task, ...) else model
  
  if (the_model$mode == "regression") {
    response_type = "continuous"
    stop("Regression not yet supported for cross validation evaluation")
  } else {
    response_type = "categorical"
  }

  the_df <- sup_data(slData, response_type = response_type)
  splits <- data_splitter(the_df, nFolds, pTest, seed)
  nFolds <- splits$nFolds

  if(parallel){
    future::plan(multisession)
    
    allres <- furrr::future_map(nFolds, function(nf){
      evaluate_cv(slData, nFolds = nf, 
                  slMethod = slMethod, 
                  pTest = pTest, 
                  repeats = repeats, 
                  model = model, ...)
    })
    
    future::plan(sequential)
  } else {
    
    allres <- purrr::map(nFolds, function(nf){
      evaluate_cv(slData, nFolds = nf, 
                  slMethod = slMethod, 
                  pTest = pTest, 
                  repeats = repeats, 
                  model = model, ...)
    })
    
  }
  
  acc_means <- purrr::map_dbl(allres, function(res) 
    mean(res$accuracy_df$accuracy))
  acc_sds <- purrr::map_dbl(allres, function(res) 
    sd(res$accuracy_df$accuracy))
  
  ce_means <- purrr::map_dbl(allres, function(res) 
    mean(res$consistency_df$pred_entropy))
  ce_sds <- purrr::map_dbl(allres, function(res) 
    sd(res$consistency_df$pred_entropy))

  out <- list(
    "acc_means" = acc_means,
    "acc_sds" = acc_sds,
    "ce_means" = ce_means,
    "ce_sds" = ce_sds,
    "nFolds" = nFolds,
    "cv_results" = allres
  )

  attr(out, "class") <- "slCvGridEval"

  return(out)
}

#' A helper function that determines the minimum number of training samples 
#' suggested for cross validation for a given method.
#' 
#' @param slMethod A character string specifying the machine learning algorithm
#'   that will be used for classification.  See \code{acceptable_sl_sup} 
#'   and \code{acceptable_sl_unsup} for a list of acceptable values.
#' 
#' @return An integer specifying the minimum number of training samples 
#' suggested for cross validation.
#' 
#' @keywords internal
#' 
#' @noRd
method_min_ntrain <- function(slMethod){
  min_cv <- switch(
    slMethod,
    lsvm = 5,
    psvm = 5,
    rsvm = 5,
    multi = 5,
    multilasso = 5,
    logistic = 5,
    loglasso = 5,
    rf = 5,
    kmeans = 5, ## For cluster optimization, might have to snag group stufff
    hclust = NA,
    pca = NA,
    umap = NA,
    gbtree = 5,
    5
  )

  return(min_cv)
}

#' Plot results of cross-validation evaluation
#' 
#' @param x An slCvEval object
#' @param plot_type A string specifying the type of plot to return, either "acc_histogram" or "sample_barplot"
#' 
#' @return A ggplot2 object
#' 
#' @export
plot.slCvEval <- function(x, plot_type = "acc_histogram", ...) {
    plot_type <- match.arg(plot_type, c("acc_histogram", "sample_barplot"))
    
    if (plot_type == "acc_histogram") {
        return(slCv_acc_hist(x, ...))
    } else if (plot_type == "sample_barplot") {
        return(slCv_sample_barplot(x, ...))
    }
}

#' Plot a barplot of the mix of predicted classes for each test sample
#' 
#' @param x An slCvEval object
#' @param ... Placeholder for additional arguments
#'
#' @keywords internal
#'
slCv_sample_barplot <- function(x, ...) {
    df <- x$consistency_df |> 
        tidyr::unnest(.pred_class) |> 
        dplyr::mutate(
          sample_name = as.factor(attr(x, "sample_names")[.data$test_idx]),
          test_idx = as.factor(test_idx)
        )

    # trim duplicate leads of sample names
    df$sample_name <- as.factor(trim_strings(as.character(df$sample_name)))
         
    p <- ggplot2::ggplot(data = df, aes(x = .data$sample_name)) +
        ggplot2::geom_bar(aes(fill = .pred_class), position = "stack") +
        ggplot2::labs(x = "Test Sample Index", y = "Count")

    # rename the legend title
    p <- p + ggplot2::guides(fill = ggplot2::guide_legend(title = "Predicted Class"))

    # rotate and truncate the x-tick labels
    p <- p + ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, hjust = 1, vjust = 0.5))

    p <- p + ggplot2::scale_x_discrete(labels = function(x) stringr::str_trunc(x, 10))

    return(p)
}

#' A histogram of accuracy scores for the cross validation
#' 
#' @param x An slCvEval object
#' @param ... Placeholder for additional arguments
#' 
#' @keywords internal
slCv_acc_hist <- function(x, ...) {
    # plot the accuracy in a histogram with proportions
    p <- x$accuracy_df %>%
        ggplot2::ggplot(aes(x = accuracy)) +
        ggplot2::geom_histogram(bins = 20, aes(y = ggplot2::after_stat(count/sum(count)))) +
        ggplot2::labs(x = "Accuracy", y = "Proportion") +
        ggplot2::labs(title = "Distribution of Accuracy Across Cross Validation Folds")

    return(p)
}

#' Plot results of cross-validation evaluations across a range of the number of folds
#' 
#' @param obj An slCvGridEval object, obtained from \code{eval_cv_grid}
#' @param means A logical specifying whether to plot the mean accuracy for each number of folds
#' @param error_bars A logical specifying whether to plot error bars for the standard deviation of the accuracy for each number of folds
#' 
#' @return A ggplot2 object.  A plot with the accuracy or score on the y axis and number of folds on the x-axis.
#' 
#' @export
plot.slCvGridEval <- function(obj, means=FALSE, error_bars = TRUE, score_type='accuracy') {
  score_type <- match.arg(score_type, c("accuracy", "entropy"))

  if (score_type == "accuracy") {
    df <- data.frame(
      nFolds = obj$nFolds,
      means = obj$acc_means,
      sds = obj$acc_sds
    )

    metric_name = "Accuracy"
  } else if (score_type == "entropy") {
    df <- data.frame(
      nFolds = obj$nFolds,
      means = obj$ce_means,
      sds = obj$ce_sds
    )

    metric_name = "Cross Entropy"
  }

  p <- ggplot2::ggplot(data = df, aes(x = .data$nFolds))
  
  legend_values = character(0)
  legend_labels = character(0)

  p <- p + ggplot2::geom_point(aes(y = .data$sds, color = "blue"))
  legend_values <- c(legend_values, "blue")
  legend_labels <- c(legend_labels, sprintf("%s Variation", metric_name))

  if (means) {
    p <- p + ggplot2::geom_point(aes(y = .data$means, color = "red"))
    legend_values <- c(legend_values, "red")
    legend_labels <- c(legend_labels, sprintf("Mean %s", metric_name))
  }

  # add a legend for the color of the points
  p <- p + ggplot2::scale_color_manual(
    name = "",
    values = legend_values,
    labels = legend_labels
  )

  p <- p + ggplot2::labs(x = "Number of Folds", y = sprintf("Variation in %s", metric_name))

  return(p)
}
