#'
#' Repeated Optimization for Feature Selection (ROFI)
#' 
#' The `rofi()` function implements a feature selection algorithm that uses repeated 
#' randomization and optimization (citation included below). This implementation is 
#' for a single dataset, and is designed to work with data processed using the other slopeR functions. 
#'
#' @param slMethod A character string specifying the machine learning algorithm
#'   that will be used for classification. The current options are: "rf" -
#'   random forest, "lsvm" - linear support vector machine, "psvm" - polynomial
#'   support vector machine, "rsvm" - radial basis support vector machine,
#'   "logistic" - logistic regression, "loglasso" - logistic regression with
#'   LASSO, "multi" - multinomial regression, and "multilasso" - multinomial
#'   regression with LASSO.
#' @param slObject  An slData object
#' @param cvMethod A character string specifying the type of cross validation
#'   that will be used. There are only two options "kfcv" for K-fold cross
#'   validation and "loocv" for leave-one-out cross validation.
#' @param nFolds An integer specifying the number of cross validation folds.
#' @param pairedData Boolean value, TRUE if the data has a paired structure, 
#'  defaults to FALSE. 
#' @param nn integer. The number of times to repeat the optimization in its
#'   entirety
#' @param f_prob numeric greater than 0 and leq 1. The proportion of the full
#'   feature set to initialize the optimization routine
#' @param nu numeric greater than 0 and leq 1. The scale value for feature
#'   acceptance criteria of a difference in AUC values
#' @param max_iter int. Maximum number of iterations to allow in nn iterations
#' @param conv_check int. Number of iterations at which to perform a
#'   convergence check. Typically set to the total number of features
#' @param epsilon numeric greater than 0 and leq 1. AUC convergence threshold,
#'   typically small (< 0.1).
#' @param after_conv_checks int. After the initial convergence check, the
#'   Interval of iterations at which to perform a convergence check
#'  @param pairedCol the column indicating which group each sample belongs to. 
#'  
#'  @references Webb-Robertson, Bobbie-Jo M., Lisa M. Bramer, Sarah M. Reehl, 
#'  Thomas O. Metz, Qibin Zhang, Marian J. Rewers, and Brigitte I. Frohnert.
#'   “ROFI - The Use of Repeated Optimization for Feature Interpretation.” In 2016 
#'   International Conference on Computational Science and Computational Intelligence 
#'   (CSCI), 29–33, 2016. https://doi.org/10.1109/CSCI.2016.0013.



rofi <- function(slMethod, slData, cvMethod, nFolds, pairedData=FALSE, multiRofi= FALSE,
                 nn = 4, f_prob=0.1 , nu=1/100,
                 max_iter=2*nrow(slData$e_data),
                 conv_check=nrow(slData$e_data)+1,
                 epsilon = 0.01, after_conv_checks = 100,
                 
                 verbose=FALSE){

  if (multiRofi == TRUE){
    print('in first if')
    modelObj <- sup_model(as.character(slMethod$model))
    
    dataObj <- sup_data(slMethod$data[[1]], response_type = "categorical")
    # changed nrow -> ncol because these were assigned before sup_model/data, 
    # but now are being assesd after the transformation of edata in sup_data
    max_iter=2*ncol(dataObj)
    conv_check=ncol(dataObj)
    slMethod <- slMethod$model
  }else{
    modelObj <- sup_model(slMethod)
    dataObj <- sup_data(slData, response_type = "categorical")
    
  }
  
  
  
  
  
  if (pairedData==TRUE){
    foldsObj <- rsample::group_vfold_cv(data = dataObj, 
                                        group = pairedCol, 
                                        v = 10, 
                                        repeats=3)
  }else {
    foldsObj <- sup_cv_folds(dataObj, slMethod, cvMethod, nFolds)
    
  }
  
  benchmark_auc <- after_conv_checks
  results <- vector("list", nn)
  total_features <- conv_check - 1
  feature_inds <- seq(from = 1, to = total_features, by = 1)
  feature_map <- data.frame(Feature = names(dataObj %>% 
                                              dplyr::select(-response)), 
                            Position = feature_inds, 
                            stringsAsFactors = FALSE)
  
  for(i in 1:nn){
    # print('inside 1:nn loop')
    aucchecks <- NULL
    
    # Create elements in results list
    results[[i]] <- vector("list",  4)
    names(results[[i]]) <- c("AllAUC", "BestAUC", "f_Vectors","Changed")
    results[[i]]$BestAUC <- rep(NA,max_iter)
    results[[i]]$AllAUC <- rep(NA,max_iter)
    results[[i]]$f_Vectors <- matrix(NA,max_iter,total_features)
    results[[i]]$Changed <- rep(NA,max_iter)
    
    
    #------1. Select a random number of 100*f_prob% features to include in model  
    fveci <- rbinom(total_features, 1, f_prob)
    
    #------2. Do cross validation using randomly chosen features
    # Sometimes choice of included features may yield a model that does not
    # fit. Should re-run this within a while-loop until finds a model that 
    # does fit.
    included_features <- feature_map$Feature[which(fveci==1)]
    
    loop_formula <- as.formula(paste("response ~ ", paste(included_features, collapse = " + ")))
    
    
    wf <- workflow() %>% add_model(modelObj) %>% add_formula(loop_formula)
    wf_fit <- wf %>% fit_resamples(foldsObj)
    
    #----- Retrieve initial AUC------#
    
    # extract AUC
    init_auc <- collect_metrics(wf_fit)$mean[2]
    aucchecks <- init_auc
    
    iter <- 1
    results[[i]]$BestAUC[iter] <- results[[i]]$AllAUC[iter] <- auci <- init_auc
    results[[i]]$f_Vectors[iter,] <- fveci
    print("Auc extraction finished")
    #------3. Repeat until AUC_diff is below some threshold
    auc_diff <- 1
    
    # Create the vector that defines the order in which each features is turned on/off
    # change later to avoid creating a vector of length maxIter...
    if((max_iter-1)<=total_features){
      flip_order <- sample(total_features,max_iter-1,replace = FALSE)
    }else{
      flip_order <- rep(NA,max_iter-1)
      
      for(lazy in 1:floor((max_iter-1)/total_features)){
        flip_order[(1:total_features)+total_features*(lazy-1)] <- sample(total_features)
      }
      flip_order[-c(1:(total_features*lazy))] <- sample(total_features,(max_iter-1)%%total_features,replace=FALSE)
    }
    # prepend a 0 for the first change
    flip_order <- c(0,flip_order)
    results[[i]]$Changed <- flip_order
    
    while(iter < max_iter){
      # print(iter)
      iter <- iter+1
      # print('in iter loop')
      
       # print(iter)
      
      #Step a
      fvecip1 <- fveci
      
      #Step b - flip random feature on or off
      toflip <- flip_order[iter]
      
      fvecip1[toflip] <- 1-fvecip1[toflip]
      
      #Step c - compute AUC with perturbed feature vector
      
      included_features <- feature_map$Feature[which(fvecip1==1)]
      
      iter_formula <- as.formula(paste("response ~ ", paste(included_features, collapse = " + ")))
      
      # Recipe
      wf_iter <- workflow() %>% add_model(modelObj) %>% add_formula(iter_formula)
      wf_fit_iter <- wf_iter %>% fit_resamples(foldsObj)
      
      aucip1 <- iter_auc <- collect_metrics(wf_fit_iter)$mean[2]
      #Step d - compute acceptance prob and flip coin
      # i - acceptance prob
      theta <- min(1,exp((aucip1-auci)/nu))
      results[[i]]$AllAUC[iter] <- aucip1 #Save current AUC to AllAUC
      
      # ii - accept/reject decision decision
      if(theta>runif(1)){
        #Accept - fvec i become fvec i+1
        fveci <- fvecip1
        auci <- aucip1
      }
      
      results[[i]]$BestAUC[iter] <- auci #Only save accepted AUC as BestAUC
      results[[i]]$f_Vectors[iter,] <- fveci
      
      #Step 4 - Check convergence every conv_check step after the first conv_check
      if(iter <= conv_check) {
        dynamic_check <- conv_check
      } else {
        dynamic_check <- after_conv_checks
      }
      #Record the AUC every "benchmark_auc" iterations - don't get why not always recorded
      if(iter%%benchmark_auc==0){
        print("Yes!")
        aucchecks <- c(aucchecks,auci)
        #print(aucchecks)
      }
      # Are we not checking every iter so that there are is a burnout of sorts?
      
      if(iter%%dynamic_check==0){
        all_auc_diff <- diff(aucchecks)
        auc_diff <- abs(all_auc_diff[length(all_auc_diff)])
        if(auc_diff < epsilon){
          #If converged, force iter to kick out of step 3
          stop <- iter
          iter <- Inf
        }
      }
      
    }
    
    #Remove trailing NAs from AllAUC, f_Vectors
    if(!is.finite(iter)){
      results[[i]]$BestAUC <- results[[i]]$BestAUC[1:stop]
      results[[i]]$AllAUC <- results[[i]]$AllAUC[1:stop]
      results[[i]]$f_Vectors <- results[[i]]$f_Vectors[1:stop,]
      results[[i]]$Changed <- results[[i]]$Changed[1:stop]
    }
    
  }
  
  #---- Get Feature Importance and Info -----#
  final_fvecs <- lapply(results, function(nn){
    nn$f_Vectors[nrow(nn$f_Vectors), ]
  })
  
  importance <- data.frame(t(do.call("rbind", final_fvecs)))
  colnames(importance) <- paste("Iteration",1:ncol(importance))
  importance_metric <- rowSums(importance)/ncol(importance)
  importance <- cbind(importance_metric, importance)
  importance <- cbind(feature_map, importance) %>% dplyr::select(-Position)
  
  #---- Get Performance Metrics and Info -----#
  aucs <- vector("list", nn)
  for(i in 1:nn){
    aucs[[i]] <- data.frame(Iteration = i, do.call("cbind", results[[i]]))
  }
  aucs <- do.call("rbind", aucs)
  colnames(aucs)[4:(length(feature_map$Feature)+3)] <- feature_map$Feature 
  
  return(list(importance, results))
  
}


