## code to prepare `expert_mentor` dataset goes here

## Rules table for each of the machine learning methods

hard_rule_names <- list("supervised"="Supervised", 
                        "n_levels"="Min. Levels", 
                        "any_is_na"="Handles Missing Data",
                        "regression"="Handles continuous response",
                        "naive_bayes_cutoff"="Sufficiently few continuous features for Naive Bayes")

soft_rule_names <- list(
  "handles_small_n"="Relative ability to learn from small sample sizes",
  "n_predictors_per_sample"="Handles large number of predictors per sample", 
  "prop_missing"="Proportion Missing",
  "explainability" = "Explainable", 
  "feature_selection"="Performs Feature Selection",
  "equation" = "Output includes Equation",
  "prone_to_overfit"="Prone to Overfitting",
  "correlation"="Handles Correlated Data",
  "high_dimensional"="Handles High Dimensional Data",
  "outlier_sensitivity"="Sensitivity to Outliers"
)

hard_rule_descriptions <- list("supervised"="String. Whether an ML algorithm is supervised or unsupervised. Values are `supervised` and `unsupervised`.",
                               "n_levels"="Integer. The number of classes (levels) needed to run an algorithm.",
                               "any_is_na" ="Boolean. Whether or not the algorithm can handle missing data. If `FALSE`, missingness needs addressed before algorithm is run.",
                               "regression"="Boolean; Whether or not an algorithm can perform a continuous response",
                               "naive_bayes_cutoff"="A check for high feature dimension in Naive Bayes, since we begin to round-to-zero errors when dealing with large numbers of predictors.  We limit the number of features for using Naive Bayes to 100.")

soft_rule_descriptions <- list("handles_small_n"="Float [0-1]. Relative ability of the algorithm to handle small sample sizes",
                               "n_predictors_per_sample"="Float [0-1]. How well an algorithm performs against data with a larger ratio of predictors to observations.",
                               "prop_missing"="Float [0-1]. How well an algorithm performs against data with larger amounts of missing data.",
                               "explainability"="Float [0-1]. How explainable an algorithm is.",
                               "feature_selection"="Boolean. Whether an algorithm performs feature (variable) selection or not.",
                               "equation"="Boolean. Whether or not the output after the algorithm is run includes a closed-form equation.",  
                               "prone_to_overfit"="Float [0-1]. How prone an algorithm is to overfitting. Note that a larger value indicates robustness to overfitting.",
                               "correlation"="Float [0-1]. How robust an algorithm is to data that is correalted. Value is dependent on correlation auto-computed in data.",
                               "high_dimensional"="Float [0-1]. How well an algorithm handles high-dimensional data (i.e. data with a large number of predictors).",
                               "outlier_sensitivity"="Float [0-1]. How robust an algorithm is against data containing outliers.")

# a rule for if we dont care about whether a boolean input to expert mentor is TRUE or FALSE.
PASS_BOOLEAN_RULE = list(TRUE, `<=`) 
PASS_ANY_RULE = list(TRUE, function(x, y) return(TRUE))

algo_rules <- list(
  "lsvm" = list(
    "full_name" = "Linear SVM",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list()),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(0.25, `*`, list("barakat_rule_2010")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0.5, `*`, list("hua_optimal_2005", "ramezan_effects_2021", "reel_using_2021")),
      "high_dimensional" = list(1, `*`, list("Bishop2006PatternRA")),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0, `*`, list("stewart_constructing_2018")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0.5, `*`, list())
    )
  ),
  "psvm" = list(
    "full_name" = "Polynomial SVM",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list()),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(0, `*`, list("barakat_rule_2010")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0.25, `*`, list("hua_optimal_2005", "ramezan_effects_2021", "reel_using_2021")),
      "high_dimensional" = list(1, `*`, list("Bishop2006PatternRA")),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0, `*`, list("stewart_constructing_2018")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0.25, `*`, list())
    )
  ),
  "rsvm" = list(
    "full_name" = "Radial SVM",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list()),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(0, `*`, list("barakat_rule_2010")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0.25, `*`, list("reel_using_2021")),
      "high_dimensional" = list(1, `*`, list("Bishop2006PatternRA")),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0, `*`, list("stewart_constructing_2018")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0.25, `*`, list())
    )
  ),
  "multi" = list(
    "full_name" = "Multinomial Regression",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(3, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0, `*`, list("ellis_when_2022")),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(0.5, `*`, list("ellis_when_2022")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0.75, `*`, list("reel_using_2021")),
      "high_dimensional" = list(0.5, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0, `*`, list("ellis_when_2022")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0, `*`, list("ellis_when_2022"))
    )
  ),
  "multilasso" = list(
    "full_name" = "Multinomial Regression with LASSO",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(3, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.25, `*`, list("christina_when_2022")),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(0.5, `*`, list()),
      "feature_selection" = list(TRUE, `==`, list("christina_when_2022")),
      "handles_small_n" = list(1, `*`),
      "high_dimensional" = list(1, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0.5, `*`, list()),
      "prone_to_overfit" = list(1, `*`, list()),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "logistic" = list(
    "full_name" = "Logistic Regression",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `==`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list("courvoisier_performance_2011")),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(1, `*`, list("hosmer_applied_2000")),
      "feature_selection" = list(0.25, `*`, list()),
      "handles_small_n" = list(0.75, `*`, list("reel_using_2021")),
      "high_dimensional" = list(0.5, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list("noauthor_ibm-logistic_2021", "westreich_propensity_2010")),
      "outlier_sensitivity" = list(0, `*`, list("rousseeuw_robustness_2003", "pregibon_logistic_1981")),
      "prone_to_overfit" = list(1, `*`, list("noauthor_ibm-logistic_2021")),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "loglasso" = list(
    "full_name" = "Logistic Regression with LASSO",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `==`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.25, `*`, list("christina_when_2022")),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(1, `*`, list()),
      "feature_selection" = list(TRUE, `==`, list("christina_when_2022")),
      "handles_small_n" = list(1, `*`),
      "high_dimensional" = list(1, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0.5, `*`, list()),
      "prone_to_overfit" = list(1, `*`, list()),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "rf" = list(
    "full_name" = "Random Forest",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list("buskirk_surveying_2018")),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(0.5, `*`, list("criminisi_decision_2011")),
      "feature_selection" = list(TRUE, `==`, list("buskirk_surveying_2018", "noauthor_ibm-random-forest_2023")),
      "handles_small_n" = list(1, `*`, list("ramezan_effects_2021", "reel_using_2021")),
      "high_dimensional" = list(1, `*`, list("buskirk_surveying_2018")),
      "n_predictors_per_sample" = list(1, `*`, list("buskirk_surveying_2018")),
      "outlier_sensitivity" = list(1, `*`, list("breiman_random_2001", "altman_ensemble_2017")),
      "prone_to_overfit" = list(1, `*`, list("buskirk_surveying_2018", "altman_ensemble_2017", "noauthor_ibm-random-forest_2023")),
      "prop_missing" = list(0.5, `*`, list("buskirk_surveying_2018", "hapfelmeier_variable_2014"))
    )
  ),
  "gbtree" = list(
    "full_name" = "Gradient Boosting Tree",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list()),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(0.5, `*`, list("friedman_greedy_2001")),
      "feature_selection" = list(0.5, `*`, list()),
      "handles_small_n" = list(0.75, `*`, list("ramezan_effects_2021", "reel_using_2021")),
      "high_dimensional" = list(1, `*`, list()),
      "n_predictors_per_sample" = list(1, `*`, list()),
      "outlier_sensitivity" = list(0.5, `*`, list("aws_boosting_2023")),
      "prone_to_overfit" = list(0.5, `*`, list("google_overfitting_2023")),
      "prop_missing" = list(0.5, `*`, list("bentejac_comparative_2021"))
    )
  ),
  "pls" = list(
    "full_name" = "Partial Least Squares Regression",
    "hard" = list(
      "any_is_na" = PASS_BOOLEAN_RULE,
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(1, `*`, list()),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(0.5, `*`, list()),
      "feature_selection" = list(TRUE, `==`, list()),
      "handles_small_n" = list(0.25, `*`, list("reel_using_2021")),
      "high_dimensional" = list(1, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0.5, `*`, list()),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "knn" = list(
    "full_name" = "k-Nearest Neighbors",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.5, `*`, list("taunk_brief_2019")),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(1, `*`, list("taunk_brief_2019", "lee_chapter_nodate")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0.5, `*`, list("ramezan_effects_2021", "reel_using_2021")),
      "high_dimensional" = list(0.5, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0.25, `*`, list()),
      "prone_to_overfit" = list(0.5, `*`, list("noauthor_ibm-knn-2023")),
      "prop_missing" = list(0.5, `*`, list())
    )
  ),
  "lr" = list(
    "full_name" = "Linear Regression",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(3, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(TRUE, `<=`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0, `*`, list("ellis_when_2022")),
      "equation" = list(TRUE, `==`, list()),
      "explainability" = list(1, `*`, list("ellis_when_2022")),
      "feature_selection" = list(FALSE, `==`, list()),
      "handles_small_n" = list(0.75, `*`, list("reel_using_2021")),
      "high_dimensional" = list(0.5, `*`, list()),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0 , `*`, list("ellis_when_2022")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0, `*`, list("ellis_when_2022"))
    )
  ),
  "lda" = list(
    "full_name" = "Linear Discriminant Analysis",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(1, `*`, list("noauthor_ibm-lda_2023")),
      "equation" = list(FALSE, `==`, list()),
      "explainability" = list(0.75, `*`, list("noauthor_ibm-lda_2023")),
      "feature_selection" = list(TRUE, `==`, list()),
      "handles_small_n" = list(0.25, `*`, list()),
      "high_dimensional" = list(0.25, `*`, list("noauthor_ibm-lda_2023")),
      "n_predictors_per_sample" = list(1, `*`, list("noauthor_ibm-lda_2023")),
      "outlier_sensitivity" = list(0.25 , `*`, list("Fujin_Zhong_Jiashu_Zhang_2013")),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "nb" = list(
    "full_name" = "Naive Bayes",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = list(2, `>=`),
      "naive_bayes_cutoff" = list(100, `<=`),
      "regression" = list(FALSE, `==`),
      "supervised" = TRUE
    ),
    "soft" = list(
      "correlation" = list(0.25, `*`, list("noauthor_ibm-nb_2021")),
      "equation" = list(FALSE, `==`, list()),
      "explainability" = list(0.5, `*`, list("noauthor_ibm-nb_2021")),
      "feature_selection" = list(TRUE, `==`, list()),
      "handles_small_n" = list(0.25, `*`, list()),
      "high_dimensional" = list(1, `*`, list("noauthor_ibm-nb_2021")),
      "n_predictors_per_sample" = list(0.5, `*`, list()),
      "outlier_sensitivity" = list(0.5 , `*`, list()),
      "prone_to_overfit" = list(0.5, `*`, list()),
      "prop_missing" = list(0, `*`, list())
    )
  ),
  "kmeans" = list(
    "full_name" = "k-Means Clustering",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = PASS_ANY_RULE,
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = PASS_BOOLEAN_RULE,
      "supervised" = FALSE
    ),
    "soft" = list(
      "correlation" = list(1, `*`, list()),
      "equation" = list(FALSE, `&`, list()),
      "explainability" = list(FALSE, `&`, list("christina_when_2022")),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0, `*`),
      "high_dimensional" = list(0.5, `*`, list("saxena_review_2017")),
      "n_predictors_per_sample" = list(0, `*`, list()),
      "outlier_sensitivity" = list(0.5, `*`, list("saxena_review_2017")),
      "prone_to_overfit" = list(0.5, `*`, list("christina_when_2022")),
      "prop_missing" = list(0.5, `*`, list())
    )
  ),
  "hclust" = list(
    "full_name" = "Hierarchical Clustering",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = PASS_ANY_RULE,
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = PASS_BOOLEAN_RULE,
      "supervised" = FALSE
    ),
    "soft" = list(
      "correlation" = list(0.75, `*`, list()),
      "equation" = list(FALSE, `&`, list("xu_survey_2005")),
      "explainability" = list(TRUE, `==`, list()),
      "feature_selection" = list(FALSE, `&`, list()),
      "handles_small_n" = list(0, `*`),
      "high_dimensional" = list(1, `*`, list("saxena_review_2017")),
      "n_predictors_per_sample" = list(0, `*`, list()),
      "outlier_sensitivity" = list(1, `*`, list("saxena_review_2017")),
      "prone_to_overfit" = list(1, `*`, list()),
      "prop_missing" = list(0.5, `*`, list())
    )
  ),
  "pca" = list(
    "full_name" = "PCA",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = PASS_ANY_RULE,
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = PASS_BOOLEAN_RULE,
      "supervised" = FALSE
    ),
    "soft" = list(
      "correlation" = list(1, `*`),
      "equation" = list(FALSE, `&`),
      "explainability" = list(0, `*`),
      "feature_selection" = list(FALSE, `&`),
      "handles_small_n" = list(0, `*`),
      "high_dimensional" = list(1, `*`),
      "n_predictors_per_sample" = list(0, `*`),
      "outlier_sensitivity" = list(0, `*`),
      "prone_to_overfit" = list(0, `*`),
      "prop_missing" = list(0, `*`)
    )
  ),
  "ppca" = list(
    "full_name" = "PPCA",
    "hard" = list(
      "any_is_na" = PASS_BOOLEAN_RULE,
      "n_levels" = PASS_ANY_RULE,
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = PASS_BOOLEAN_RULE,
      "supervised" = FALSE
    ),
    "soft" = list(
      "correlation" = list(1, `*`),
      "equation" = list(FALSE, `&`),
      "explainability" = list(0, `*`),
      "feature_selection" = list(FALSE, `&`),
      "handles_small_n" = list(0, `*`),
      "high_dimensional" = list(1, `*`),
      "n_predictors_per_sample" = list(0, `*`),
      "outlier_sensitivity" = list(0, `*`),
      "prone_to_overfit" = list(0, `*`),
      "prop_missing" = list(0, `*`)
    )
  ),
  "umap" = list(
    "full_name" = "UMAP",
    "hard" = list(
      "any_is_na" = list(FALSE, `==`),
      "n_levels" = PASS_ANY_RULE,
      "naive_bayes_cutoff" = PASS_ANY_RULE,
      "regression" = PASS_BOOLEAN_RULE,
      "supervised" = FALSE
    ),
    "soft" = list(
      "correlation" = list(0, `*`),
      "equation" = list(FALSE, `&`),
      "explainability" = list(0, `*`),
      "feature_selection" = list(FALSE, `&`),
      "handles_small_n" = list(0, `*`),
      "high_dimensional" = list(1, `*`),
      "n_predictors_per_sample" = list(0, `*`),
      "outlier_sensitivity" = list(0, `*`),
      "prone_to_overfit" = list(0, `*`),
      "prop_missing" = list(0, `*`)
    )
  )
)

# Algos with outstanding issues, keeping track of them here.
TO_ADD = list(
)

usethis::use_data(
  hard_rule_names,
  soft_rule_names,
  hard_rule_descriptions,
  soft_rule_descriptions,
  algo_rules,
  PASS_ANY_RULE,
  PASS_BOOLEAN_RULE,
  overwrite = TRUE
)
