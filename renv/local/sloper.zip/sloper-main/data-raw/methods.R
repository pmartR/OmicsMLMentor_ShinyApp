# Machine learning/cross validation methods ------------------------------------

# Below are vectors containing machine learning and cross validation methods
# that are accepted by sloper. These vectors will be used in several places to
# make sure the inputs to different functions are correct. By including the
# vectors here they only have to be updated in one place.

acceptable_sl_sup <- c(
  "rf", "lsvm", "psvm", "rsvm", "logistic", "loglasso",
  "multi", "multilasso", "gbtree", "pls", "lr", "knn",
  "lda", "nb"
)

acceptable_sl_unsup <- c(
  "kmeans", "hclust", "pca", "ppca", "umap"
)

acceptable_cv <- c("kfcv", "loocv")

decision_tree_methods <- c("rf")
svm_methods <- c("lsvm", "psvm", "rsvm")
logistic_methods <- c("logistic", "loglasso")
multinomial_methods <- c("multi", "multilasso")
pca_methods <- c("pls")

VARIABLE_IMPORTANCE_METHODS = list(
  'decision_tree_methods' = decision_tree_methods,
  'svm_methods' = svm_methods,
  'logistic_methods' = logistic_methods,
  'multinomial_methods' = multinomial_methods,
  'pca_methods' = pca_methods
)

# plot mappings

PLOTS_TO_TASKS = list(
  "variable_importance" = list("classification"), 
  "roc_curve" = list("classification"), 
  "confidence_bar" = list("classification"),  
  "prediction_bar" = list("classification"),  
  "confusion_heatmap" = list("classification"),  
  "confidence_scatter" = list("classification"), 
  "predicted_v_actual" = list("regression") 
)

CLASSIFICATION_PLOTS = Filter(function(x) "classification" %in% PLOTS_TO_TASKS[[x]], names(PLOTS_TO_TASKS))
REGRESSION_PLOTS = Filter(function(x) "regression" %in% PLOTS_TO_TASKS[[x]], names(PLOTS_TO_TASKS))

TASKS_TO_PLOTS = list(
  "classification" = CLASSIFICATION_PLOTS,
  "regression" = REGRESSION_PLOTS
)

# Save as internal data --------------------------------------------------------

usethis::use_data(
  acceptable_sl_sup,
  acceptable_sl_unsup,
  acceptable_cv,
  VARIABLE_IMPORTANCE_METHODS,
  PLOTS_TO_TASKS,
  TASKS_TO_PLOTS,
  CLASSIFICATION_PLOTS,
  REGRESSION_PLOTS,
  internal = TRUE,
  overwrite = TRUE
)
