test_that(
  "peptides are correctly rolled up for each rollup method",
  {
    # Create a pepData object --------------------------------------------------

    omicsData <- pdata

    # Create an slData object --------------------------------------------------

    slData <- as.slData(omicsData)

    # Impute data --------------------------------------------------------------

    imputeData <- imputation(slData)

    # The imputed object is used to compare the rollup from slopeR to pmartR.
    imputed <- apply_imputation(imputeData, slData)

    # Transform data -----------------------------------------------------------

    transData <- transformation(slData, rollupMethod = "rollup")

    # The transfigured object will be used to test the portions of the rollup
    # function that handle presence/absence and quantitative peptides.
    transfigured <- apply_transformation(transData, slData, threshold = 0.5)

    # Tests for imputed data ---------------------------------------------------

    # Make sure the rollup from slopeR matches the rollup from pmartR. This is
    # only true when there are not presence absence proteins. Presence/absence
    # proteins occur when the apply_transformation function is run with a
    # threshold (not an interval).

    # Vanilla rollup ---------------

    rollup_sloper <- protein_rollup(
      imputed,
      method = "rollup",
      parallel = FALSE
    )
    rollup_pmartr <- pmartR::protein_quant(
      imputed %>% `class<-`("pepData"),
      method = "rollup",
      parallel = FALSE
    )
    expect_identical(
      rollup_sloper$e_data,
      rollup_pmartr$e_data
    )
    expect_identical(
      rollup_sloper$e_meta,
      rollup_pmartr$e_meta
    )
    expect_identical(
      attr(rollup_sloper, "data_info"),
      attr(rollup_pmartr, "data_info")
    )
    expect_identical(
      attr(rollup_sloper, "meta_info"),
      attr(rollup_pmartr, "meta_info")
    )
    expect_identical(
      attr(rollup_sloper, "omicsData_class"),
      "proData"
    )
    expect_identical(
      attr(rollup_sloper, "prot_quant_info"),
      list(method = "rollup")
    )

    # R rollup (or chocolate rollup if you are Kelly) ---------------

    rollup_sloper <- protein_rollup(
      imputed,
      method = "rrollup",
      parallel = FALSE
    )
    rollup_pmartr <- pmartR::protein_quant(
      imputed %>% `class<-`("pepData"),
      method = "rrollup",
      parallel = FALSE
    )
    expect_identical(
      rollup_sloper$e_data,
      rollup_pmartr$e_data
    )
    expect_identical(
      rollup_sloper$e_meta,
      rollup_pmartr$e_meta
    )
    expect_identical(
      attr(rollup_sloper, "data_info"),
      attr(rollup_pmartr, "data_info")
    )
    expect_identical(
      attr(rollup_sloper, "meta_info"),
      attr(rollup_pmartr, "meta_info")
    )
    expect_identical(
      attr(rollup_sloper, "omicsData_class"),
      "proData"
    )
    expect_identical(
      attr(rollup_sloper, "prot_quant_info"),
      list(method = "rrollup")
    )

    # Q rollup ---------------

    rollup_sloper <- protein_rollup(
      imputed,
      method = "qrollup",
      qrollup_thresh = 0.5,
      parallel = FALSE
    )
    rollup_pmartr <- pmartR::protein_quant(
      imputed %>% `class<-`("pepData"),
      method = "qrollup",
      qrollup_thresh = 0.5,
      parallel = FALSE
    )
    expect_identical(
      rollup_sloper$e_data,
      rollup_pmartr$e_data
    )
    expect_identical(
      rollup_sloper$e_meta,
      rollup_pmartr$e_meta
    )
    expect_identical(
      attr(rollup_sloper, "data_info"),
      attr(rollup_pmartr, "data_info")
    )
    expect_identical(
      attr(rollup_sloper, "meta_info"),
      attr(rollup_pmartr, "meta_info")
    )
    expect_identical(
      attr(rollup_sloper, "omicsData_class"),
      "proData"
    )
    expect_identical(
      attr(rollup_sloper, "prot_quant_info"),
      list(method = "qrollup")
    )

    # Z rollup ---------------

    rollup_sloper <- protein_rollup(
      imputed,
      method = "zrollup",
      single_pep = TRUE,
      parallel = FALSE
    )
    rollup_pmartr <- pmartR::protein_quant(
      imputed %>% `class<-`("pepData"),
      method = "zrollup",
      single_pep = TRUE,
      parallel = FALSE
    )
    expect_identical(
      rollup_sloper$e_data,
      rollup_pmartr$e_data
    )
    expect_identical(
      rollup_sloper$e_meta,
      rollup_pmartr$e_meta
    )
    expect_identical(
      attr(rollup_sloper, "data_info"),
      attr(rollup_pmartr, "data_info")
    )
    expect_identical(
      attr(rollup_sloper, "meta_info"),
      attr(rollup_pmartr, "meta_info")
    )
    expect_identical(
      attr(rollup_sloper, "omicsData_class"),
      "proData"
    )
    expect_identical(
      attr(rollup_sloper, "prot_quant_info"),
      list(method = "zrollup")
    )

    # Tests for transformed data -----------------------------------------------

    # Dear new slopeR programmer,
    #
    # This section must be filled out by whoever inherits this project from me.
    # (You!) I do not know who you are but I already feel a deep connection with
    # you. I have already gone through the coding hell you are just now
    # entering. I send you my best wishes and luck on your new journey. I wish I
    # had more wisdom and comfort to send you, but the offering of our
    # connection and my comments throughout the package will have to be enough
    # to carry you through the dark days and sleepless nights.
    #
    # Good luck! I believe in you!
    #
    # Sincerely yours,
    # old slopeR programmer
  }
)
