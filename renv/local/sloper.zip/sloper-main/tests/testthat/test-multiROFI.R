


test_that(
  
  "incorrect input throws errors",
  {
    testthat::skip_if_not_installed("workflowsets")
    
    # Create an omicsData object -----------------------------------------------
    
    omicsData <- mdata
    # system.file("testdata",...,package="my_package")
    # barfile <- system.file("extdata", "bar.csv", package="mypackage")
    # bar <- read.csv(barfile)
    
    # Create an slData object --------------------------------------------------
    
    slData <- as.slData(omicsData, response_cols = "Gender")
    slDatasets <- list(slData, slData)
    
    # Create modeldf object ----------------------------------------------------
    modeldf <- expand.grid(c('lsvm', 'lsvm'), c('lsvm', 'lsvm'))
    
    # Other multiROFI specific values ------------------------------------------
    nFolds <- 10
    outcomes <- c(1,1,1,1,0,0,0,0)
    sampleKeysID <- seq(1:8)
    
    
    # Impute data --------------------------------------------------------------
    
    imputeData <- imputation(slData)
    
    applied_imputation <- apply_imputation(imputeData, slData)
    
    # create modeldf for assigning models 
    
    
    
    
    # Tests handling bad input:
    expect_error(multiROFI(modeldf, slDatasets, nFolds, outcomes, sampleKeysID))
    # test error when passing in only 1 dataset
    expect_error(multiROFI(modeldf, slData, nFolds, outcomes, sampleKeysID))
    # test error when the dimensions of the modeldf doesn't match number of 
    # slData objects passed in
    expect_error(multiROFI(modeldf[,1], slDatasets, 'loocv', nFolds,outcomes, sampleKeysID ))
    
    # test error when any of the passed in data objects are not slData objects
    expect_error(multiROFI(modeldf, c(slData, 'string'), loocv, nFolds, outcomes, sampleKeysID))
    expect_error(multiROFI(modeldf, c('string', slData), 'loocv', nFolds, outcomes, sampleKeysID))
    # test for correctness of string used to specify cross-validation method
    expect_error(multiROFI(modeldf, c('string', slData), 'looocv', nFolds, outcomes, sampleKeysID))
    expect_error(multiROFI(modeldf, c('string', slData), 'kkfcv', nFolds, outcomes, sampleKeysID))
    # test error if outcomes is not a bivariate factor 
    expect_error(multiROFI(modeldf, c('string', slData), 'kkfcv', nFolds, c(1,1,1,1,0,0,3,0), sampleKeysID))
    # test equal length of outcomes and sampleKeys
    expect_error(multiROFI(modeldf, slDatasets, 'kfcv', outcomes[1:7], sampleKeysID))
    expect_error(multiROFI(modeldf, slDatasets, 'kfcv', outcomes, sampleKeysID[1:7]))
    
    
    
  }
)