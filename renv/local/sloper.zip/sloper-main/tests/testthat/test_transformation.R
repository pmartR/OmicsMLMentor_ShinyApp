test_that(
  "transformation and apply_transformation function properly",
  {
    # Create an omicsData object -----------------------------------------------

    omicsData <- mdata

    # Create an slData object --------------------------------------------------

    slData <- as.slData(omicsData, response_cols = "Gender")

    # Transform data -----------------------------------------------------------

    transData <- transformation(slData)

    # We don't want any dplyr messages displayed when running the tests.
    suppressMessages(
      applied_threshold <- apply_transformation(
        transData, slData,
        threshold = 0.5
      )
    )

    applied_interval <- apply_transformation(
      transData, slData,
      interval = c(0, 1)
    )

    # Holy transformation tests, Batman ----------------------------------------

    # Tests for the transformation function:

    expect_s3_class(
      transData,
      "transData"
    )

    expect_identical(
      dim(transData),
      c(80L, 2L)
    )

    expect_identical(
      c(transData),
      list(
        Metabolite = slData$e_data$Metabolite,
        prop_missing = rowSums(is.na(slData$e_data[, -1])) /
          (ncol(slData$e_data) - 1)
      )
    )

    expect_identical(
      attr(transData, "original_edata"),
      slData$e_data
    )

    expect_identical(
      attr(transData, "na_to_zero"),
      slData$e_data %>%
        dplyr::select(-Metabolite) %>%
        dplyr::mutate(
          dplyr::across(dplyr::everything(), ~ replace(., is.na(.), 0))
        ) %>%
        dplyr::bind_cols(
          dplyr::select(slData$e_data, Metabolite)
        )
    )

    # Tests for the apply_transformation function:

    # Make sure the data_info attribute was correctly updated.
    expect_identical(
      attr(applied_threshold, "data_info")$num_miss_obs,
      0L
    )
    expect_identical(
      attr(applied_threshold, "data_info")$prop_missing,
      0
    )
    expect_identical(
      attr(applied_threshold, "data_info")$norm_info,
      attr(slData, "data_info")$norm_info
    )
    expect_identical(
      attr(applied_threshold, "data_info")$batch_info,
      attr(slData, "data_info")$batch_info
    )
    expect_identical(
      attr(applied_threshold, "data_info")$data_scale_orig,
      attr(slData, "data_info")$data_scale_orig
    )
    expect_identical(
      attr(applied_threshold, "data_info")$data_scale,
      attr(slData, "data_info")$data_scale
    )
    expect_identical(
      attr(applied_threshold, "data_info")$num_edata,
      attr(slData, "data_info")$num_edata
    )
    expect_identical(
      attr(applied_threshold, "data_info")$num_samps,
      attr(slData, "data_info")$num_samps
    )

    # Test other pmartR attributes that should not have changed.
    expect_identical(
      attr(applied_threshold, "meta_info"),
      attr(slData, "meta_info")
    )
    expect_identical(
      attr(applied_threshold, "class_info"),
      attr(slData, "class_info")
    )
    expect_identical(
      attr(applied_threshold, "feature_info"),
      attr(slData, "feature_info")
    )

    # Check out the attributes included after applying the imputation.
    expect_identical(
      attr(applied_threshold, "original_edata"),
      slData$e_data
    )
    expect_identical(
      attr(applied_threshold, "transformation_info"),
      list(
        n_pres_abs = 15L,
        names_pres_abs = c(
          "adenosine ", "adenosine-5'-monophosphate", "creatinine",
          "D-glucose-6-phosphate", "dihydroxyacetone phosphate",
          "D-ribose-5-phosphate", "gluconic acid", "hypotaurine",
          "inositol phosphate", "pyrophosphate", "Unknown 12", "Unknown 15",
          "Unknown 26", "Unknown 27", "Unknown 28"
        ),
        rollup_method = NULL,
        interval = NULL
      )
    )

    # Make sure the data_info attribute was correctly updated.
    expect_identical(
      attr(applied_interval, "data_info")$num_miss_obs,
      0L
    )
    expect_identical(
      attr(applied_interval, "data_info")$prop_missing,
      0
    )
    expect_identical(
      attr(applied_interval, "data_info")$norm_info,
      attr(slData, "data_info")$norm_info
    )
    expect_identical(
      attr(applied_interval, "data_info")$batch_info,
      attr(slData, "data_info")$batch_info
    )
    expect_identical(
      attr(applied_interval, "data_info")$data_scale_orig,
      attr(slData, "data_info")$data_scale_orig
    )
    expect_identical(
      attr(applied_interval, "data_info")$data_scale,
      attr(slData, "data_info")$data_scale
    )
    expect_identical(
      attr(applied_interval, "data_info")$num_edata,
      attr(slData, "data_info")$num_edata
    )
    expect_identical(
      attr(applied_interval, "data_info")$num_samps,
      attr(slData, "data_info")$num_samps
    )

    # Test other pmartR attributes that should not have changed.
    expect_identical(
      attr(applied_interval, "meta_info"),
      attr(slData, "meta_info")
    )
    expect_identical(
      attr(applied_interval, "class_info"),
      attr(slData, "class_info")
    )
    expect_identical(
      attr(applied_interval, "feature_info"),
      attr(slData, "feature_info")
    )

    # Check out the attributes included after applying the imputation.
    expect_identical(
      attr(applied_interval, "original_edata"),
      slData$e_data
    )
    expect_identical(
      attr(applied_interval, "transformation_info"),
      list(
        n_pres_abs = NULL,
        names_pres_abs = NULL,
        rollup_method = NULL,
        interval = c(0, 1)
      )
    )
  }
)
