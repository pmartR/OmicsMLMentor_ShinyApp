test_that(
  "as.slData returns the correct object and attributes",
  {
    # Create an omicsData object -----------------------------------------------

    omicsData <- mdata

    # Create an slData object --------------------------------------------------

    with_class <- as.slData(omicsData, response_cols = "Gender")

    without_class <- as.slData(omicsData)

    # Run tests on slData objects ----------------------------------------------

    # Make sure the main structure (e_data, f_data, and e_meta) of the slData
    # object remains unchanged from the omicsData object.
    expect_identical(
      with_class$e_data,
      omicsData$e_data
    )
    expect_identical(
      with_class$f_data,
      omicsData$f_data
    )
    expect_identical(
      with_class$e_meta,
      omicsData$e_meta
    )
    expect_identical(
      without_class$e_data,
      omicsData$e_data
    )
    expect_identical(
      without_class$f_data,
      omicsData$f_data
    )
    expect_identical(
      without_class$e_meta,
      omicsData$e_meta
    )

    # Check whether the attributes of the slData object are correct.
    expect_identical(
      attributes(with_class),
      list(
        names = c("e_data", "f_data", "e_meta"),
        cnames = list(
          edata_cname = "Metabolite",
          emeta_cname = NULL,
          fdata_cname = "SampleID",
          techrep_cname = NULL
        ),
        data_info = attr(omicsData, "data_info"),
        check.names = TRUE,
        meta_info = list(meta_data = FALSE, num_emeta = NULL),
        filters = list(),
        class = c("slData", "metabData"),
        group_DF = attr(omicsData, "group_DF"),
        response_info = list(
          "categorical" = list(
            raw_values = data.frame(
              sample_id = omicsData$f_data$SampleID,
              response = omicsData$f_data$Gender
            ),
            n_lvls = dplyr::n_distinct(omicsData$f_data$Gender),
            "fdata_col" = "Gender"
          ),
          "continuous" = NULL
  
        ),
        feature_info = data.frame(
          names_orig = omicsData$e_data$Metabolite,
          names_compact = paste(
            "feature", 1:length(omicsData$e_data$Metabolite),
            sep = "_"
          )
        ),
        omicsData_class = "metabData"
      )
    )
    expect_identical(
      attributes(without_class),
      list(
        names = c("e_data", "f_data", "e_meta"),
        cnames = list(
          edata_cname = "Metabolite",
          emeta_cname = NULL,
          fdata_cname = "SampleID",
          techrep_cname = NULL
        ),
        data_info = attr(omicsData, "data_info"),
        check.names = TRUE,
        meta_info = list(meta_data = FALSE, num_emeta = NULL),
        filters = list(),
        class = c("slData", "metabData"),
        group_DF = attr(omicsData, "group_DF"),
        # When creating an slData object there is no class_info attribute if you
        # assign NULL to it. Therefore, we have to leave this attribute out (we
        # can't set class_info = NULL) when creating the list to test the
        # attributes against.
        feature_info = data.frame(
          names_orig = omicsData$e_data$Metabolite,
          names_compact = paste(
            "feature", 1:length(omicsData$e_data$Metabolite),
            sep = "_"
          )
        ),
        omicsData_class = "metabData"
      )
    )
  }
)
