test_that("Hard and Soft Rule Names and Descriptions are valid", {
  expect_equal(length(hard_rule_names), length(hard_rule_descriptions))
  expect_equal(length(soft_rule_names), length(soft_rule_descriptions))
})

test_that("Each algorithm has a full name and hard/soft rules", {
  for (algo in names(algo_rules)) {
    expect_named(algo_rules[[algo]], 
                 c("full_name","hard","soft"), 
                 ignore.order = TRUE)
  }
})