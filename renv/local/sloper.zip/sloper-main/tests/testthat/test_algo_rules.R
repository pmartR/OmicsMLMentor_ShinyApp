test_that("algorithm rules are correctly specified", {
    # all model rules contain a key for all soft rules and hard rules
    for (algo in names(algo_rules)) {
        # check all hard rules have an entry
        expect_true(
            all(names(hard_rule_names) %in% names(algo_rules[[algo]]$hard))
        )

        # check all soft rules have an entry
        expect_true(
            all(names(soft_rule_names) %in% names(algo_rules[[algo]]$soft))
        )
    }

    # test that the keys are sorted alphabetically
    for (algo in names(algo_rules)) {
        expect_true(
            all(names(algo_rules[[algo]]$hard) == sort(names(algo_rules[[algo]]$hard)))
        )
        expect_true(
            all(names(algo_rules[[algo]]$soft) == sort(names(algo_rules[[algo]]$soft)))
        )
    }
})