# dimensionality reduction

    Code
      p$data
    Output
      # A tibble: 12 x 3
             PC1    PC2     PC3
       *   <dbl>  <dbl>   <dbl>
       1  -1.13    5.95 -1.62  
       2  -1.09    5.11 -0.177 
       3   0.127   3.85  1.20  
       4  -4.13   -1.31 -0.488 
       5  -3.55    5.28 -0.380 
       6  -2.50    4.41 -3.20  
       7   1.03    2.64  4.94  
       8 -10.6   -11.5   0.0175
       9  -5.77   -2.82  1.46  
      10   7.83   -5.32 -3.36  
      11  10.5    -3.35  1.20  
      12   9.32   -2.98  0.406 

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      
      [[2]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

