# unsupervised clustering

    Code
      p$data
    Output
      # A tibble: 15 x 4
             PC1    PC2 cluster   type    
           <dbl>  <dbl> <fct>     <chr>   
       1   1.13    5.95 Cluster_1 data    
       2   1.09    5.11 Cluster_1 data    
       3  -0.127   3.85 Cluster_1 data    
       4   4.13   -1.31 Cluster_1 data    
       5   3.55    5.28 Cluster_1 data    
       6   2.50    4.41 Cluster_1 data    
       7  -1.03    2.64 Cluster_1 data    
       8  10.6   -11.5  Cluster_2 data    
       9   5.77   -2.82 Cluster_1 data    
      10  -7.83   -5.32 Cluster_3 data    
      11 -10.5    -3.35 Cluster_3 data    
      12  -9.32   -2.98 Cluster_3 data    
      13   2.13    2.89 Cluster_1 centroid
      14  10.6   -11.5  Cluster_2 centroid
      15  -9.21   -3.88 Cluster_3 centroid

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

