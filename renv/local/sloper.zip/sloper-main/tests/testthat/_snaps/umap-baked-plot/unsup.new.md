# dimensionality reduction

    Code
      p$data
    Output
      # A tibble: 12 x 2
           UMAP1   UMAP2
       *   <dbl>   <dbl>
       1  0.0858 -1.73  
       2  1.68   -1.05  
       3  1.23    0.726 
       4 -1.29   -1.62  
       5  1.07   -1.30  
       6  0.871  -1.87  
       7  1.62   -0.159 
       8 -1.22   -1.05  
       9 -1.48   -0.0410
      10 -0.817   1.67  
      11  0.410   1.50  
      12  0.495   2.03  

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      
      [[2]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

