# unsupervised clustering

    Code
      tidyclust::extract_fit_parsnip(res)$fit %>% str()
    Output
      List of 7
       $ merge      : int [1:11, 1:2] -11 -2 -4 -5 -1 2 -10 -7 3 7 ...
       $ height     : num [1:11] 3.99 4.39 5.78 5.92 6.41 ...
       $ order      : int [1:12] 8 10 11 12 4 9 7 2 3 1 ...
       $ labels     : NULL
       $ method     : chr "complete"
       $ call       : language stats::hclust(d = stats::as.dist(dmat), method = linkage_method)
       $ dist.method: NULL
       - attr(*, "class")= chr "hclust"
       - attr(*, "num_clusters")= num 3
       - attr(*, "training_data")= num [1:12, 1:150] -4.17 -4.17 -4.17 -4.17 -4.17 ...
        ..- attr(*, "dimnames")=List of 2
        .. ..$ : NULL
        .. ..$ : chr [1:150] "feature_1" "feature_2" "feature_3" "feature_4" ...

