# dimensionality reduction

    Code
      res
    Message <cliMessage>
      
      -- Recipe ----------------------------------------------------------------------
      
      -- Inputs 
      Number of variables by role
      predictor: 150
      
      -- Operations 
      * UMAP embedding for: recipes::all_numeric()

---

    Code
      res
    Output
      # A tibble: 12 x 2
           UMAP1  UMAP2
       *   <dbl>  <dbl>
       1 -0.115   1.68 
       2 -1.11    1.33 
       3 -1.81    1.10 
       4  0.938   1.16 
       5 -1.54    0.382
       6 -1.58   -0.227
       7  0.667   1.96 
       8  1.68    0.234
       9  1.25   -0.596
      10 -0.0679 -2.03 
      11 -1.03   -1.57 
      12 -0.882  -1.25 

