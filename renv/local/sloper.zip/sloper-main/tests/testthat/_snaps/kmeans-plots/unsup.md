# unsupervised clustering

    Code
      p$data
    Output
      # A tibble: 14 x 4
             PC1    PC2 cluster   type    
           <dbl>  <dbl> <fct>     <chr>   
       1   1.13    5.95 Cluster_1 data    
       2   1.09    5.11 Cluster_1 data    
       3  -0.127   3.85 Cluster_1 data    
       4   4.13   -1.31 Cluster_1 data    
       5   3.55    5.28 Cluster_1 data    
       6   2.50    4.41 Cluster_1 data    
       7  -1.03    2.64 Cluster_1 data    
       8  10.6   -11.5  Cluster_1 data    
       9   5.77   -2.82 Cluster_1 data    
      10  -7.83   -5.32 Cluster_2 data    
      11 -10.5    -3.35 Cluster_2 data    
      12  -9.32   -2.98 Cluster_2 data    
      13   3.07    1.29 Cluster_1 centroid
      14  -9.21   -3.88 Cluster_2 centroid

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

