# dimensionality reduction

    Code
      p$data
    Output
      # A tibble: 12 x 5
           PC1     PC2    PC3     PC4    PC5
         <dbl>   <dbl>  <dbl>   <dbl>  <dbl>
       1 -39.9  -0.599   5.27 -1.56    2.47 
       2 -38.5  -0.692   4.90 -0.239  -0.573
       3 -38.2   0.440   3.58  1.13   -2.36 
       4 -37.5  -4.14   -1.29 -0.471   0.352
       5 -39.7  -3.07    4.85 -0.377  -0.168
       6 -38.9  -2.12    4.13 -3.25   -1.83 
       7 -38.2   1.28    2.23  4.99    2.61 
       8 -34.4 -11.4   -10.4   0.0206 -0.782
       9 -37.4  -5.86   -2.74  1.51    0.452
      10 -35.6   7.51   -5.83 -3.26    3.15 
      11 -35.3  10.3    -3.81  1.17   -1.96 
      12 -35.6   9.11   -3.43  0.392  -1.53 

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      
      [[2]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

