# dimensionality reduction

    Code
      p$data
    Output
      # A tibble: 12 x 2
          UMAP1   UMAP2
          <dbl>   <dbl>
       1  0.427 -1.21  
       2  1.75  -0.0798
       3  1.54   0.976 
       4 -0.131  1.55  
       5  1.77  -0.888 
       6  1.19  -0.923 
       7  0.860  1.52  
       8 -1.12   0.989 
       9 -0.656  1.82  
      10 -0.451 -1.90  
      11 -0.851 -1.50  
      12 -1.87  -0.941 

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      
      [[2]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

