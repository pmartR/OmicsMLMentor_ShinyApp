# dimensionality reduction

    Code
      p$data
    Output
      # A tibble: 12 x 2
          UMAP1   UMAP2
          <dbl>   <dbl>
       1  0.640  1.44  
       2  1.51   1.02  
       3  1.83   1.21  
       4 -0.693  1.60  
       5  1.72   0.292 
       6  1.38  -0.601 
       7 -0.320  1.57  
       8 -1.20   1.07  
       9 -1.65   0.0471
      10 -0.937 -1.47  
      11  0.247 -1.52  
      12 -0.274 -2.03  

---

    Code
      p$layers
    Output
      [[1]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      
      [[2]]
      geom_point: na.rm = FALSE
      stat_identity: na.rm = FALSE
      position_identity 
      

