test_plot <- function(res, ...) {
  p <- plot(res)
  expect_true(inherits(p, c("gg", "ggplot")))
  expect_snapshot(p$data, ...)
  expect_snapshot(p$layers, ...)
}

test_that("unsupervised clustering", {
    slData <- pep_sl

    set.seed(8432)

    # k-means
    res <- cluster_unsup(slData, slMethod = "kmeans")
    expect_true(inherits(res, 'workflow'))
    test_plot(res, variant = "kmeans-plots")
        
    expect_snapshot(tidyclust::extract_fit_parsnip(res)$fit$centers, variant = "kmeans-centers")

    # hclust
    res <- cluster_unsup(slData, num_clusters = 3, slMethod = "hclust")
    expect_true(inherits(res, 'workflow'))
    expect_snapshot(tidyclust::extract_fit_parsnip(res)$fit %>% str(), variant = 'hclust-centers')
    test_plot(res, variant = 'hclust-plots')
})

test_that("dimensionality reduction", {
    slData <- pep_sl

    set.seed(4439)
    
    ## pca

    # no-bake
    res <- embed_unsup(slData, slMethod = "pca", bake=FALSE)
    expect_true(inherits(res, 'recipe'))
    expect_snapshot(res, variant = "pca-recipe")
    test_plot(res, variant = "pca-nobake-plot")

    # bake
    res <- embed_unsup(slData, slMethod = "pca", bake=TRUE)
    expect_snapshot(res, variant = "pca-recipe")
    test_plot(res, variant = "pca-baked-plot")

    ## ppca

    # no-bake
    res <- embed_unsup(slData, slMethod = "ppca", bake=FALSE, num_comp = 3)
    expect_true(inherits(res, 'recipe'))
    expect_snapshot(res, variant = "ppca-recipe")
    test_plot(res, variant = "ppca-nobake-plot")

    # bake
    res <- embed_unsup(slData, slMethod = "ppca", bake=TRUE, num_comp = 3)
    expect_snapshot(res, variant = "ppca-recipe")
    test_plot(res, variant = "ppca-baked-plot")

    ## umap

    # no-bake
    res <- embed_unsup(slData, slMethod = "umap", bake=FALSE)
    expect_true(inherits(res, 'recipe'))
    expect_snapshot(res, variant = "umap-recipe")
    test_plot(res, variant = "umap-nobake-plot")

    # bake
    res <- embed_unsup(slData, slMethod = "umap", bake=TRUE, seed = c(4439, 4444))
    expect_snapshot(res, variant = "umap-recipe")
    test_plot(res, variant = "umap-baked-plot")
})