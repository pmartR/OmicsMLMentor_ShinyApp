test_that("expert_mentor returns the correct output", {
    omicsData <- mdata

    # Create an slData object --------------------------------------------------

    slData <- as.slData(omicsData, response_cols = "Gender")

    # Impute data --------------------------------------------------------------

    imputeData <- imputation(slData)

    slData <- apply_imputation(imputeData, slData)

    # Run expert_mentor --------------------------------------------------------

    # supervised algos
    suggestions_sup <- expert_mentor(slData)

    expect_true(
        all(c("lsvm", "psvm", "rsvm", "logistic", "loglasso", "rf") %in% names(suggestions_sup))
    )

    expect_true(
        !any(c("multi", "multilasso", acceptable_sl_unsup) %in% names(suggestions_sup))
    )

    # unsupervised algos
    suggestions_unsup <- expert_mentor(slData, supervised = FALSE)

    expect_true(
        all(acceptable_sl_unsup %in% names(suggestions_unsup))
    )

    expect_true(
        !any(acceptable_sl_sup %in% names(suggestions_unsup))
    )
    
    # check summary method
    expect_output(mysumm <- summary(suggestions_sup))
    expect_setequal(mysumm$method, names(slopeR::algo_rules))
    
    # check filtering hard rules
    expect_output(mysumm_hard <- summary(suggestions_sup, apply_hard_filter = TRUE))
    expect_setequal(mysumm_hard$method, names(suggestions_sup))

    # check filtering by algos, cover all algos
    combos = combn(names(algo_rules), 2)
    
    for (i in ncol(combos)) {
        algo_names = combos[, i]
        expect_output(mysumm_algo <- summary(suggestions_sup, algos = algo_names))
        expect_setequal(mysumm_algo$method, names(algo_rules)[which(names(algo_rules) %in% algo_names)])
    }

})