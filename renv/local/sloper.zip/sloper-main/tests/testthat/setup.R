# pre-apply imputation so we don't have to re-do it every test
set.seed(7769)
pep_sl <- as.slData(pdata_processed, response_cols = "Condition")
imputeData <- imputation(pep_sl)
pep_sl <- apply_imputation(imputeData, pep_sl)

metab_sl <- as.slData(mdata, response_cols = "Condition")
imputeData <- imputation(metab_sl)
metab_sl <- apply_imputation(imputeData, metab_sl)
