test_that(
  "variable importance runs correctly for all methods",
  {
    omicsData <- mdata
    omicsData$f_data$y <- rnorm(nrow(omicsData$f_data))
    
    slData <- as.slData(omicsData, response_cols = c("Gender"))
    
    imputeData <- imputation(slData)
    
    slData <- apply_imputation(imputeData, slData)
    # Create an slData object --------------------------------------------------
    
    vi_call = rlang::expr(variable_importance(slData, slMethod = slmethod, pTest = 0.2))
    
    # which ones handle regression
    # handles_regression = expert_mentor(slData, handles_regression = T, supervised=T) %>% names()
    
    # basic fits over all supervised methods
    for (slmethod in acceptable_sl_sup) {
      if (!slmethod %in% unlist(VARIABLE_IMPORTANCE_METHODS)) {
        expect_error(eval(vi_call))
        next
      }
      
      suppressWarnings({suppressMessages({
        if (slmethod == "pls") {
          vi_call = rlang::call_modify(vi_call, num_comp = 6)
        }
        
        res = eval(vi_call)
        fit_info = attributes(res)$fit_info
        expect_true(all(inherits(res, c("slRes", "slRes.vi", "workflow"))))
        expect_setequal(names(fit_info), c("method", "prop_test", "data_split", "task"))
        expect_equal(fit_info$method, slmethod)
        expect_identical(fit_info$selected_features, NULL)
        expect_equal(fit_info$prop_test, 0.2)
        expect_true(all(inherits(fit_info$data_split, c("initial_split", "mc_split", "rsplit"))))
        
        # check the data wasn't mangled (this probably only needs to be done once, as it should be method agnostic)
        mat1 = slData$e_data[-which(colnames(slData$e_data) == get_edata_cname(slData))]
        mat2 = t(fit_info$data_split$data[-which(colnames(fit_info$data_split$data) %in% c("response"))])
        expect_equal(sum(mat1 -  mat2), 0)
        expect_equal(dim(fit_info$data_split$data), c(dim(slData$e_data)[2] - 1, dim(slData$e_data)[1] + 1))
        
        # test with a continuous covariate
        tmp_call = rlang::call_modify(vi_call, fdata_use = "dummy_covar", pTest=0.21)
        res = eval(tmp_call)
        fit_info = attributes(res)$fit_info
        expect_true('dummy_covar' %in% tail(names(res$pre$mold$predictors), 3))
        expect_true(
          all(res$pre$mold$predictors$dummy_covar %in% slData$f_data$dummy_covar),
          res$pre$mold$predictors$dummy_covar
        )
        mat1 = slData$e_data[-which(colnames(slData$e_data) == get_edata_cname(slData))]
        mat2 = t(fit_info$data_split$data[-which(colnames(fit_info$data_split$data) %in% c("response", "dummy_covar"))])
        expect_equal(sum(mat1 -  mat2), 0)
        # dimension will have the extra column 'dummy_covar'
        expect_equal(dim(fit_info$data_split$data), c(dim(slData$e_data)[2] - 1, dim(slData$e_data)[1] + 2))
        expect_true("dummy_covar" %in% colnames(fit_info$data_split$data))
        
        # test with a categorical covariate
        tmp_call = rlang::call_modify(vi_call, fdata_use = c("dummy_covar", "Condition"), pTest=0.24)
        res = eval(tmp_call)
        fit_info = attributes(res)$fit_info
        
        condition_levels = paste("Condition", unique(slData$f_data[['Condition']]), sep = "_")
        
        mat1 = slData$e_data[-which(colnames(slData$e_data) == get_edata_cname(slData))]
        mat2 = t(fit_info$data_split$data[-which(colnames(fit_info$data_split$data) %in% c("response", "dummy_covar", condition_levels))])
        expect_equal(sum(mat1 -  mat2), 0)
        
        expect_true(all(c('dummy_covar', condition_levels) %in% tail(names(res$pre$mold$predictors), 3)))
        expect_true(all(c('dummy_covar', condition_levels) %in% colnames(fit_info$data_split$data)))
        expect_true(
          all(res$pre$mold$predictors$dummy_covar %in% slData$f_data$dummy_covar),
          res$pre$mold$predictors$dummy_covar
        )
      })})
    }
  }
)