test_that(
  "imputation and apply_imputation correctly impute data",
  {
    # Create an omicsData object -----------------------------------------------

    omicsData <- mdata

    # Create an slData object --------------------------------------------------

    slData <- as.slData(omicsData, response_cols = "Gender")

    # Impute data --------------------------------------------------------------

    imputeData <- imputation(slData)

    applied_imputation <- apply_imputation(imputeData, slData)

    # Holy imputation tests, Batman --------------------------------------------

    # Tests for the imputation function:

    expect_s3_class(
      imputeData,
      "imputeData"
    )

    expect_identical(
      attr(imputeData, "original_edata"),
      omicsData$e_data
    )

    expect_identical(
      sum(is.na(imputeData)),
      0L
    )

    expect_identical(
      attr(imputeData, "missing_by_sample"),
      slData$e_data[, -1] %>%
        purrr::map_df(~ sum(is.na(.)) / length(.)) %>%
        `class<-`("data.frame")
    )

    expect_identical(
      attr(imputeData, "imputation_method"),
      "ppca"
    )

    # Tests for the apply_imputation function:

    # Make sure e_data is updated with the imputed values. It should be
    # different from the original e_data in that there are no missing values.
    expect_false(
      identical(slData$e_data, applied_imputation$e_data)
    )

    # Make sure the data_info attribute was correctly updated.
    expect_identical(
      attr(applied_imputation, "data_info")$num_miss_obs,
      0L
    )
    expect_identical(
      attr(applied_imputation, "data_info")$prop_missing,
      0
    )
    expect_identical(
      attr(applied_imputation, "data_info")$norm_info,
      attr(slData, "data_info")$norm_info
    )
    expect_identical(
      attr(applied_imputation, "data_info")$batch_info,
      attr(slData, "data_info")$batch_info
    )
    expect_identical(
      attr(applied_imputation, "data_info")$data_scale_orig,
      attr(slData, "data_info")$data_scale_orig
    )
    expect_identical(
      attr(applied_imputation, "data_info")$data_scale,
      attr(slData, "data_info")$data_scale
    )
    expect_identical(
      attr(applied_imputation, "data_info")$num_edata,
      attr(slData, "data_info")$num_edata
    )
    expect_identical(
      attr(applied_imputation, "data_info")$num_samps,
      attr(slData, "data_info")$num_samps
    )

    # Test other pmartR attributes that should not have changed.
    expect_identical(
      attr(applied_imputation, "meta_info"),
      attr(slData, "meta_info")
    )
    expect_identical(
      attr(applied_imputation, "class_info"),
      attr(slData, "class_info")
    )
    expect_identical(
      attr(applied_imputation, "feature_info"),
      attr(slData, "feature_info")
    )

    # Check out the attributes included after applying the imputation.
    expect_identical(
      slData$e_data,
      attr(applied_imputation, "original_edata")
    )
    expect_identical(
      attr(applied_imputation, "imputation_info"),
      list(
        imputation_method = "ppca",
        prop_imputed = attr(slData, "data_info")$prop_missing
      )
    )
  }
)
